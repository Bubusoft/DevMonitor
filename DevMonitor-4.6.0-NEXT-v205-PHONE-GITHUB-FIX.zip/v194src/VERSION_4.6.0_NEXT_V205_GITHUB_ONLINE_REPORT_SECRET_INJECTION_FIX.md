# DevMonitor 4.6.0-NEXT v205 — GitHub Online Reports Release Injection Fix

## Fix

GitHub release builds now pass the restricted Google Drive API key and production
report-folder ID explicitly to the `assembleRelease` Gradle invocation as project
properties.

This removes ambiguity caused by appending `DRIVE_REPORT_API_KEY` to the ZIP's
existing `gradle.properties`, which may already contain a local placeholder or
another property declaration.

## Preserved

- Phone builds continue to use the manually supplied `DRIVE_REPORT_API_KEY` in `gradle.properties`.
- No release-build prompt for the Drive key.
- Existing Google Drive Online Reports implementation is unchanged.
- PaymentEngine/payment-cycle logic unchanged.
- Month-on-Month physical database architecture unchanged.
- Existing release signing configuration unchanged.

## GitHub release path

`DRIVE_REPORT_API_KEY` is read from the GitHub Actions secret and supplied only
to the release Gradle invocation. The secret is not written into the committed
ZIP/source.
