# DevMonitor 4.6.0-NEXT v205 — Phone/GitHub Comparison Baseline

Base: verified phone-built v203 source.

## Version identity
- Android `versionCode`: 205
- Android `versionName`: 4.6.0-NEXT
- Package: `com.aziitech.simregmonitor`

## Online Reports configuration
The phone build path keeps `gradle.properties` authoritative for:
- `DRIVE_REPORT_FOLDER_ID`
- `DRIVE_REPORT_API_KEY`

`build-phone.sh` intentionally does not prompt for or override these values.

The GitHub Actions release path writes the repository `DRIVE_REPORT_API_KEY` secret into the extracted project's `gradle.properties` before `assembleRelease`.

## Investigation boundary
This baseline does not change `OnlineReports.kt`, PaymentEngine, payment-cycle logic, MOM databases, or report-processing behavior. It is the clean v205 source for determining why the phone-built APK can list Google Drive reports while the GitHub-built release has not done so.
