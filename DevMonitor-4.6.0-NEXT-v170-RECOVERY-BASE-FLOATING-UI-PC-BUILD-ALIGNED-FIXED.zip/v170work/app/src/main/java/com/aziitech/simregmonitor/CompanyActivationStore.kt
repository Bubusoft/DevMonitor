package com.aziitech.simregmonitor

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.io.File
import java.time.LocalDate
import java.time.YearMonth
import java.util.Locale

/**
 * Authoritative HQ activation snapshots.
 *
 * Storage is deliberately limited to two physical monthly SQLite databases:
 *   fieldpulse_company_YYYY_MM.db for the current calendar month and
 *   fieldpulse_company_YYYY_MM.db for the immediately previous month.
 *
 * HQ reports are complete exports of the company's view for their month. An accepted
 * newer report therefore replaces the entire stored snapshot for that month. Missing
 * devices are meaningful in an HQ export (zero activity / removed / transferred), so
 * stale rows must not survive a replacement.
 *
 * Import is storage-only. Payment, Device Monitor, Month-on-Month and other analytics
 * read these monthly stores when their own Refresh/action is invoked; importing a
 * report does not invoke those calculations.
 */
class CompanyActivationStore(private val context: Context) {

    private val monthHelpers = mutableMapOf<YearMonth, MonthlyDb>()
    private val monthOnMonthStore by lazy { MonthOnMonthStore(context) }

    companion object {
        private const val LEGACY_DB_NAME = "fieldpulse_company_activations.db"
        private const val DB_PREFIX = "fieldpulse_company_"
        private const val DB_SUFFIX = ".db"
        private const val DB_VERSION = 1
    }

    data class ImportResult(
        val reportId: Long,
        val inserted: Int,
        val replaced: Int,
        val deviceCount: Int,
        val updatedMessage: String?
    )

    data class CycleContribution(
        val reportId: Long,
        val sourceName: String,
        val coverageStart: LocalDate?,
        val coverageEnd: LocalDate?,
        val activationCount: Int
    )

    data class StoredReport(
        val id: Long,
        val sourceName: String,
        val reportType: String,
        val coverageStart: LocalDate?,
        val coverageEnd: LocalDate?,
        val importedAt: Long,
        val deviceCount: Int,
        val dayCount: Int
    )

    data class DeviceScopeRow(
        val deviceId: String,
        val tradeCode: String,
        val partnerName: String,
        val cluster: String,
        val region: String,
        val territory: String,
        val staffName: String
    )

    data class MonthToMonthComparison(
        val asOf: LocalDate,
        val currentTotal: Int,
        val previousTotal: Int,
        val delta: Int,
        val percentChange: Double?
    )

    data class DeviceHistoricalBridge(
        val deviceId: String,
        val reportMonth: YearMonth,
        val coverageStart: LocalDate,
        val coverageEnd: LocalDate,
        val activationSum: Int,
        val sourceReportId: Long
    )

    private class MonthlyDb(context: Context, name: String) : SQLiteOpenHelper(context, name, null, DB_VERSION) {
        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL("""CREATE TABLE company_reports(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_name TEXT NOT NULL,
                report_type TEXT NOT NULL,
                coverage_start TEXT,
                coverage_end TEXT,
                imported_at INTEGER NOT NULL
            )""")
            db.execSQL("""CREATE TABLE company_report_devices(
                report_id INTEGER NOT NULL,
                device_id TEXT NOT NULL,
                trade_code TEXT,
                partner_name TEXT,
                cluster TEXT,
                region TEXT,
                territory TEXT,
                staff_name TEXT,
                PRIMARY KEY(report_id, device_id),
                FOREIGN KEY(report_id) REFERENCES company_reports(id) ON DELETE CASCADE
            )""")
            db.execSQL("""CREATE TABLE activation_days(
                device_id TEXT NOT NULL,
                activation_date TEXT NOT NULL,
                activation_count INTEGER NOT NULL,
                source TEXT NOT NULL,
                report_id INTEGER NOT NULL,
                imported_at INTEGER NOT NULL,
                PRIMARY KEY(device_id, activation_date),
                FOREIGN KEY(report_id) REFERENCES company_reports(id) ON DELETE CASCADE
            )""")
            db.execSQL("CREATE INDEX idx_company_reports_imported ON company_reports(imported_at)")
            db.execSQL("CREATE INDEX idx_company_activation_date ON activation_days(activation_date)")
            db.execSQL("CREATE INDEX idx_company_activation_device ON activation_days(device_id)")
            db.execSQL("CREATE INDEX idx_company_activation_device_date ON activation_days(device_id,activation_date)")
            db.execSQL("CREATE INDEX idx_company_activation_report ON activation_days(report_id)")
            db.execSQL("CREATE INDEX idx_company_report_devices_device ON company_report_devices(device_id)")
        }
        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit
    }

    init {
        migrateLegacyDatabaseIfNeeded()
        removeObsoleteMonthOnMonthCaches()
    }

    private fun databaseName(month: YearMonth): String =
        "$DB_PREFIX${month.year}_${month.monthValue.toString().padStart(2, '0')}$DB_SUFFIX"

    private fun databaseFile(month: YearMonth): File = context.getDatabasePath(databaseName(month))

    private fun helper(month: YearMonth, create: Boolean = true): MonthlyDb? {
        val cached = monthHelpers[month]
        if (cached != null) return cached
        if (!create && !databaseFile(month).exists()) return null
        val h = MonthlyDb(context, databaseName(month))
        monthHelpers[month] = h
        return h
    }

    private fun readable(month: YearMonth): SQLiteDatabase? = helper(month, false)?.readableDatabase
    private fun writable(month: YearMonth): SQLiteDatabase = helper(month, true)!!.writableDatabase

    private fun activeMonths(asOf: LocalDate = LocalDate.now()): List<YearMonth> = listOf(
        YearMonth.from(asOf),
        YearMonth.from(asOf).minusMonths(1)
    )

    private fun reportMonth(report: SimRegReport, now: LocalDate = LocalDate.now()): YearMonth? {
        val startMonth = report.coverageStart?.let(YearMonth::from)
        val endMonth = report.coverageEnd?.let(YearMonth::from)
        if (startMonth != null && endMonth != null && startMonth != endMonth) return null
        if (startMonth != null) return startMonth
        if (endMonth != null) return endMonth
        return report.rows.asSequence().flatMap { row ->
            (row.dailyByDate.keys.asSequence() + row.daily.keys.asSequence().mapNotNull {
                runCatching { LocalDate.of(now.year, now.monthValue, it) }.getOrNull()
            })
        }.map { YearMonth.from(it) }.firstOrNull()
    }

    /**
     * Import one HQ report as the authoritative snapshot for its calendar month.
     * Older reports are rejected; a report with the same coverage/end date is
     * accepted as a replacement; newer reports replace the whole month's snapshot
     * atomically. Reports for current and previous calendar months are independent.
     */
    @Synchronized
    fun importReport(report: SimRegReport): ImportResult {
        val started = System.nanoTime()
        val nowDate = LocalDate.now()
        val month = reportMonth(report, nowDate)
            ?: throw IllegalArgumentException("HQ report must belong to exactly one calendar month")
        val current = YearMonth.from(nowDate)
        val previous = current.minusMonths(1)
        require(month == current || month == previous) {
            "This report is for $month. DevMonitor stores only the current month ($current) and previous month ($previous)."
        }

        val incomingEnd = report.coverageEnd ?: report.rows.asSequence()
            .flatMap { it.dailyByDate.keys.asSequence() }
            .filter { YearMonth.from(it) == month }
            .maxOrNull()
            ?: throw IllegalArgumentException("HQ report has no usable coverage end date")

        if (YearMonth.from(incomingEnd) != month) {
            throw IllegalArgumentException("HQ report coverage end does not match its reporting month")
        }

        val db = writable(month)
        val existing = db.rawQuery(
            "SELECT id,coverage_end FROM company_reports ORDER BY imported_at DESC,id DESC LIMIT 1", null
        ).use { c ->
            if (!c.moveToFirst()) null
            else c.getLong(0) to c.getString(1)?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
        }

        if (existing != null) {
            val existingEnd = existing.second
            when {
                existingEnd != null && incomingEnd.isBefore(existingEnd) -> {
                    DevMonitorLogger.import("HQ import rejected older report month=$month incomingEnd=$incomingEnd existingEnd=$existingEnd")
                    throw IllegalArgumentException("Older HQ report rejected: $month already contains data through $existingEnd.")
                }
                existingEnd != null && incomingEnd == existingEnd -> {
                    // Same coverage date does not mean duplicate data. HQ can issue
                    // different complete report types with the same coverage end date.
                    // The later valid import therefore replaces the complete snapshot.
                    DevMonitorLogger.import("HQ import replacing same-coverage snapshot month=$month coverageEnd=$incomingEnd")
                }
            }
        }

        val source = if (report.isActivationReport) "ACTIVATIONS" else report.reportType
        val normalizedRows = ArrayList<Triple<String, LocalDate, Int>>()
        val deviceRows = LinkedHashMap<String, SimRegReportRow>()
        for (row in report.rows) {
            val device = canonicalDeviceCode(row.deviceId)
            if (device.isBlank()) continue
            deviceRows[device] = row.copy(deviceId = device)
            val dailyValues = if (row.dailyByDate.isNotEmpty()) row.dailyByDate else row.daily.mapNotNull { (day, count) ->
                runCatching { LocalDate.of(month.year, month.monthValue, day) }.getOrNull()?.let { it to count }
            }.toMap()
            dailyValues.forEach { (date, count) ->
                if (YearMonth.from(date) == month &&
                    (report.coverageStart == null || !date.isBefore(report.coverageStart)) &&
                    (report.coverageEnd == null || !date.isAfter(report.coverageEnd))) {
                    normalizedRows += Triple(device, date, count)
                }
            }
        }

        db.beginTransaction()
        var localReportId = 0L
        try {
            // HQ export is a complete monthly snapshot: clear everything from the
            // month before inserting the new snapshot. Missing devices therefore do
            // not leave stale records behind.
            db.delete("activation_days", null, null)
            db.delete("company_report_devices", null, null)
            db.delete("company_reports", null, null)

            db.execSQL(
                "INSERT INTO company_reports(source_name,report_type,coverage_start,coverage_end,imported_at) VALUES(?,?,?,?,?)",
                arrayOf(report.sourceName, source, report.coverageStart?.toString(), incomingEnd.toString(), System.currentTimeMillis())
            )
            db.rawQuery("SELECT last_insert_rowid()", null).use { c ->
                if (c.moveToFirst()) localReportId = c.getLong(0)
            }
            deviceRows.values.forEach { row ->
                val device = canonicalDeviceCode(row.deviceId)
                db.execSQL(
                    "INSERT INTO company_report_devices(report_id,device_id,trade_code,partner_name,cluster,region,territory,staff_name) VALUES(?,?,?,?,?,?,?,?)",
                    arrayOf(localReportId, device, row.tradeCode, row.partnerName, row.cluster, row.region, row.territory, row.staffName)
                )
            }
            normalizedRows.forEach { (device, date, count) ->
                db.execSQL(
                    "INSERT OR REPLACE INTO activation_days(device_id,activation_date,activation_count,source,report_id,imported_at) VALUES(?,?,?,?,?,?)",
                    arrayOf(device, date.toString(), count, source, localReportId, System.currentTimeMillis())
                )
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }

        val globalId = encodeReportId(month, localReportId)
        val elapsed = (System.nanoTime() - started) / 1_000_000L
        DevMonitorLogger.import(
            "monthly HQ snapshot IMPORTED month=$month end=$incomingEnd devices=${deviceRows.size} dailyRows=${normalizedRows.size} " +
                "replacedExisting=${existing != null} reportId=$globalId elapsedMs=$elapsed"
        )
        return ImportResult(
            reportId = globalId,
            inserted = normalizedRows.size,
            replaced = if (existing != null) normalizedRows.size else 0,
            deviceCount = deviceRows.size,
            updatedMessage = if (existing != null) "Replaced the previous HQ snapshot for $month with the newer verified report." else "Stored the verified HQ snapshot for $month."
        )
    }

    /** Latest hierarchy metadata across the two retained monthly snapshots. */
    fun latestDeviceScopeRows(): List<DeviceScopeRow> {
        val out = mutableListOf<DeviceScopeRow>()
        val seen = HashSet<String>()
        activeMonths().forEach { month ->
            readable(month)?.rawQuery(
                """SELECT d.device_id,d.trade_code,d.partner_name,d.cluster,d.region,d.territory,d.staff_name
                   FROM company_report_devices d JOIN company_reports r ON r.id=d.report_id
                   ORDER BY r.imported_at DESC,d.rowid ASC""".trimIndent(), null
            )?.use { c ->
                while (c.moveToNext()) {
                    val id = canonicalDeviceCode(c.getString(0).orEmpty())
                    if (id.isBlank() || !seen.add(id)) continue
                    out += DeviceScopeRow(id,c.getString(1).orEmpty(),c.getString(2).orEmpty(),c.getString(3).orEmpty(),c.getString(4).orEmpty(),c.getString(5).orEmpty(),c.getString(6).orEmpty())
                }
            }
        }
        return out
    }

    fun divisions(): List<String> = latestDeviceScopeRows().map { it.cluster.trim() }.filter { it.isNotBlank() }.distinct().sorted()
    fun regionsForDivision(division: String): List<String> = latestDeviceScopeRows().filter { it.cluster.equals(division.trim(), true) }.map { it.region.trim() }.filter { it.isNotBlank() }.distinct().sorted()
    fun staffForRegion(region: String): List<String> = latestDeviceScopeRows().filter { it.region.equals(region.trim(), true) }.map { it.staffName.trim() }.filter { it.isNotBlank() }.distinct().sorted()
    fun territoriesForStaff(region: String, staffName: String): List<String> = latestDeviceScopeRows().filter { it.region.equals(region.trim(), true) && it.staffName.equals(staffName.trim(), true) }.map { it.territory.trim() }.filter { it.isNotBlank() }.distinct().sorted()

    fun devicesForScope(userType: String, partnerCode: String = "", deviceId: String = "", staffLevel: String = "", division: String = "", region: String = "", staffName: String = "", territory: String = ""): List<String> {
        return latestDeviceScopeRows().filter { row ->
            when (userType.uppercase()) {
                "PARTNER" -> row.tradeCode.equals(partnerCode.trim(), true)
                "AGENT" -> canonicalDeviceCode(row.deviceId) == canonicalDeviceCode(deviceId)
                "STAFF" -> when (staffLevel.uppercase()) {
                    "CLUSTER HEAD" -> row.cluster.equals(division.trim(), true)
                    "REGIONAL MANAGER" -> row.region.equals(region.trim(), true) && (division.isBlank() || row.cluster.equals(division.trim(), true))
                    else -> row.staffName.equals(staffName.trim(), true) && (territory.isBlank() || row.territory.equals(territory.trim(), true)) && (region.isBlank() || row.region.equals(region.trim(), true))
                }
                else -> false
            }
        }.map { it.deviceId }.distinct()
    }

    fun listReports(): List<StoredReport> {
        val out = mutableListOf<StoredReport>()
        activeMonths().forEach { month ->
            readable(month)?.rawQuery(
                """SELECT r.id,r.source_name,r.report_type,r.coverage_start,r.coverage_end,r.imported_at,
                   (SELECT COUNT(*) FROM company_report_devices d WHERE d.report_id=r.id),
                   (SELECT COUNT(*) FROM activation_days a WHERE a.report_id=r.id)
                   FROM company_reports r ORDER BY r.imported_at DESC,r.id DESC""".trimIndent(), null
            )?.use { c ->
                while (c.moveToNext()) {
                    out += StoredReport(encodeReportId(month,c.getLong(0)),c.getString(1),c.getString(2),c.getString(3)?.let { runCatching { LocalDate.parse(it) }.getOrNull() },c.getString(4)?.let { runCatching { LocalDate.parse(it) }.getOrNull() },c.getLong(5),c.getInt(6),c.getInt(7))
                }
            }
        }
        return out.sortedWith(compareByDescending<StoredReport> { it.coverageEnd ?: it.coverageStart }.thenByDescending { it.importedAt })
    }

    fun latestReportImportedAtCovering(date: LocalDate): Long? = readable(YearMonth.from(date))?.rawQuery(
        "SELECT imported_at FROM company_reports WHERE coverage_start IS NOT NULL AND coverage_end IS NOT NULL AND coverage_start<=? AND coverage_end>=? ORDER BY imported_at DESC,id DESC LIMIT 1",
        arrayOf(date.toString(),date.toString())
    )?.use { if (it.moveToFirst()) it.getLong(0) else null }

    fun latestReportImportedAt(start: LocalDate, end: LocalDate): Long? {
        if (start.isAfter(end)) return null
        var best: Long? = null
        val first = YearMonth.from(start)
        val last = YearMonth.from(end)
        var month = first
        while (!month.isAfter(last)) {
            readable(month)?.rawQuery(
                "SELECT imported_at FROM company_reports WHERE coverage_start IS NOT NULL AND coverage_end IS NOT NULL AND coverage_start<=? AND coverage_end>=? ORDER BY imported_at DESC,id DESC LIMIT 1",
                arrayOf(end.toString(),start.toString())
            )?.use { if (it.moveToFirst()) best = maxOf(best ?: Long.MIN_VALUE,it.getLong(0)) }
            month = month.plusMonths(1)
        }
        return best
    }

    fun latestReportCoverageEnd(onOrBefore: LocalDate): LocalDate? {
        var best: LocalDate? = null
        activeMonths(onOrBefore).forEach { month ->
            readable(month)?.rawQuery(
                "SELECT coverage_end FROM company_reports WHERE coverage_end IS NOT NULL AND coverage_end<=? ORDER BY imported_at DESC,id DESC LIMIT 1",
                arrayOf(onOrBefore.toString())
            )?.use { c ->
                if (c.moveToFirst()) {
                    val d = c.getString(0)?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
                    if (d != null && (best == null || d.isAfter(best))) best = d
                }
            }
        }
        return best
    }

    fun latestReportForMonth(year: Int, month: Int): SimRegReport? {
        val ym = YearMonth.of(year,month)
        val db = readable(ym) ?: return null
        val localId = db.rawQuery("SELECT id FROM company_reports ORDER BY imported_at DESC,id DESC LIMIT 1",null).use { if (it.moveToFirst()) it.getLong(0) else null } ?: return null
        return loadReport(encodeReportId(ym,localId))
    }

    fun loadReport(reportId: Long): SimRegReport? {
        val decoded = decodeReportId(reportId) ?: return null
        val (month, localId) = decoded
        val db = readable(month) ?: return null
        var sourceName = "Normalized database report"
        var reportType = "ACTIVATIONS"
        var start: LocalDate? = null
        var end: LocalDate? = null
        db.rawQuery("SELECT source_name,report_type,coverage_start,coverage_end FROM company_reports WHERE id=?",arrayOf(localId.toString())).use { c ->
            if (!c.moveToFirst()) return null
            sourceName=c.getString(0); reportType=c.getString(1)
            start=c.getString(2)?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
            end=c.getString(3)?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
        }
        val rowsByDevice = linkedMapOf<String,SimRegReportRow>()
        db.rawQuery("SELECT device_id,trade_code,partner_name,cluster,region,territory,staff_name FROM company_report_devices WHERE report_id=? ORDER BY rowid",arrayOf(localId.toString())).use { c ->
            while(c.moveToNext()) rowsByDevice[c.getString(0)] = SimRegReportRow(c.getString(1).orEmpty(),c.getString(2).orEmpty(),c.getString(0),c.getString(3).orEmpty(),c.getString(4).orEmpty(),c.getString(5).orEmpty(),c.getString(6).orEmpty(),emptyMap(),0)
        }
        val dailyByDevice = linkedMapOf<String,MutableMap<Int,Int>>()
        db.rawQuery("SELECT device_id,activation_date,activation_count FROM activation_days WHERE report_id=? ORDER BY rowid",arrayOf(localId.toString())).use { c ->
            while(c.moveToNext()) {
                val date=runCatching{LocalDate.parse(c.getString(1))}.getOrNull() ?: continue
                dailyByDevice.getOrPut(c.getString(0)){linkedMapOf()}[date.dayOfMonth]=c.getInt(2)
            }
        }
        dailyByDevice.forEach { (id,daily) ->
            val old=rowsByDevice[id]
            rowsByDevice[id]=(old ?: SimRegReportRow("","",id,"","","","",emptyMap(),0)).copy(daily=daily,grandTotal=daily.values.sum())
        }
        return SimRegReport(sourceName,reportType,start,end,"Normalized monthly database",rowsByDevice.values.toList(),isContinuous=false)
    }

    fun deleteReport(reportId: Long) {
        val decoded=decodeReportId(reportId) ?: return
        val (month,localId)=decoded
        val db=readable(month) ?: return
        // The report is the monthly snapshot; deleting its metadata also removes its
        // complete monthly data. This operation is explicit in the report viewer.
        db.beginTransaction()
        try {
            db.delete("activation_days",null,null)
            db.delete("company_report_devices",null,null)
            db.delete("company_reports","id=?",arrayOf(localId.toString()))
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        DevMonitorLogger.db("monthly report DELETE month=$month reportId=$reportId")
    }

    fun loadWorkingSetForDevices(codes: List<String>, start: LocalDate, end: LocalDate): SimRegReport? {
        if (codes.isEmpty() || start.isAfter(end)) return null
        val normalized=codes.map(::canonicalDeviceCode).filter{it.isNotBlank()}.distinct()
        if(normalized.isEmpty()) return null
        val daily=mutableMapOf<String,MutableMap<LocalDate,Int>>()
        val meta=mutableMapOf<String,Array<String>>()
        var month=YearMonth.from(start)
        val last=YearMonth.from(end)
        while(!month.isAfter(last)) {
            val db=readable(month)
            if(db!=null) normalized.chunked(500).forEach { batch ->
                val ph=batch.joinToString(","){"?"}
                db.rawQuery("SELECT device_id,trade_code,partner_name,cluster,region,territory,staff_name FROM company_report_devices WHERE device_id IN ($ph) ORDER BY report_id DESC",batch.toTypedArray()).use { c ->
                    while(c.moveToNext()){val id=canonicalDeviceCode(c.getString(0).orEmpty()); if(!meta.containsKey(id)) meta[id]=arrayOf(c.getString(1).orEmpty(),c.getString(2).orEmpty(),c.getString(3).orEmpty(),c.getString(4).orEmpty(),c.getString(5).orEmpty(),c.getString(6).orEmpty())}
                }
                val args=ArrayList<String>(batch.size+2);args+=maxOf(start,month.atDay(1)).toString();args+=minOf(end,month.atEndOfMonth()).toString();args.addAll(batch)
                db.rawQuery("SELECT device_id,activation_date,activation_count FROM activation_days WHERE activation_date BETWEEN ? AND ? AND device_id IN ($ph) ORDER BY activation_date",args.toTypedArray()).use { c -> while(c.moveToNext()){val id=c.getString(0);val d=runCatching{LocalDate.parse(c.getString(1))}.getOrNull()?:continue;daily.getOrPut(id){linkedMapOf()}[d]=c.getInt(2)} }
            }
            month=month.plusMonths(1)
        }
        val rows=normalized.map{ id -> val m=meta[id]?:arrayOf("","","","","",""); val by=daily[id].orEmpty(); SimRegReportRow(m[0],m[1],id,m[2],m[3],m[4],m[5],emptyMap(),by.values.sum(),by) }
        return SimRegReport("My Devices working set","ACTIVATIONS",start,end,"My Devices",rows,isContinuous=true)
    }

    fun setDeviceMonitorStore(store: DatabaseStore) = monthOnMonthStore.setDeviceMonitorStore(store)

    /** Retained for source compatibility. Month-to-Month now reads the two monthly HQ stores directly. */
    fun acceptMonthOnMonthReport(report: SimRegReport, myDeviceCodes: List<String>, now: LocalDate = LocalDate.now()): String =
        "Month-to-Month uses the two physical monthly HQ stores; no duplicate import is performed."

    /** Retained for source compatibility; this is a calculation/refresh-layer action, not an import action. */
    fun refreshMonthOnMonthMyDevices(myDeviceCodes: List<String>) {
        DevMonitorLogger.db("Month-to-Month My Devices refresh uses monthly HQ stores directly; codes=${myDeviceCodes.size}")
    }

    fun searchMonthToMonth(query: String, asOf: LocalDate = LocalDate.now(), limit: Int = 100): List<MonthOnMonthStore.SearchHit> =
        monthOnMonthStore.search(this,query,asOf,limit)

    fun monthToMonthComparison(userType: String, staffLevel: String, partnerCode: String, deviceId: String, division: String, region: String, staffName: String, territory: String, currentCodes: List<String>, asOf: LocalDate = LocalDate.now(), restrictToCodes: Boolean = false): MonthToMonthComparison? {
        val codes=currentCodes.map(::canonicalDeviceCode).filter{it.isNotBlank()}.distinct()
        if(restrictToCodes && codes.isEmpty()) return null
        val result=monthOnMonthStore.compare(this,codes,asOf) ?: return null
        return MonthToMonthComparison(result.asOf,result.currentTotal,result.previousTotal,result.delta,result.percentChange)
    }

    fun loadCurrentMonthReport(asOfRequested: LocalDate = LocalDate.now()): SimRegReport? {
        val asOf=PaymentRules.currentAwareDate(asOfRequested)
        val currentMonth=YearMonth.from(asOf)
        val selected=latestReportForMonth(currentMonth.year,currentMonth.monthValue)
            ?: latestReportForMonth(currentMonth.minusMonths(1).year,currentMonth.minusMonths(1).monthValue)
        return selected?.let { report ->
            val selectedMonth=report.coverageStart?.let(YearMonth::from) ?: report.coverageEnd?.let(YearMonth::from)
            val upper=if(selectedMonth==currentMonth) asOf else selectedMonth?.atEndOfMonth() ?: asOf
            val rows=report.rows.mapNotNull { row ->
                val by=row.dailyByDate.filterKeys{ !it.isAfter(upper) }
                if(by.isEmpty()) null else row.copy(dailyByDate=by,daily=by.mapKeys{it.key.dayOfMonth},grandTotal=by.values.sum())
            }
            if(rows.isEmpty()) null else report.copy(coverageEnd = minOf(report.coverageEnd ?: upper, upper), rows=rows)
        }
    }

    fun loadContinuousReport(): SimRegReport? {
        val rowsByDevice=linkedMapOf<String,MutableMap<LocalDate,Int>>()
        val meta=linkedMapOf<String,Array<String?>>()
        var first:LocalDate?=null; var last:LocalDate?=null
        activeMonths().sorted().forEach { month ->
            val db=readable(month) ?: return@forEach
            db.rawQuery("SELECT device_id,trade_code,partner_name,cluster,region,territory,staff_name FROM company_report_devices ORDER BY rowid",null).use { c -> while(c.moveToNext()){val id=c.getString(0); if(!meta.containsKey(id)) meta[id]=arrayOf(c.getString(1),c.getString(2),c.getString(3),c.getString(4),c.getString(5),c.getString(6))} }
            db.rawQuery("SELECT device_id,activation_date,activation_count FROM activation_days ORDER BY activation_date,rowid",null).use { c -> while(c.moveToNext()){val d=runCatching{LocalDate.parse(c.getString(1))}.getOrNull()?:continue; if(first==null||d.isBefore(first))first=d;if(last==null||d.isAfter(last))last=d;rowsByDevice.getOrPut(c.getString(0)){linkedMapOf()}[d]=c.getInt(2)} }
        }
        if(first==null||last==null) return null
        val ids=buildList{addAll(meta.keys);rowsByDevice.keys.filterNot{meta.containsKey(it)}.forEach{add(it)}}
        val rows=ids.map{ id -> val m=meta[id]?:arrayOf<String?>(null,null,null,null,null,null);val by=rowsByDevice[id].orEmpty();SimRegReportRow(m[0].orEmpty(),m[1].orEmpty(),id,m[2].orEmpty(),m[3].orEmpty(),m[4].orEmpty(),m[5].orEmpty(),emptyMap(),by.values.sum(),by)}
        return SimRegReport("Two-month HQ database","ACTIVATIONS",first,last,"Two monthly databases",rows,true)
    }

    fun cycleContributions(deviceId: String, date: LocalDate = LocalDate.now()): List<CycleContribution> {
        val asOf=PaymentRules.currentAwareDate(date);val code=canonicalDeviceCode(deviceId);val start=PaymentRules.paymentCycleForDate(asOf).first;val out=mutableListOf<CycleContribution>()
        var month=YearMonth.from(start);val last=YearMonth.from(asOf)
        while(!month.isAfter(last)) { readable(month)?.rawQuery("SELECT r.id,r.source_name,r.coverage_start,r.coverage_end,SUM(a.activation_count) FROM activation_days a JOIN company_reports r ON r.id=a.report_id WHERE a.device_id=? AND a.activation_date BETWEEN ? AND ? GROUP BY r.id,r.source_name,r.coverage_start,r.coverage_end",arrayOf(code,start.toString(),asOf.toString())).useIfNotNull { c -> while(c.moveToNext()) out+=CycleContribution(encodeReportId(month,c.getLong(0)),c.getString(1),c.getString(2)?.let{runCatching{LocalDate.parse(it)}.getOrNull()},c.getString(3)?.let{runCatching{LocalDate.parse(it)}.getOrNull()},c.getInt(4)) }; month=month.plusMonths(1) }
        return out
    }

    fun dailyCoverageForDevice(deviceId: String, start: LocalDate, end: LocalDate): Map<LocalDate,Int> {
        if(start.isAfter(end)) return emptyMap();val code=canonicalDeviceCode(deviceId);val out=linkedMapOf<LocalDate,Int>();var month=YearMonth.from(start);val last=YearMonth.from(end)
        while(!month.isAfter(last)){readable(month)?.rawQuery("SELECT activation_date,activation_count FROM activation_days WHERE device_id=? AND activation_date BETWEEN ? AND ? ORDER BY activation_date",arrayOf(code,start.toString(),end.toString())).useIfNotNull{c->while(c.moveToNext()){val d=runCatching{LocalDate.parse(c.getString(0))}.getOrNull()?:continue;out[d]=c.getInt(1)}};month=month.plusMonths(1)};return out
    }

    fun hasReportCoverage(date: LocalDate): Boolean = readable(YearMonth.from(date))?.rawQuery("SELECT 1 FROM company_reports WHERE coverage_start IS NOT NULL AND coverage_end IS NOT NULL AND coverage_start<=? AND coverage_end>=? LIMIT 1",arrayOf(date.toString(),date.toString())).useIfNotNull { it.moveToFirst() } ?: false

    fun hasCompleteDeviceCoverage(deviceId: String,start: LocalDate,end: LocalDate): Boolean {
        if(start.isAfter(end)) return true;val expected=java.time.temporal.ChronoUnit.DAYS.between(start,end)+1;val actual=dailyCoverageForDevice(deviceId,start,end).keys.size;return actual.toLong()==expected
    }

    fun hasCompleteReportCoverage(start: LocalDate,end: LocalDate): Boolean { if(start.isAfter(end)) return true;var d=start;while(!d.isAfter(end)){if(!hasReportCoverage(d))return false;d=d.plusDays(1)};return true }

    fun paymentBaselineActiveFromLoadedReport(deviceId: String,monthStart: LocalDate,boundary: LocalDate): Int? {
        if(boundary.isBefore(monthStart)) return null;val code=canonicalDeviceCode(deviceId);val month=YearMonth.from(monthStart);val db=readable(month)?:return null
        val hasReport=db.rawQuery("SELECT 1 FROM company_reports r JOIN company_report_devices d ON d.report_id=r.id WHERE d.device_id=? AND r.coverage_start<=? AND r.coverage_end>=? LIMIT 1",arrayOf(code,monthStart.toString(),boundary.toString())).use{it.moveToFirst()};if(!hasReport)return null
        return db.rawQuery("SELECT COALESCE(SUM(activation_count),0) FROM activation_days WHERE device_id=? AND activation_date BETWEEN ? AND ?",arrayOf(code,monthStart.toString(),boundary.toString())).use{if(it.moveToFirst())it.getInt(0) else 0}
    }

    fun activationCountForDate(deviceId: String,date: LocalDate=LocalDate.now()):Int?{val asOf=PaymentRules.currentAwareDate(date);return readable(YearMonth.from(asOf))?.rawQuery("SELECT SUM(activation_count) FROM activation_days WHERE device_id=? AND activation_date=?",arrayOf(canonicalDeviceCode(deviceId),asOf.toString())).useIfNotNull{c->if(c.moveToFirst()&&!c.isNull(0))c.getInt(0)else null}}

    fun cycleTotal(deviceId: String,date: LocalDate=LocalDate.now()):Int?{val asOf=PaymentRules.currentAwareDate(date);val code=canonicalDeviceCode(deviceId);val start=PaymentRules.paymentCycleForDate(asOf).first;val values=dailyCoverageForDevice(code,start,asOf);if(values.isNotEmpty())return values.values.sum();return if(hasAnyHistory(code))0 else null}

    fun cycleSundayActivations(deviceId:String,date:LocalDate=LocalDate.now()):Int{val asOf=PaymentRules.currentAwareDate(date);val start=PaymentRules.paymentCycleForDate(asOf).first;return dailyCoverageForDevice(deviceId,start,asOf).filter{it.key.dayOfWeek.value==7}.filter{it.value>=PaymentRules.SUNDAY_MIN_ACTIVATIONS}.values.sum()}

    fun hasAnyHistory(deviceId:String):Boolean{val code=canonicalDeviceCode(deviceId);return activeMonths().any{readable(it)?.rawQuery("SELECT 1 FROM activation_days WHERE device_id=? LIMIT 1",arrayOf(code)).useIfNotNull{c->c.moveToFirst()}==true}}

    fun historicalBridgeForDevice(deviceId:String,referenceDate:LocalDate=LocalDate.now()):DeviceHistoricalBridge?{val asOf=PaymentRules.currentAwareDate(referenceDate);val month=YearMonth.from(asOf).minusMonths(1);val start=month.atDay(21);val end=month.atEndOfMonth();val code=canonicalDeviceCode(deviceId);val db=readable(month)?:return null;return db.rawQuery("SELECT MIN(activation_date),MAX(activation_date),SUM(activation_count),(SELECT a2.report_id FROM activation_days a2 WHERE a2.device_id=? AND a2.activation_date BETWEEN ? AND ? ORDER BY a2.imported_at DESC,a2.report_id DESC LIMIT 1) FROM activation_days WHERE device_id=? AND activation_date BETWEEN ? AND ?",arrayOf(code,start.toString(),end.toString(),code,start.toString(),end.toString())).use{c->if(!c.moveToFirst()||c.isNull(2))null else DeviceHistoricalBridge(code,month,c.getString(0)?.let{LocalDate.parse(it)}?:start,c.getString(1)?.let{LocalDate.parse(it)}?:end,c.getInt(2),if(c.isNull(3))0L else encodeReportId(month,c.getLong(3)))}}

    fun historicalBridgeRows(reportId:Long,coverageEnd:LocalDate?):List<Triple<String,String,Int>>{if(coverageEnd==null)return emptyList();val month=YearMonth.from(coverageEnd);val start=month.atDay(21);val db=readable(month)?:return emptyList();val out=mutableListOf<Triple<String,String,Int>>();db.rawQuery("SELECT device_id,SUM(activation_count) FROM activation_days WHERE activation_date BETWEEN ? AND ? GROUP BY device_id",arrayOf(start.toString(),coverageEnd.toString())).use{c->while(c.moveToNext())if(!c.isNull(1))out+=Triple(c.getString(0),month.toString(),c.getInt(1))};return out}

    fun closeStore()=close()

    fun close(){monthHelpers.values.forEach{runCatching{it.close()}};monthHelpers.clear();runCatching{monthOnMonthStore.close()}}

    private fun encodeReportId(month: YearMonth, localId: Long): Long =
        (epochMonth(month) shl 32) or (localId and 0xffffffffL)

    private fun epochMonth(month: YearMonth): Long =
        month.year.toLong() * 12L + (month.monthValue - 1L)

    private fun decodeReportId(id: Long): Pair<YearMonth,Long>? {
        if(id<=0L)return null
        val epoch=id ushr 32
        val local=id and 0xffffffffL
        val year=Math.floorDiv(epoch,12L).toInt()
        val month=(Math.floorMod(epoch,12L)+1L).toInt()
        return runCatching{YearMonth.of(year,month)}.getOrNull()?.let{it to local}
    }

    /** Migrate the former rolling database into the two current monthly files once. */
    private fun migrateLegacyDatabaseIfNeeded() {
        val legacyFile = context.getDatabasePath(LEGACY_DB_NAME)
        if (!legacyFile.exists()) return
        val current = YearMonth.from(LocalDate.now())
        val previous = current.minusMonths(1)
        val legacy = runCatching {
            SQLiteDatabase.openDatabase(legacyFile.path, null, SQLiteDatabase.OPEN_READONLY)
        }.getOrNull() ?: return
        try {
            val hasReports = legacy.rawQuery(
                "SELECT name FROM sqlite_master WHERE type='table' AND name='company_reports'", null
            ).use { it.moveToFirst() }
            if (!hasReports) return

            listOf(current, previous).forEach { month ->
                val targetFile = databaseFile(month)
                if (targetFile.exists()) return@forEach
                val report = legacy.rawQuery(
                    """SELECT id,source_name,report_type,coverage_start,coverage_end,imported_at
                       FROM company_reports
                       WHERE (coverage_start IS NOT NULL AND substr(coverage_start,1,7)=?)
                          OR (coverage_end IS NOT NULL AND substr(coverage_end,1,7)=?)
                       ORDER BY imported_at DESC,id DESC LIMIT 1""".trimIndent(),
                    arrayOf(month.toString(), month.toString())
                ).use { c ->
                    if (!c.moveToFirst()) null
                    else arrayOf<Any?>(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),c.getString(4),c.getLong(5))
                } ?: return@forEach

                val oldReportId = report[0] as Long
                val target = writable(month)
                target.beginTransaction()
                try {
                    target.execSQL(
                        "INSERT INTO company_reports(source_name,report_type,coverage_start,coverage_end,imported_at) VALUES(?,?,?,?,?)",
                        arrayOf(report[1],report[2],report[3],report[4],report[5])
                    )
                    var newReportId = 0L
                    target.rawQuery("SELECT last_insert_rowid()",null).use { if(it.moveToFirst()) newReportId=it.getLong(0) }

                    // The old normalized table already contains the final value for
                    // each device/date. Assign those final monthly values to the new
                    // monthly snapshot instead of recreating the old multi-report merge.
                    legacy.rawQuery(
                        "SELECT device_id,activation_date,activation_count,source,imported_at FROM activation_days WHERE activation_date>=? AND activation_date<=?",
                        arrayOf(month.atDay(1).toString(),month.atEndOfMonth().toString())
                    ).use { c ->
                        while(c.moveToNext()) target.execSQL(
                            "INSERT OR REPLACE INTO activation_days(device_id,activation_date,activation_count,source,report_id,imported_at) VALUES(?,?,?,?,?,?)",
                            arrayOf(c.getString(0),c.getString(1),c.getInt(2),c.getString(3),newReportId,c.getLong(4))
                        )
                    }
                    legacy.rawQuery(
                        "SELECT device_id,trade_code,partner_name,cluster,region,territory,staff_name FROM company_report_devices WHERE report_id=?",
                        arrayOf(oldReportId.toString())
                    ).use { c ->
                        while(c.moveToNext()) target.execSQL(
                            "INSERT OR REPLACE INTO company_report_devices(report_id,device_id,trade_code,partner_name,cluster,region,territory,staff_name) VALUES(?,?,?,?,?,?,?,?)",
                            arrayOf(newReportId,c.getString(0),c.getString(1),c.getString(2),c.getString(3),c.getString(4),c.getString(5),c.getString(6))
                        )
                    }
                    target.setTransactionSuccessful()
                } finally { target.endTransaction() }
            }
            legacy.close()
            runCatching { legacyFile.delete() }
            DevMonitorLogger.db("migrated legacy company activation database into two physical monthly HQ stores")
        } finally { if(legacy.isOpen) legacy.close() }
    }

    /** Old Month-on-Month caches are derived data and are no longer part of storage. */
    private fun removeObsoleteMonthOnMonthCaches() {
        listOf("devmonitor_mom_previous.db","devmonitor_mom_previous_my_devices.db","devmonitor_mom_current.db","devmonitor_mom_current_my_devices.db").forEach { name ->
            val f=context.getDatabasePath(name)
            if(f.exists())runCatching{f.delete()}
            runCatching{File(f.path+"-wal").delete()};runCatching{File(f.path+"-shm").delete()}
        }
    }

    private inline fun <T> android.database.Cursor?.useIfNotNull(block:(android.database.Cursor)->T):T? {
        if(this==null)return null
        return use(block)
    }
}
