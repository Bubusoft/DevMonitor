package com.aziitech.simregmonitor

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.time.LocalDate
import java.time.YearMonth
import java.util.Locale

/**
 * Company/HQ activation history. This database is deliberately separate from
 * DatabaseStore, which is profile-scoped and remains the operational Device Monitor database.
 */
class CompanyActivationStore(private val context: Context) :
    SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {

    private val monthOnMonthStore by lazy { MonthOnMonthStore(context) }

    companion object {
        private const val DB_NAME = "fieldpulse_company_activations.db"
        private const val DB_VERSION = 3
        private const val RETENTION_MONTHS = 2L
    }

    data class ImportResult(
        val reportId: Long,
        val inserted: Int,
        val replaced: Int,
        val deviceCount: Int,
        val updatedMessage: String?
    )

    data class CycleContribution(
        val reportId: Long,
        val sourceName: String,
        val coverageStart: LocalDate?,
        val coverageEnd: LocalDate?,
        val activationCount: Int
    )

    data class StoredReport(
        val id: Long,
        val sourceName: String,
        val reportType: String,
        val coverageStart: LocalDate?,
        val coverageEnd: LocalDate?,
        val importedAt: Long,
        val deviceCount: Int,
        val dayCount: Int
    )

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE company_reports(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source_name TEXT NOT NULL,
            report_type TEXT NOT NULL,
            coverage_start TEXT,
            coverage_end TEXT,
            imported_at INTEGER NOT NULL
        )""")
        db.execSQL("""CREATE TABLE company_report_devices(
            report_id INTEGER NOT NULL,
            device_id TEXT NOT NULL,
            trade_code TEXT,
            partner_name TEXT,
            cluster TEXT,
            region TEXT,
            territory TEXT,
            staff_name TEXT,
            PRIMARY KEY(report_id, device_id),
            FOREIGN KEY(report_id) REFERENCES company_reports(id) ON DELETE CASCADE
        )""")
        db.execSQL("""CREATE TABLE activation_days(
            device_id TEXT NOT NULL,
            activation_date TEXT NOT NULL,
            activation_count INTEGER NOT NULL,
            source TEXT NOT NULL,
            report_id INTEGER NOT NULL,
            imported_at INTEGER NOT NULL,
            PRIMARY KEY(device_id, activation_date),
            FOREIGN KEY(report_id) REFERENCES company_reports(id) ON DELETE CASCADE
        )""")
        db.execSQL("CREATE INDEX idx_company_reports_imported ON company_reports(imported_at)")
        db.execSQL("CREATE INDEX idx_company_activation_date ON activation_days(activation_date)")
        db.execSQL("CREATE INDEX idx_company_activation_device ON activation_days(device_id)")
        db.execSQL("CREATE INDEX idx_company_activation_report ON activation_days(report_id)")
        db.execSQL("CREATE INDEX idx_company_report_devices_device ON company_report_devices(device_id)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("DROP TABLE IF EXISTS device_monitor_historical_snapshot")
        }
        // Version 3 keeps the normalized daily table as the durable continuous
        // dataset. Existing activation rows are deliberately preserved.
        if (oldVersion < 3) {
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_company_activation_device_date ON activation_days(device_id,activation_date)")
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_company_activation_report ON activation_days(report_id)")
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_company_report_devices_device ON company_report_devices(device_id)")
        }
    }

    fun importReport(report: SimRegReport): ImportResult {
        val importStartedNanos = System.nanoTime()
        DevMonitorLogger.import("normalized import START source=\"${report.sourceName}\" type=${report.reportType} start=${report.coverageStart} end=${report.coverageEnd} rows=${report.rows.size}")
        val db = writableDatabase
        val now = System.currentTimeMillis()
        var inserted = 0
        var replaced = 0
        var skippedSettled = 0
        var reportId = 0L
        val source = if (report.isActivationReport) "ACTIVATIONS" else report.reportType
        db.beginTransaction()
        try {
            // Exact re-imports are idempotent: do not create another inventory record.
            val existingReportId = db.rawQuery(
                "SELECT id FROM company_reports WHERE source_name=? AND report_type=? AND " +
                    "coverage_start IS ? AND coverage_end IS ? ORDER BY imported_at DESC, id DESC LIMIT 1",
                arrayOf(report.sourceName, source, report.coverageStart?.toString(), report.coverageEnd?.toString())
            ).use { c -> if (c.moveToFirst()) c.getLong(0) else null }
            reportId = existingReportId ?: run {
                db.execSQL(
                    "INSERT INTO company_reports(source_name,report_type,coverage_start,coverage_end,imported_at) VALUES(?,?,?,?,?)",
                    arrayOf(report.sourceName, source, report.coverageStart?.toString(), report.coverageEnd?.toString(), now)
                )
                db.rawQuery("SELECT last_insert_rowid()", null).use { c -> if (c.moveToFirst()) c.getLong(0) else 0L }
            }
            if (existingReportId != null) {
                db.execSQL("UPDATE company_reports SET imported_at=? WHERE id=?", arrayOf(now, reportId))
                DevMonitorLogger.import("duplicate import detected; reusing reportId=$reportId")
            }

            // First normalize the incoming report into device/date rows. Reports are
            // normally month-to-date (1st..cutoff), so coverageEnd is the useful
            // reference point for deciding whether older normalized dates are settled.
            val normalizedRows = ArrayList<Triple<String, LocalDate, Int>>()
            val deviceCodes = LinkedHashSet<String>()

            for (row in report.rows) {
                val device = canonicalDeviceCode(row.deviceId)
                if (device.isBlank()) continue
                deviceCodes += device
                db.execSQL(
                    "INSERT OR REPLACE INTO company_report_devices(report_id,device_id,trade_code,partner_name,cluster,region,territory,staff_name) VALUES(?,?,?,?,?,?,?,?)",
                    arrayOf(reportId, device, row.tradeCode, row.partnerName, row.cluster, row.region, row.territory, row.staffName)
                )

                // Never persist daily cells outside the report's declared coverage.
                // XLSX files commonly carry empty/zero columns for the rest of the month
                // even when the report is explicitly MTD (for example a Sep 1-23 report
                // can still contain columns 24-31). Those cells are not available data and
                // must not move the normalized frontier or Month-on-Month cutoff forward.
                val dateValues: Map<LocalDate, Int> = if (row.dailyByDate.isNotEmpty()) {
                    row.dailyByDate.filter { (date, _) ->
                        (report.coverageStart == null || !date.isBefore(report.coverageStart)) &&
                            (report.coverageEnd == null || !date.isAfter(report.coverageEnd))
                    }
                } else {
                    val start = report.coverageStart
                    val end = report.coverageEnd
                    row.daily.mapNotNull { (day, count) ->
                        val date = if (start != null && end != null) {
                            runCatching { LocalDate.of(end.year, end.month, day) }.getOrNull()
                        } else null
                        if (date != null && (start == null || !date.isBefore(start)) && (end == null || !date.isAfter(end))) date to count else null
                    }.toMap()
                }
                for ((date, count) in dateValues) {
                    normalizedRows += Triple(device, date, count)
                }
            }

            // The normalized database is a rolling three-calendar-month archive.
            // Imports are date-addressable, so an older month must still be accepted
            // after a newer month has already been imported.  The previous importer
            // treated the newest normalized date as a frontier and rejected older
            // reports; that made August disappear as soon as September existed.
            //
            // For overlapping dates, preserve the report with the newer coverage end.
            // This lets a full-month report supersede an earlier MTD snapshot while
            // still allowing a late import for an older month to fill its own dates.
            val incomingEnd = report.coverageEnd ?: normalizedRows.maxOfOrNull { it.second }
            data class ExistingCell(val count: Int, val coverageEnd: LocalDate?)
            val existing = HashMap<String, ExistingCell>(normalizedRows.size)
            val lookupStart = normalizedRows.minOfOrNull { it.second }
            val lookupEnd = normalizedRows.maxOfOrNull { it.second }
            if (lookupStart != null && lookupEnd != null && deviceCodes.isNotEmpty()) {
                deviceCodes.chunked(500).forEach { batch ->
                    val placeholders = batch.joinToString(",") { "?" }
                    val args = ArrayList<String>(batch.size + 2)
                    args += lookupStart.toString()
                    args += lookupEnd.toString()
                    args.addAll(batch)
                    db.rawQuery(
                        "SELECT a.device_id,a.activation_date,a.activation_count,r.coverage_end " +
                            "FROM activation_days a LEFT JOIN company_reports r ON r.id=a.report_id " +
                            "WHERE a.activation_date BETWEEN ? AND ? AND a.device_id IN ($placeholders)",
                        args.toTypedArray()
                    ).use { c ->
                        while (c.moveToNext()) {
                            val device = c.getString(0)
                            val date = c.getString(1)
                            val count = c.getInt(2)
                            val end = c.getString(3)?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
                            existing["$device|$date"] = ExistingCell(count, end)
                        }
                    }
                }
            }

            for ((device, date, count) in normalizedRows) {
                val key = "$device|$date"
                val old = existing[key]
                val oldEnd = old?.coverageEnd
                // A report with a later coverage end is the more complete snapshot
                // for an overlapping date. Do not let an older late import roll it back.
                if (old != null && oldEnd != null && incomingEnd != null && oldEnd.isAfter(incomingEnd)) {
                    skippedSettled++
                    continue
                }
                db.execSQL(
                    "INSERT OR REPLACE INTO activation_days(device_id,activation_date,activation_count,source,report_id,imported_at) VALUES(?,?,?,?,?,?)",
                    arrayOf(device, date.toString(), count, source, reportId, now)
                )
                if (old == null) inserted++ else if (old.count != count || oldEnd != incomingEnd) replaced++
            }
            pruneOldData(db)
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        val message = when {
            skippedSettled > 0 && replaced == 0 && inserted == 0 -> "Older report data was retained without replacing newer, more complete dates."
            replaced > 0 -> "Some activation values were updated based on the newer report."
            else -> null
        }
        val importElapsedMs = (System.nanoTime() - importStartedNanos) / 1_000_000L
        DevMonitorLogger.import(
            "normalized import DONE reportId=$reportId inserted=$inserted replaced=$replaced skippedSettled=$skippedSettled " +
                "devices=${report.rows.size} coverage=${report.coverageStart}..${report.coverageEnd} elapsedMs=$importElapsedMs"
        )
        return ImportResult(reportId, inserted, replaced, report.rows.size, message)
    }

    private fun pruneOldData(db: SQLiteDatabase) {
        val currentMonth = YearMonth.from(LocalDate.now())
        val cutoffDate = currentMonth.minusMonths(RETENTION_MONTHS).atDay(1)
        val cutoff = cutoffDate.toString()
        db.delete("activation_days", "activation_date<?", arrayOf(cutoff))

        // Keep report metadata even when all of its daily rows have later been
        // replaced by a newer report. The report list is a persistence audit
        // and must not disappear merely because its values were superseded.
        db.execSQL(
            "DELETE FROM company_report_devices WHERE report_id IN (" +
                "SELECT id FROM company_reports WHERE " +
                "(coverage_end IS NOT NULL AND coverage_end<?) OR " +
                "(coverage_end IS NULL AND imported_at<?))",
            arrayOf(cutoff, cutoffDate.atStartOfDay(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli())
        )
        db.execSQL(
            "DELETE FROM company_reports WHERE " +
                "(coverage_end IS NOT NULL AND coverage_end<?) OR " +
                "(coverage_end IS NULL AND imported_at<?)",
            arrayOf(cutoff, cutoffDate.atStartOfDay(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli())
        )
    }

    data class DeviceScopeRow(
        val deviceId: String,
        val tradeCode: String,
        val partnerName: String,
        val cluster: String,
        val region: String,
        val territory: String,
        val staffName: String
    )

    /** Latest known hierarchy metadata for each device, newest imported report first. */
    fun latestDeviceScopeRows(): List<DeviceScopeRow> {
        val out = mutableListOf<DeviceScopeRow>()
        val seen = HashSet<String>()
        readableDatabase.rawQuery(
            """SELECT d.device_id,d.trade_code,d.partner_name,d.cluster,d.region,d.territory,d.staff_name
               FROM company_report_devices d JOIN company_reports r ON r.id=d.report_id
               ORDER BY COALESCE(r.coverage_end,'0000-00-00') DESC, r.imported_at DESC, r.id DESC, d.rowid ASC""".trimIndent(), null
        ).use { c ->
            while (c.moveToNext()) {
                val id = canonicalDeviceCode(c.getString(0).orEmpty())
                if (id.isBlank() || !seen.add(id)) continue
                out += DeviceScopeRow(
                    id, c.getString(1).orEmpty(), c.getString(2).orEmpty(),
                    c.getString(3).orEmpty(), c.getString(4).orEmpty(),
                    c.getString(5).orEmpty(), c.getString(6).orEmpty()
                )
            }
        }
        return out
    }

    fun divisions(): List<String> = latestDeviceScopeRows().map { it.cluster.trim() }.filter { it.isNotBlank() }.distinct().sorted()

    fun regionsForDivision(division: String): List<String> = latestDeviceScopeRows()
        .filter { it.cluster.equals(division.trim(), ignoreCase = true) }
        .map { it.region.trim() }.filter { it.isNotBlank() }.distinct().sorted()

    fun staffForRegion(region: String): List<String> = latestDeviceScopeRows()
        .filter { it.region.equals(region.trim(), ignoreCase = true) }
        .map { it.staffName.trim() }.filter { it.isNotBlank() }.distinct().sorted()

    fun territoriesForStaff(region: String, staffName: String): List<String> = latestDeviceScopeRows()
        .filter { it.region.equals(region.trim(), ignoreCase = true) && it.staffName.equals(staffName.trim(), ignoreCase = true) }
        .map { it.territory.trim() }.filter { it.isNotBlank() }.distinct().sorted()

    fun devicesForScope(
        userType: String,
        partnerCode: String = "",
        deviceId: String = "",
        staffLevel: String = "",
        division: String = "",
        region: String = "",
        staffName: String = "",
        territory: String = ""
    ): List<String> {
        val rows = latestDeviceScopeRows()
        return rows.filter { row ->
            when (userType.uppercase()) {
                "PARTNER" -> row.tradeCode.equals(partnerCode.trim(), ignoreCase = true)
                "AGENT" -> canonicalDeviceCode(row.deviceId) == canonicalDeviceCode(deviceId)
                "STAFF" -> when (staffLevel.uppercase()) {
                    "CLUSTER HEAD" -> row.cluster.equals(division.trim(), ignoreCase = true)
                    "REGIONAL MANAGER" -> row.region.equals(region.trim(), ignoreCase = true) &&
                        (division.isBlank() || row.cluster.equals(division.trim(), ignoreCase = true))
                    else -> row.staffName.equals(staffName.trim(), ignoreCase = true) &&
                        (territory.isBlank() || row.territory.equals(territory.trim(), ignoreCase = true)) &&
                        (region.isBlank() || row.region.equals(region.trim(), ignoreCase = true))
                }
                else -> false
            }
        }.map { it.deviceId }.distinct()
    }

    fun listReports(): List<StoredReport> {
        val out = mutableListOf<StoredReport>()
        readableDatabase.rawQuery(
            """
            SELECT r.id,r.source_name,r.report_type,r.coverage_start,r.coverage_end,r.imported_at,
                   (SELECT COUNT(*) FROM company_report_devices d WHERE d.report_id=r.id),
                   (SELECT COUNT(*) FROM activation_days a WHERE a.report_id=r.id)
            FROM company_reports r
            ORDER BY COALESCE(r.coverage_start,r.coverage_end) DESC, r.imported_at DESC, r.id DESC
            """.trimIndent(),
            null
        ).use { c ->
            while (c.moveToNext()) {
                out += StoredReport(
                    id = c.getLong(0),
                    sourceName = c.getString(1),
                    reportType = c.getString(2),
                    coverageStart = c.getString(3)?.let { runCatching { LocalDate.parse(it) }.getOrNull() },
                    coverageEnd = c.getString(4)?.let { runCatching { LocalDate.parse(it) }.getOrNull() },
                    importedAt = c.getLong(5),
                    deviceCount = c.getInt(6),
                    dayCount = c.getInt(7)
                )
            }
        }
        DevMonitorLogger.db("report inventory count=${out.size}")
        return out
    }

    /**
     * Returns the coverage end of the most recently imported report whose
     * coverage end is not after the supplied live date. This is metadata-only
     * and is used by the Device Monitor payment-card gate.
     */
    /** Latest import timestamp for reports overlapping the requested date range. */
    fun latestReportImportedAt(start: LocalDate, end: LocalDate): Long? {
        if (start.isAfter(end)) return null
        return readableDatabase.rawQuery(
            "SELECT imported_at FROM company_reports " +
                "WHERE coverage_start IS NOT NULL AND coverage_end IS NOT NULL " +
                "AND coverage_start<=? AND coverage_end>=? " +
                "ORDER BY imported_at DESC, id DESC LIMIT 1",
            arrayOf(end.toString(), start.toString())
        ).use { c -> if (c.moveToFirst()) c.getLong(0) else null }
    }

    fun latestReportCoverageEnd(onOrBefore: LocalDate): LocalDate? {
        return readableDatabase.rawQuery(
            "SELECT coverage_end FROM company_reports " +
                "WHERE coverage_end IS NOT NULL AND coverage_end<=? " +
                "ORDER BY imported_at DESC, id DESC LIMIT 1",
            arrayOf(onOrBefore.toString())
        ).use { c ->
            if (c.moveToFirst()) c.getString(0)?.let { runCatching { LocalDate.parse(it) }.getOrNull() } else null
        }
    }

    fun latestReportForMonth(year: Int, month: Int): SimRegReport? {
        val id = readableDatabase.rawQuery(
            """
            SELECT id FROM company_reports
            WHERE (
                (coverage_start IS NOT NULL AND substr(coverage_start,1,7)=?) OR
                (coverage_end IS NOT NULL AND substr(coverage_end,1,7)=?)
            )
            ORDER BY imported_at DESC, id DESC LIMIT 1
            """.trimIndent(),
            arrayOf("%04d-%02d".format(year, month), "%04d-%02d".format(year, month))
        ).use { c -> if (c.moveToFirst()) c.getLong(0) else null }
        return id?.let(::loadReport)
    }

    fun loadReport(reportId: Long): SimRegReport? {
        val db = readableDatabase
        var sourceName: String? = null
        var reportType: String? = null
        var start: LocalDate? = null
        var end: LocalDate? = null
        var sheetName = "Normalized database"
        db.rawQuery(
            "SELECT source_name,report_type,coverage_start,coverage_end FROM company_reports WHERE id=?",
            arrayOf(reportId.toString())
        ).use { c ->
            if (!c.moveToFirst()) return null
            sourceName = c.getString(0)
            reportType = c.getString(1)
            start = c.getString(2)?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
            end = c.getString(3)?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
        }

        val rowsByDevice = linkedMapOf<String, SimRegReportRow>()
        db.rawQuery(
            """
            SELECT device_id,trade_code,partner_name,cluster,region,territory,staff_name
            FROM company_report_devices WHERE report_id=? ORDER BY rowid ASC
            """.trimIndent(),
            arrayOf(reportId.toString())
        ).use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0)
                rowsByDevice[id] = SimRegReportRow(
                    tradeCode = c.getString(1).orEmpty(),
                    partnerName = c.getString(2).orEmpty(),
                    deviceId = id,
                    cluster = c.getString(3).orEmpty(),
                    region = c.getString(4).orEmpty(),
                    territory = c.getString(5).orEmpty(),
                    staffName = c.getString(6).orEmpty(),
                    daily = emptyMap(),
                    grandTotal = 0
                )
            }
        }

        val dailyByDevice = linkedMapOf<String, MutableMap<Int, Int>>()
        db.rawQuery(
            "SELECT device_id,activation_date,activation_count FROM activation_days WHERE report_id=? ORDER BY rowid ASC",
            arrayOf(reportId.toString())
        ).use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0)
                val date = runCatching { LocalDate.parse(c.getString(1)) }.getOrNull() ?: continue
                dailyByDevice.getOrPut(id) { linkedMapOf() }[date.dayOfMonth] = c.getInt(2)
            }
        }

        dailyByDevice.forEach { (id, daily) ->
            if (!rowsByDevice.containsKey(id)) {
                rowsByDevice[id] = SimRegReportRow("", "", id, "", "", "", "", daily, daily.values.sum())
            } else {
                val old = rowsByDevice.getValue(id)
                rowsByDevice[id] = old.copy(daily = daily, grandTotal = daily.values.sum())
            }
        }

        val rows = rowsByDevice.values.map { row ->
            if (row.daily.isEmpty()) row else row.copy(grandTotal = row.daily.values.sum())
        }
        DevMonitorLogger.db("report OPEN id=$reportId source=\"$sourceName\" devices=${rows.size} dailyRows=${dailyByDevice.values.sumOf { it.size }}")
        return SimRegReport(
            sourceName = sourceName ?: "Normalized database report",
            reportType = reportType ?: "ACTIVATIONS",
            coverageStart = start,
            coverageEnd = end,
            sheetName = sheetName,
            rows = rows
        )
    }

    fun deleteReport(reportId: Long) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            // Inventory deletion must NOT delete normalized daily values. Those
            // values belong to the continuous loaded-report dataset and may be
            // the only copy of a date after a merge/replacement.
            db.delete("company_report_devices", "report_id=?", arrayOf(reportId.toString()))
            val deleted = db.delete("company_reports", "id=?", arrayOf(reportId.toString()))
            db.setTransactionSuccessful()
            DevMonitorLogger.db("report DELETE metadataOnly id=$reportId deleted=$deleted; continuous activation data preserved")
        } finally {
            db.endTransaction()
        }
    }

    /**
     * Load only the user's working-set devices and only the requested date window.
     * This is deliberately different from loadContinuousReport(): the latter is the
     * full-company fallback/Show All path and must never be needed for normal My Devices.
     */
    fun loadWorkingSetForDevices(codes: List<String>, start: LocalDate, end: LocalDate): SimRegReport? {
        if (codes.isEmpty() || start.isAfter(end)) return null
        val normalized = codes.map(::canonicalDeviceCode).filter { it.isNotBlank() }.distinct()
        if (normalized.isEmpty()) return null
        val db = readableDatabase
        val latestMeta = mutableMapOf<String, Array<String>>()
        normalized.chunked(500).forEach { batch ->
            val placeholders = batch.joinToString(",") { "?" }
            db.rawQuery(
                "SELECT device_id,trade_code,partner_name,cluster,region,territory,staff_name FROM company_report_devices WHERE device_id IN ($placeholders) ORDER BY report_id DESC",
                batch.toTypedArray()
            ).use { c ->
                while (c.moveToNext()) {
                    val id = canonicalDeviceCode(c.getString(0).orEmpty())
                    if (!latestMeta.containsKey(id)) {
                        latestMeta[id] = arrayOf(c.getString(1).orEmpty(), c.getString(2).orEmpty(), c.getString(3).orEmpty(), c.getString(4).orEmpty(), c.getString(5).orEmpty(), c.getString(6).orEmpty())
                    }
                }
            }
        }
        val daily = mutableMapOf<String, MutableMap<LocalDate, Int>>()
        normalized.chunked(500).forEach { batch ->
            val placeholders = batch.joinToString(",") { "?" }
            val args = ArrayList<String>(batch.size + 2)
            args += start.toString(); args += end.toString(); args.addAll(batch)
            db.rawQuery(
                "SELECT device_id,activation_date,activation_count FROM activation_days WHERE activation_date BETWEEN ? AND ? AND device_id IN ($placeholders) ORDER BY rowid ASC",
                args.toTypedArray()
            ).use { c ->
                while (c.moveToNext()) {
                    val id = canonicalDeviceCode(c.getString(0).orEmpty())
                    val date = runCatching { LocalDate.parse(c.getString(1)) }.getOrNull() ?: continue
                    daily.getOrPut(id) { linkedMapOf() }[date] = c.getInt(2)
                }
            }
        }
        val rows = normalized.map { id ->
            val meta = latestMeta[id] ?: arrayOf("", "", "", "", "", "")
            val byDate = daily[id].orEmpty()
            SimRegReportRow(meta[0], meta[1], id, meta[2], meta[3], meta[4], meta[5], emptyMap(), byDate.values.sum(), byDate)
        }
        DevMonitorLogger.db("my devices working-set query devices=${rows.size} range=$start..$end dailyRows=${daily.values.sumOf { it.size }}")
        return SimRegReport("My Devices working set", "ACTIVATIONS", start, end, "My Devices", rows, true)
    }

    data class MonthToMonthComparison(
        val asOf: LocalDate,
        val currentTotal: Int,
        val previousTotal: Int,
        val delta: Int,
        val percentChange: Double?
    )

    /**
     * Month-to-Month Comparison is intentionally isolated from the existing
     * company normalized database. The four dedicated MonthOnMonthStore databases
     * are the only loaded-report source used by the calculator; Device Monitor is
     * consulted separately as a live, read-only fifth source.
     */
    fun setDeviceMonitorStore(store: DatabaseStore) = monthOnMonthStore.setDeviceMonitorStore(store)

    fun acceptMonthOnMonthReport(report: SimRegReport, myDeviceCodes: List<String>, now: LocalDate = LocalDate.now()): String =
        monthOnMonthStore.acceptLoadedReport(report, myDeviceCodes, now)

    fun refreshMonthOnMonthMyDevices(myDeviceCodes: List<String>) =
        monthOnMonthStore.refreshMyDevices(myDeviceCodes)

    /**
     * Read-only bridge for the staff-only Month-to-Month search. The underlying
     * search remains isolated inside MonthOnMonthStore; MainActivity does not
     * access the store directly.
     */
    fun searchMonthToMonth(
        query: String,
        asOf: LocalDate = LocalDate.now(),
        limit: Int = 100
    ): List<MonthOnMonthStore.SearchHit> =
        monthOnMonthStore.search(query, asOf, limit)

    fun monthToMonthComparison(
        userType: String,
        staffLevel: String,
        partnerCode: String,
        deviceId: String,
        division: String,
        region: String,
        staffName: String,
        territory: String,
        currentCodes: List<String>,
        asOf: LocalDate = LocalDate.now(),
        restrictToCodes: Boolean = false
    ): MonthToMonthComparison? {
        val requestedCodes = currentCodes.map(::canonicalDeviceCode).filter { it.isNotBlank() }.distinct()
        if (restrictToCodes && requestedCodes.isEmpty()) return null
        val result = monthOnMonthStore.compare(requestedCodes, asOf) ?: return null
        return MonthToMonthComparison(
            asOf = result.asOf,
            currentTotal = result.currentTotal,
            previousTotal = result.previousTotal,
            delta = result.delta,
            percentChange = result.percentChange
        )
    }

    /**
     * Default report-table view. Prefer the current calendar month when it has
     * successfully normalized data. On a fresh install, however, an older report
     * may be the only available dataset, so fall back to the newest month actually
     * present in activation_days. Once current-month data arrives, the viewer
     * automatically returns to the current month.
     *
     * This is display selection only: it never copies historical rows into the
     * current month and does not change the rolling database retention policy.
     */
    fun loadCurrentMonthReport(asOfRequested: LocalDate = LocalDate.now()): SimRegReport? {
        val asOf = PaymentRules.currentAwareDate(asOfRequested)
        val preferredMonth = YearMonth.from(asOf)
        val full = loadContinuousReport() ?: return null

        val availableMonths = full.rows
            .asSequence()
            .flatMap { it.dailyByDate.keys.asSequence() }
            .filter { !it.isAfter(asOf) }
            .map { YearMonth.from(it) }
            .distinct()
            .sortedDescending()
            .toList()
        if (availableMonths.isEmpty()) return null

        val month = if (preferredMonth in availableMonths) {
            preferredMonth
        } else {
            availableMonths.first()
        }
        val start = month.atDay(1)
        val end = if (month == preferredMonth) asOf else month.atEndOfMonth()
        val rows = full.rows.mapNotNull { row ->
            val byDate = row.dailyByDate.filterKeys {
                YearMonth.from(it) == month && !it.isBefore(start) && !it.isAfter(end)
            }
            if (byDate.isEmpty()) null
            else row.copy(
                dailyByDate = byDate,
                daily = byDate.mapKeys { it.key.dayOfMonth },
                grandTotal = byDate.values.sum()
            )
        }
        if (rows.isEmpty()) return null
        return SimRegReport(
            sourceName = if (month == preferredMonth) "Current month — $month" else "Latest available month — $month",
            reportType = "ACTIVATIONS",
            coverageStart = start,
            coverageEnd = end,
            sheetName = if (month == preferredMonth) "Current month" else "Latest available month",
            rows = rows,
            isContinuous = false
        )
    }

    fun loadContinuousReport(): SimRegReport? {
        val db = readableDatabase
        val dates = mutableListOf<LocalDate>()
        db.rawQuery("SELECT MIN(activation_date), MAX(activation_date) FROM activation_days", null).use { c ->
            if (!c.moveToFirst() || c.isNull(0) || c.isNull(1)) return null
            val first = runCatching { LocalDate.parse(c.getString(0)) }.getOrNull() ?: return null
            val last = runCatching { LocalDate.parse(c.getString(1)) }.getOrNull() ?: return null
            var d = first
            while (!d.isAfter(last)) { dates += d; d = d.plusDays(1) }
        }
        if (dates.isEmpty()) return null
        val latestMeta = mutableMapOf<String, Array<String?>>()
        db.rawQuery(
            """SELECT d.device_id,d.trade_code,d.partner_name,d.cluster,d.region,d.territory,d.staff_name
               FROM company_report_devices d JOIN company_reports r ON r.id=d.report_id
               ORDER BY COALESCE(r.coverage_end,'0000-00-00') DESC, r.imported_at DESC, r.id DESC, d.rowid ASC""".trimIndent(), null
        ).use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0)
                if (!latestMeta.containsKey(id)) {
                    latestMeta[id] = arrayOf(c.getString(1),c.getString(2),c.getString(3),c.getString(4),c.getString(5),c.getString(6))
                }
            }
        }
        val daily = mutableMapOf<String, MutableMap<LocalDate,Int>>()
        db.rawQuery("SELECT device_id,activation_date,activation_count FROM activation_days ORDER BY rowid ASC", null).use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0)
                val date = runCatching { LocalDate.parse(c.getString(1)) }.getOrNull() ?: continue
                daily.getOrPut(id) { linkedMapOf() }[date] = c.getInt(2)
            }
        }
        val orderedIds = buildList { addAll(latestMeta.keys); daily.keys.filterNot { latestMeta.containsKey(it) }.forEach { add(it) } }
        val rows = orderedIds.map { id ->
            val meta = latestMeta[id] ?: arrayOf<String?>(null, null, null, null, null, null)
            val byDate = daily[id].orEmpty()
            SimRegReportRow(meta[0].orEmpty(),meta[1].orEmpty(),id,meta[2].orEmpty(),meta[3].orEmpty(),meta[4].orEmpty(),meta[5].orEmpty(),emptyMap(),byDate.values.sum(),byDate)
        }
        if (rows.isEmpty()) return null
        DevMonitorLogger.db("continuous report OPEN devices=${rows.size} dates=${dates.size} range=${dates.first()}..${dates.last()}")
        return SimRegReport("Continuous loaded reports", "ACTIVATIONS", dates.first(), dates.last(), "Normalized continuous database", rows, true)
    }

    fun cycleContributions(deviceId: String, date: LocalDate = LocalDate.now()): List<CycleContribution> {
        val asOf = PaymentRules.currentAwareDate(date)
        val code = canonicalDeviceCode(deviceId)
        val cycleStart = PaymentRules.paymentCycleForDate(asOf).first
        val out = mutableListOf<CycleContribution>()
        readableDatabase.rawQuery(
            """
            SELECT r.id, r.source_name, r.coverage_start, r.coverage_end,
                   SUM(a.activation_count)
            FROM activation_days a
            JOIN company_reports r ON r.id=a.report_id
            WHERE a.device_id=? AND a.activation_date BETWEEN ? AND ?
            GROUP BY r.id, r.source_name, r.coverage_start, r.coverage_end
            ORDER BY MIN(a.activation_date), r.id
            """.trimIndent(),
            arrayOf(code, cycleStart.toString(), asOf.toString())
        ).use { c ->
            while (c.moveToNext()) {
                out += CycleContribution(
                    reportId = c.getLong(0),
                    sourceName = c.getString(1),
                    coverageStart = c.getString(2)?.let { runCatching { LocalDate.parse(it) }.getOrNull() },
                    coverageEnd = c.getString(3)?.let { runCatching { LocalDate.parse(it) }.getOrNull() },
                    activationCount = c.getInt(4)
                )
            }
        }
        DevMonitorLogger.payment("loaded-report contributions device=$code cycle=${PaymentRules.paymentCycleLabel(asOf)} asOf=$asOf reports=${out.size} total=${out.sumOf { it.activationCount }}")
        return out
    }

    /** Returns the normalized Loaded Reports activation value for one device on one exact date.
     * Future dates are never requested by payment intelligence; callers should pass the live date.
     */
    /** Returns loaded daily values. A missing map entry means the report database has no activation row for that date. */
    fun dailyCoverageForDevice(deviceId: String, start: LocalDate, end: LocalDate): Map<LocalDate, Int> {
        if (start.isAfter(end)) return emptyMap()
        val out = linkedMapOf<LocalDate, Int>()
        readableDatabase.rawQuery(
            "SELECT activation_date,activation_count FROM activation_days WHERE device_id=? AND activation_date BETWEEN ? AND ? ORDER BY activation_date",
            arrayOf(canonicalDeviceCode(deviceId), start.toString(), end.toString())
        ).use { c ->
            while (c.moveToNext()) {
                val d = runCatching { LocalDate.parse(c.getString(0)) }.getOrNull() ?: continue
                out[d] = c.getInt(1)
            }
        }
        return out
    }

    /** True when at least one imported company report explicitly covers this date. */
    fun hasReportCoverage(date: LocalDate): Boolean {
        return readableDatabase.rawQuery(
            "SELECT 1 FROM company_reports WHERE coverage_start IS NOT NULL AND coverage_end IS NOT NULL AND coverage_start<=? AND coverage_end>=? LIMIT 1",
            arrayOf(date.toString(), date.toString())
        ).use { it.moveToFirst() }
    }

    /**
     * True only when this specific device has an activation row for every date in the range.
     * Global report coverage is not enough: a report can cover a date while a particular
     * device is absent/unknown for that date. Missing device dates must never be treated as 0
     * when reconstructing an SMS Active baseline.
     */
    fun hasCompleteDeviceCoverage(deviceId: String, start: LocalDate, end: LocalDate): Boolean {
        if (start.isAfter(end)) return true
        val code = canonicalDeviceCode(deviceId)
        val expected = java.time.temporal.ChronoUnit.DAYS.between(start, end) + 1
        val actual = readableDatabase.rawQuery(
            "SELECT COUNT(DISTINCT activation_date) FROM activation_days WHERE device_id=? AND activation_date BETWEEN ? AND ?",
            arrayOf(code, start.toString(), end.toString())
        ).use { c ->
            if (c.moveToFirst()) c.getLong(0) else 0L
        }
        val complete = actual == expected
        DevMonitorLogger.payment(
            "loaded-report device baseline coverage device=$code range=$start..$end expected=$expected actual=$actual complete=$complete"
        )
        return complete
    }

    /** True when the loaded-report database has continuous report coverage for every calendar date in the range. */
    fun hasCompleteReportCoverage(start: LocalDate, end: LocalDate): Boolean {
        if (start.isAfter(end)) return true
        var d = start
        while (!d.isAfter(end)) {
            if (!hasReportCoverage(d)) return false
            d = d.plusDays(1)
        }
        return true
    }

    /**
     * Returns the calendar-month cumulative activation baseline needed by Device
     * Monitor when its own SMS history has no Active snapshot through the 20th.
     * A report is eligible when its coverage reaches the requested boundary and
     * the device exists in that report. Missing daily activation rows are treated
     * as zero because the report itself establishes coverage; this avoids requiring
     * a row for every zero-activation day.
     */
    fun paymentBaselineActiveFromLoadedReport(deviceId: String, monthStart: LocalDate, boundary: LocalDate): Int? {
        if (boundary.isBefore(monthStart)) return null
        val code = canonicalDeviceCode(deviceId)
        val hasCoveredReport = readableDatabase.rawQuery(
            """SELECT 1
               FROM company_reports r
               JOIN company_report_devices d ON d.report_id=r.id
               WHERE d.device_id=? AND r.coverage_start<=? AND r.coverage_end>=?
               ORDER BY r.coverage_end DESC, r.imported_at DESC, r.id DESC
               LIMIT 1""".trimIndent(),
            arrayOf(code, monthStart.toString(), boundary.toString())
        ).use { it.moveToFirst() }
        if (!hasCoveredReport) return null
        val total = readableDatabase.rawQuery(
            "SELECT COALESCE(SUM(activation_count),0) FROM activation_days WHERE device_id=? AND activation_date BETWEEN ? AND ?",
            arrayOf(code, monthStart.toString(), boundary.toString())
        ).use { if (it.moveToFirst()) it.getInt(0) else 0 }
        DevMonitorLogger.payment("loaded-report Active baseline device=$code through=$boundary total=$total")
        return total
    }

    fun activationCountForDate(deviceId: String, date: LocalDate = LocalDate.now()): Int? {
        val asOf = PaymentRules.currentAwareDate(date)
        val code = canonicalDeviceCode(deviceId)
        val total = readableDatabase.rawQuery(
            "SELECT SUM(activation_count) FROM activation_days WHERE device_id=? AND activation_date=?",
            arrayOf(code, asOf.toString())
        ).use { c ->
            if (c.moveToFirst() && !c.isNull(0)) c.getInt(0) else null
        }
        DevMonitorLogger.payment(
            "loaded-report day total device=$code date=$asOf total=${total ?: "none"}"
        )
        return total
    }

    fun cycleTotal(deviceId: String, date: LocalDate = LocalDate.now()): Int? {
        val asOf = PaymentRules.currentAwareDate(date)
        val code = canonicalDeviceCode(deviceId)
        val cycleStart = PaymentRules.paymentCycleForDate(asOf).first
        val cursor = readableDatabase.rawQuery(
            "SELECT SUM(activation_count), COUNT(*) FROM activation_days WHERE device_id=? AND activation_date BETWEEN ? AND ?",
            arrayOf(code, cycleStart.toString(), asOf.toString())
        )
        cursor.use {
            if (!it.moveToFirst()) return null
            if (!it.isNull(0) && it.getInt(1) > 0) {
                val total = it.getInt(0)
                DevMonitorLogger.payment("loaded-report cycle total device=$code cycle=${PaymentRules.paymentCycleLabel(asOf)} asOf=$asOf total=$total")
                return total
            }
        }
        val known = readableDatabase.rawQuery(
            "SELECT 1 FROM activation_days WHERE device_id=? LIMIT 1", arrayOf(code)
        ).use { it.moveToFirst() }
        if (known) {
            DevMonitorLogger.payment("loaded-report cycle total device=$code cycle=${PaymentRules.paymentCycleLabel(asOf)} asOf=$asOf total=0 (no sales yet)")
            return 0
        }
        DevMonitorLogger.payment("loaded-report cycle total device=$code cycle=${PaymentRules.paymentCycleLabel(asOf)} asOf=$asOf unavailable")
        return null
    }

    fun cycleSundayActivations(deviceId: String, date: LocalDate = LocalDate.now()): Int {
        val asOf = PaymentRules.currentAwareDate(date)
        val code = canonicalDeviceCode(deviceId)
        val cycleStart = PaymentRules.paymentCycleForDate(asOf).first
        val cursor = readableDatabase.rawQuery(
            "SELECT activation_date,activation_count FROM activation_days WHERE device_id=? AND activation_date BETWEEN ? AND ?",
            arrayOf(code, cycleStart.toString(), asOf.toString())
        )
        var total = 0
        cursor.use {
            while (it.moveToNext()) {
                val d = LocalDate.parse(it.getString(0))
                if (d.dayOfWeek.value == 7 && it.getInt(1) >= PaymentRules.SUNDAY_MIN_ACTIVATIONS) total += it.getInt(1)
            }
        }
        return total
    }

    fun hasAnyHistory(deviceId: String): Boolean {
        return readableDatabase.rawQuery(
            "SELECT 1 FROM activation_days WHERE device_id=? LIMIT 1",
            arrayOf(canonicalDeviceCode(deviceId))
        ).use { it.moveToFirst() }
    }

    data class DeviceHistoricalBridge(
        val deviceId: String,
        val reportMonth: YearMonth,
        val coverageStart: LocalDate,
        val coverageEnd: LocalDate,
        val activationSum: Int,
        val sourceReportId: Long
    )

    /**
     * Returns the previous calendar month's available activation total for one device,
     * restricted to the 21st through month-end. This is deliberately separate from
     * payment-intelligence cycle calculations and is used only by Device Monitor.
     */
    fun historicalBridgeForDevice(deviceId: String, referenceDate: LocalDate = LocalDate.now()): DeviceHistoricalBridge? {
        // Device Monitor historical data is also live-date aware: a caller can never
        // move the bridge into a future calendar month by supplying a future date.
        val asOf = PaymentRules.currentAwareDate(referenceDate)
        val month = YearMonth.from(asOf).minusMonths(1)
        val start = month.atDay(21)
        val end = month.atEndOfMonth()
        val canonical = canonicalDeviceCode(deviceId)
        return readableDatabase.rawQuery(
            """
            SELECT MIN(activation_date), MAX(activation_date), SUM(activation_count),
                   (SELECT a2.report_id FROM activation_days a2
                    WHERE a2.device_id=? AND a2.activation_date BETWEEN ? AND ?
                    ORDER BY a2.imported_at DESC, a2.report_id DESC LIMIT 1)
            FROM activation_days
            WHERE device_id=? AND activation_date BETWEEN ? AND ?
            """.trimIndent(),
            arrayOf(canonical, start.toString(), end.toString(), canonical, start.toString(), end.toString())
        ).use { c ->
            if (!c.moveToFirst() || c.isNull(2)) return null
            val coverageStart = c.getString(0)?.let { LocalDate.parse(it) } ?: start
            val coverageEnd = c.getString(1)?.let { LocalDate.parse(it) } ?: end
            DeviceHistoricalBridge(
                deviceId = canonical,
                reportMonth = month,
                coverageStart = coverageStart,
                coverageEnd = coverageEnd,
                activationSum = c.getInt(2),
                sourceReportId = if (c.isNull(3)) 0L else c.getLong(3)
            )
        }.also { bridge ->
            DevMonitorLogger.db(
                "device-monitor historical lookup code=$canonical month=$month range=$start..$end total=${bridge?.activationSum ?: "none"}"
            )
        }
    }

    /** Returns only the per-device 21st-to-month-end total for the imported report month. */
    fun historicalBridgeRows(reportId: Long, coverageEnd: LocalDate?): List<Triple<String, String, Int>> {
        if (coverageEnd == null) return emptyList()
        val month = YearMonth.from(coverageEnd)
        val start = LocalDate.of(month.year, month.monthValue, 21)
        val end = coverageEnd
        val out = mutableListOf<Triple<String, String, Int>>()
        readableDatabase.rawQuery(
            "SELECT device_id, SUM(activation_count) FROM activation_days WHERE activation_date BETWEEN ? AND ? GROUP BY device_id",
            arrayOf(start.toString(), end.toString())
        ).use { c ->
            while (c.moveToNext()) {
                if (!c.isNull(1)) out += Triple(c.getString(0), month.toString(), c.getInt(1))
            }
        }
        DevMonitorLogger.db("historical bridge prepared reportId=$reportId month=$month devices=${out.size} range=$start..$end")
        return out
    }

    fun closeStore() = close()

    override fun close() {
        runCatching { monthOnMonthStore.close() }
        super.close()
    }
}
