# DevMonitor 4.6.0-NEXT v239 — My Partner search fix

## Fixed
- The My Partner loaded-report search field now updates only the search query. It no longer copies every typed character into the Partner name field.
- Search results continue to be filtered from the loaded HQ report scope by partner name or trade code.
- Selecting a result fills the actual partner name and trade code; manual entry remains available when there is no match.

## Preserved
- My Partner data and check history remain in the separate `my_partner.db` database.
- My Partner remains separate from My Devices, normal SMS Checker observations and payment progression.
- Existing payment rules and report calculations are unchanged.
- v238 permission callback compile fix and app-wide notification changes are carried forward.

## Verification
- Source-level assertion confirms the search field no longer writes to `myPartnerNameInput`.
- ZIP integrity checked after packaging. Android compilation and device-level search behaviour still require the GitHub Actions build and on-device test.
