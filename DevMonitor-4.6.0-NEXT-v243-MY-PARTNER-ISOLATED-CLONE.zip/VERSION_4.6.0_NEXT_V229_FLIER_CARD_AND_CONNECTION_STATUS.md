# DevMonitor Android v229 — Earnings Flier and Link Status

- Redesigned earnings-card image export as a green/lime promotional flier inspired by the in-app company payment structure graphic.
- Preserved supplied estimate values; no payment rules or calculations changed.
- Added a persistent PC-link status strip under the app header, with configured, awaiting sync, reconnecting, recent-success and stale/offline states.
- Android reports recent successful exchange rather than claiming a live connection when no exchange is currently occurring.
- Build and paired-device behaviour still require GitHub Actions and device testing.


Version identity advance: Android versionCode is 229; versionName remains 4.6.0-NEXT. No feature or payment logic change intended in this version-only advance.
