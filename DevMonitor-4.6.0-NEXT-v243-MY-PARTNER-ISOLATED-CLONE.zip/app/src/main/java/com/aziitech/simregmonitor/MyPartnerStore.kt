package com.aziitech.simregmonitor

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.util.UUID
import java.util.Locale
import org.json.JSONArray

/** Independent SQLite database for My Partner. It never opens or mutates the main device database. */
data class MyPartnerRecord(val id: String, val name: String, val code: String)

class MyPartnerStore(context: Context) : SQLiteOpenHelper(context.applicationContext, "my_partner.db", null, 1) {
    init { migrateLegacyPreferences(context.applicationContext) }

    private fun migrateLegacyPreferences(context: Context) {
        val prefs = context.getSharedPreferences("devmonitor_my_partner", Context.MODE_PRIVATE)
        if (prefs.getBoolean("sqlite_migration_complete", false)) return
        val db = writableDatabase
        db.beginTransaction()
        try {
            prefs.all.forEach { (key, value) ->
                if (!key.startsWith("partners_") || value !is String) return@forEach
                val profile = key.removePrefix("partners_").ifBlank { "default" }
                runCatching {
                    val array = JSONArray(value)
                    for (i in 0 until array.length()) {
                        val item = array.optJSONObject(i) ?: continue
                        val name = item.optString("name").trim()
                        val code = item.optString("code").trim().uppercase(Locale.US)
                        if (name.isBlank() || code.isBlank()) continue
                        val values = ContentValues().apply {
                            put("id", item.optString("id").ifBlank { UUID.randomUUID().toString() })
                            put("profile_id", profile); put("name", name); put("code", code); put("updated_at", System.currentTimeMillis())
                        }
                        db.insertWithOnConflict("partners", null, values, SQLiteDatabase.CONFLICT_IGNORE)
                    }
                }
            }
            db.setTransactionSuccessful()
            prefs.edit().putBoolean("sqlite_migration_complete", true).apply()
        } finally { db.endTransaction() }
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE partners (id TEXT PRIMARY KEY NOT NULL, profile_id TEXT NOT NULL, name TEXT NOT NULL, code TEXT NOT NULL, updated_at INTEGER NOT NULL)")
        db.execSQL("CREATE UNIQUE INDEX idx_my_partner_profile_code ON partners(profile_id, code)")
        db.execSQL("CREATE TABLE check_history (id TEXT PRIMARY KEY NOT NULL, profile_id TEXT NOT NULL, partner_code TEXT NOT NULL, source TEXT NOT NULL, status TEXT NOT NULL, today INTEGER, mtd INTEGER, active INTEGER, bar48 INTEGER, bar96 INTEGER, raw_response TEXT NOT NULL, checked_at INTEGER NOT NULL)")
        db.execSQL("CREATE INDEX idx_my_partner_history ON check_history(profile_id, partner_code, checked_at DESC)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) { }
    private fun normalizedProfile(profileId: String) = profileId.ifBlank { "default" }

    @Synchronized fun load(profileId: String): List<MyPartnerRecord> {
        val out = mutableListOf<MyPartnerRecord>()
        readableDatabase.query("partners", arrayOf("id", "name", "code"), "profile_id=?", arrayOf(normalizedProfile(profileId)), null, null, "name COLLATE NOCASE ASC").use { c ->
            while (c.moveToNext()) out += MyPartnerRecord(c.getString(0), c.getString(1), c.getString(2))
        }
        return out
    }

    @Synchronized fun save(profileId: String, records: List<MyPartnerRecord>) {
        val db = writableDatabase
        val profile = normalizedProfile(profileId)
        db.beginTransaction()
        try {
            db.delete("partners", "profile_id=?", arrayOf(profile))
            val seen = mutableSetOf<String>()
            records.forEach { record ->
                val name = record.name.trim()
                val code = record.code.trim().uppercase(Locale.US)
                if (name.isNotBlank() && code.isNotBlank() && seen.add(code)) {
                    val values = ContentValues().apply {
                        put("id", record.id.ifBlank { UUID.randomUUID().toString() }); put("profile_id", profile)
                        put("name", name); put("code", code); put("updated_at", System.currentTimeMillis())
                    }
                    db.insertOrThrow("partners", null, values)
                }
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    @Synchronized fun saveCheck(profileId: String, code: String, source: String, status: String,
        today: Int?, mtd: Int?, active: Int?, bar48: Int?, bar96: Int?, rawResponse: String) {
        val values = ContentValues().apply {
            put("id", UUID.randomUUID().toString()); put("profile_id", normalizedProfile(profileId))
            put("partner_code", code.trim().uppercase(Locale.US)); put("source", source); put("status", status)
            if (today == null) putNull("today") else put("today", today)
            if (mtd == null) putNull("mtd") else put("mtd", mtd)
            if (active == null) putNull("active") else put("active", active)
            if (bar48 == null) putNull("bar48") else put("bar48", bar48)
            if (bar96 == null) putNull("bar96") else put("bar96", bar96)
            put("raw_response", rawResponse); put("checked_at", System.currentTimeMillis())
        }
        writableDatabase.insert("check_history", null, values)
    }
}
