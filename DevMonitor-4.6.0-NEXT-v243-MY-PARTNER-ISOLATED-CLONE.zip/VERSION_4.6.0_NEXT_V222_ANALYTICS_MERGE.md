# DevMonitor 4.6.0-NEXT v222 — Analytics and Version Awareness Merge

## Merged into the current v222 sync-bridge development line
- Added privacy-conscious Firebase Analytics event logging for app opens, successful report imports, update prompts/actions, and manual update checks.
- Added Firebase Crashlytics integration for crash and non-fatal diagnostics with app version, Android version, and install-channel context.
- Restored optional update prompts alongside mandatory minimum-version enforcement.
- Restored manual Settings > App version > Check for updates.
- Update URL selection now prefers configured GetApps URL for GetApps installations, otherwise the configured website URL, then generic URL, then the official DevMonitor website fallback.
- Preserved the current v222 Phone ↔ PC Sync Bridge files and UI; this merge does not alter sync payload logic.
- Version code incremented to 221.

## Data protection
Analytics events must not include phone numbers, staff names, trade codes, device IDs, raw activation/SIMReg records, or payment values. Review Firebase Analytics and Crashlytics access and retention before public release.

## Validation status
ZIP integrity and source-level integration checks are performed for this package. A complete Gradle build must still run in GitHub Actions before treating the merged APK as build-verified.
