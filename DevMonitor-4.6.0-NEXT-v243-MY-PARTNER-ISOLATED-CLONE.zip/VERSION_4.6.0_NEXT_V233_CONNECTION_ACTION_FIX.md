# DevMonitor Android v233 — Connection icon action fix

- The top-bar PC-link icon continues to open Next Level, but Next Level now opens directly on the Health section so the tap immediately exposes Phone ↔ PC Sync Bridge settings and the Sync now action.
- No payment calculation or threshold changes.
- Based on Android v232.
- Build verification: run the repository Android GitHub Actions workflow; local compilation was not available in this environment.
