# DevMonitor Android v228 — Earnings Flier and Link Status

- Redesigned earnings-card image export as a green/lime promotional flier inspired by the in-app company payment structure graphic.
- Preserved supplied estimate values; no payment rules or calculations changed.
- Added a persistent PC-link status strip under the app header, with configured, awaiting sync, reconnecting, recent-success and stale/offline states.
- Android reports recent successful exchange rather than claiming a live connection when no exchange is currently occurring.
- Build and paired-device behaviour still require GitHub Actions and device testing.
