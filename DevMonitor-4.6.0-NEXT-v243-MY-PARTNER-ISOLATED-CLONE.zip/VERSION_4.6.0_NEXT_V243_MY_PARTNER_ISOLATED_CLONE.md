# DevMonitor Android v243 — Independent staff-only My Partner clone

## Changes
- Added a dashboard My Partner card immediately above Month-on-Month Comparison; it is shown only when the active profile type is STAFF.
- Added a standalone My Partner page with add, edit, remove and per-partner Check by SMS actions.
- My Partner uses the dedicated `my_partner.db` database and profile-scoped partner records. SMS results are written to its own check-history table; the existing Device Monitor/My Devices lists and history are not used for My Partner storage.
- The SMS check uses the selected SIM and configured SMS destination, then polls the captured inbox response and parses the returned summary.
- Preserved package/application ID, payment logic, report import behavior, notifications, and existing Device Monitor flows. Version code is 243; version name remains 4.6.0-NEXT.

## Validation
- ZIP integrity and source-level assertions checked during packaging.
- The substituted `.github/workflows/android-build.yml` found in v242 was intentionally not carried into this ZIP; keep the established GitHub Actions workflow in the repository unchanged. The known phone build entry remains `sh build-phone.sh assembleDebug --console=plain`.
- Android compilation, GitHub Actions build, and physical-device SMS testing have not been run in this environment; test the first SMS check on-device before relying on it operationally.
