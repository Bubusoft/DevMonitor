# Android v232 — Connection icon placement and earnings flier

- Moved the PC connection state icon to the app-bar action row beside the notification bell and flag.
- Replaced the simple earnings export artwork with a branded portrait promotional flier.
- Displays the source, reporting period, as-of date, agent/device identity, estimate total, estimate components, and reach-step-specific encouragement.
- Existing displayed estimate values are passed through unchanged; payment logic is not recalculated by the export renderer.
- Build status: source ZIP assembled and integrity checked; Android build and live-device testing are still required.
