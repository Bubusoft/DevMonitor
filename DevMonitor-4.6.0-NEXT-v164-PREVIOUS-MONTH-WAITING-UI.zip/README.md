# SIMReg Monitor v0.9.0

Mobile-first build for Android Code Studio. Based on the known-good v0.8.1 fixed project.

## Stability
- Java/Kotlin JVM target 17
- Gradle workers limited to 1
- Gradle parallel execution disabled
- No Apache POI dependency

## Monitoring
- Calendar daily and MTD observations
- Company ownership: GLO-GD-...
- Partner ownership: GLO-DD-..., GLO-FD-... and standalone partner codes
- Company-first report priority
- Company day-1 zero-sales flag clears automatically after first sale
- Company <10 MTD sales by day 15 flag
- Two consecutive zero-sales-day flag
- Bar 48 increases reported as Conversion Lost
- Increasing Conversion Lost trend flag
- Individual recent-pattern deviation monitoring
- Up to 60 months of analytics retention

## Payment tracking
Separate Agent/partner Payment Tracking record.

Default cycle: 21st through 20th. A Calendar Month option is also available. Cycle labels use the cycle end month, so the cycle beginning 21 August 2026 is labelled September 2026.

A month-end scheduler checks the last calendar day at about 20:30 local time. It saves the current payment snapshot and attempts to open the app with an automatic month-end run request. Android may defer background activity launches depending on device power/background restrictions; the saved snapshot is retained even if the visible launch is deferred.

## Agent / partner database
Stores:
- Agent name
- Address
- Multiple phone numbers
- Latitude/longitude
- Linked device/partner codes

Phone numbers can be selected from the phone's Contacts picker. Location can use the device's present/last-known location or manually entered coordinates. A Google Maps button opens the selected coordinates for map verification.

## Build
Open the project folder in Android Code Studio and build normally. Do not change the single-worker Gradle settings unless necessary.


## v2.0.1 update
- Restored visible SIM selector for dual/multi-SIM phones.
- SMS is sent through Android SmsManager SMS APIs only; no RCS fallback is used.
- Optional sent/delivered SMS delivery reports are monitored when the carrier/device provides them. Negative delivery reports trigger up to two immediate retries before the next query, with a visible warning while the batch continues.
- Company devices crossing the day-15 MTD <10 checkpoint remain flagged until MTD reaches 10+.
- No-sales flag threshold increased from 2 to 4 consecutive recorded days.


## v2.1.0 product polish
- Optional first-launch Busayo welcome screen and interactive guided tour.
- Tour can be skipped and reopened from Settings.
- About page with the supplied professional profile.
- File attachment/link area for local reference files.
- Form placeholders/examples added to make expected inputs clear.
- Excel report headers and totals use the GLO green visual scheme.
- Existing SMS-only, multi-SIM, delivery monitoring, flags, database and payment features are preserved.

Google/Firebase authentication is now integrated for the 4.3.4 authentication workstream. Google remains the identity anchor and Firebase Authentication is used to establish the account identity and verify the configured staff line by SMS. Google Drive backup continues to use the user's Google account and private app-data area.


## v2.1.1 SMS and onboarding update
- Guided tour is the default first-launch experience, while Skip/Explore remains available.
- Long GLO device IDs are retained in the database/UI but converted to the 3030 short form immediately before SMS transmission (for example GLO-GD-OGN-da3-3GOGN047-666D -> GLO-GD-666D).
- Other SMS destinations receive the code exactly as entered.
- Busayo avatar presentation was changed to a non-circular portrait so the upper face is not clipped.


## v2.1.3 Play SMS-permission readiness
- SMS permissions are requested only in response to the user starting SMS batch automation or a retry.
- A prominent in-app disclosure explains the SMS use immediately before the Android permission prompt.
- SMS data is explicitly limited to the monitoring/reporting workflow and is not used for advertising or marketing.
- See `PLAY_STORE_SMS_PERMISSION_DECLARATION.md` for the intended Google Play `Device automation` declaration.

Google Play lists Device automation among exception categories that may be eligible for SMS permissions, subject to review and approval. The publisher must submit the declaration accurately for the production build.


## v2.2.0 Release Candidate
AdMob is integrated using Google test IDs only. Replace the test App ID and banner unit before production. See PLAY_RELEASE_CHECKLIST.md.

## v2.2.8 Samsung Galaxy Store build
- Removed the sideload APK auto-update/downloader mechanism for Galaxy Store compliance.
- Removed REQUEST_INSTALL_PACKAGES and the update FileProvider.
- Galaxy Store is the update channel for this build.
- AdMob banner/interstitial integration remains; replace Google test IDs with your production AdMob IDs before public release.


## Version 2.3.0 fork
- First 10 successful Excel exports are free.
- After the first 10, each completed rewarded ad grants 3 additional exports.
- Monthly or yearly subscription removes all ads and export limits in the public build.
- The day-15 MTD-below-10 flag is hidden by default. Tap the DevMonitor title 7 times within about 2.2 seconds to toggle diagnostic visibility.
- This fork: public / monetized.

## DevMonitor Premium — Xiaomi GetApps (Current Release Store)

This release is the GetApps-focused Premium build. It uses Xiaomi GetApps IAP for Monthly and Yearly Premium subscriptions, while retaining the existing AdMob implementation for free users. Configure the two subscription SKUs in Xiaomi GetApps before testing purchases.
