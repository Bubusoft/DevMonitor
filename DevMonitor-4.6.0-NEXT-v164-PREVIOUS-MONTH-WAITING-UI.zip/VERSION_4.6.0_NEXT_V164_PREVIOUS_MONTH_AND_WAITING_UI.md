# DevMonitor 4.6.0-NEXT v164 — Previous-Month HQ Import + Same-Coverage Replacement + Unified Waiting UI

## HQ report storage rule
- Current and immediately previous calendar months remain the only physical HQ stores.
- Import order is independent of calendar month.
- Older coverage-end data is rejected.
- Same coverage-end date is no longer treated as a duplicate. A valid same-coverage report replaces the existing complete monthly snapshot.
- This supports different complete registration and activation exports arriving later with the same coverage date.
- Replacement remains atomic and does not merge stale rows.

## Previous-month display
- After import, the viewer selects the stored snapshot belonging to the month just imported.
- The dashboard LOAD REPORT entry point still prefers the current calendar month when opening the viewer normally.
- The existing automatic advancement to the report table is preserved.
- Profile Builder is untouched.

## Unified floating waiting UI
- One floating waiting window remains the only app-wide waiting window.
- It now shows operation name, current major step, fixed projected overall percentage, one progress bar, and a concise status message.
- Import stages use the existing workflow boundaries; percentages are presentation only and do not introduce row-by-row counting or performance monitoring.
- Other existing substantial operations use fixed representational stage percentages in the same single window.

## Protected
- PaymentEngine and payment formulas.
- 21st-to-20th payment-cycle rules.
- SMS/query logic.
- Report authority and complete-snapshot semantics.
- Existing automatic report-table scroll.
- DevMonitor 4.5.17 locked performance baseline.
