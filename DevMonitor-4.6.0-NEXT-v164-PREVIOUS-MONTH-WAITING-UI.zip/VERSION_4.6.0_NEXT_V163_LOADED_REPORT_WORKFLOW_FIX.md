# DevMonitor 4.6.0-NEXT v163 — Loaded Report Workflow Fix

## Basis
v163 is based directly on the protected v162.1 source and was compared against v161 before changes were made.

## Finding
The v161 and v162.1 Loaded Report implementation files were functionally identical. The regression was therefore not treated as a rewrite of the report parser/viewer.

## Targeted fix
- The dashboard **LOAD REPORT** entry now opens the Loaded Report screen immediately and, in the background, restores the preferred stored report.
- If a current-calendar-month report exists, it is selected first.
- If no current-month report exists, the newest stored report is selected.
- If no stored report exists, the screen remains ready for a new import.
- After importing a report, the same preference is applied: current calendar month first, then newest stored report, then the just-imported report as fallback.
- The existing automatic post-load table scroll in `SimRegReport.kt` is untouched.
- Report parser, storage model, payment engine, payment formulas, and report calculations are untouched.

## Scope
This is a targeted Loaded Report navigation/state fix only. No payment logic or report parsing logic was rewritten.
