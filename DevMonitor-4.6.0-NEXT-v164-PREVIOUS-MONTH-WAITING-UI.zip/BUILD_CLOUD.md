# DevMonitor 4.6.0-NEXT — Cloud Build

## Purpose
This fork is the complete NEXT LEVEL milestone build, not a cloud-build-only experiment. It starts from the locked DevMonitor 4.5.17 performance baseline and carries the mapped Phase 3 and Phase 4 milestones together in one integrated build.

## Cloud build target
```sh
./gradlew :app:assembleDebug --no-daemon --console=plain
```

The GitHub Actions workflow uses Java 17 and Gradle 8.7 and uploads the resulting debug APK as the `DevMonitor-debug-apk` artifact. No release keystore or release signing credentials are required for this experimental fork.

## Protected areas
- Payment cycle remains 21st of previous month through 20th of current month.
- Payment progression pathway remains Device Monitor / SIMReg → Payment Cycle → Device Card → Payments.
- Month-on-Month retains four physically separate SQLite databases.
- SMS remains the 3030 operational transport.
- Loaded Reports remain authoritative HQ evidence where applicable.
- NEXT LEVEL analytics are explicit-refresh driven; no new heavy automatic/background processing is introduced.
