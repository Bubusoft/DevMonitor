# DevMonitor 4.6.0-NEXT v177 — SMS CHECKER + Dashboard Onboarding Implementation

## Status
**IMPLEMENTED — BUILD VERIFICATION PENDING**

## SMS CHECKER operational tour
- Restored the established Device Monitor/SMS operational guided tour under **SMS CHECKER**.
- The operational tour remains available from the app menu.
- First-time arrival at SMS CHECKER can trigger it from the dashboard SMS CHECKER action or when Check My Devices takes the user into SMS Checker.
- The entry point can skip already-established flow steps such as SIM selection.
- The tour continues to use real SMS Checker controls and does not simulate SMS operations.

## Dashboard orientation
- Added a separate post-profile dashboard tour for a newly created profile.
- It highlights the major dashboard sections in sequence.
- Each section has a concise explanation and remains highlighted for approximately five seconds.
- It advances automatically; the user does not need to press Next.
- The user can skip it. Completion/skip is persisted so it does not replay.
- Existing profile edits/rebuilds do not restart the new-user orientation.

## BUILD PROFILE card
- The existing first-setup BUILD PROFILE card remains conditional on having no profile.
- Once a profile is successfully created/saved, it disappears naturally from the dashboard.

## Protected boundaries
No intentional changes were made to payment formulas/progression, the 21st–20th payment cycle, Device Monitor business rules, SMS query behavior, HQ report storage/import rules, Company Skeleton data model, Cluster → Region → Territory → Staff → Devices/Trade Codes hierarchy, MOM architecture, or explicit-refresh performance rules.

## Verification
A local Gradle build was attempted after implementation but could not start because the environment could not resolve `services.gradle.org` to download Gradle 8.7. Therefore this package must not be described as build-verified until GitHub/cloud build succeeds.
