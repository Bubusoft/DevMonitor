# DevMonitor v210 — Check My Devices Source Menu Fix

Baseline: v203-derived v209 source.

Fix: Check My Devices is restored as a source-selection entry point. It no longer silently opens the Loaded Report when no report is available. With an existing My Devices profile, tapping Check My Devices opens the choice between:
- Device Monitor / SMS Checker
- Loaded Report

The first-time profile setup remains unchanged and returns to the source-selection flow after setup.

No payment logic or MOM calculation logic was changed.

VersionCode: 210
VersionName: 4.6.0-NEXT
