package com.aziitech.simregmonitor

import android.content.Context
import android.net.Uri
import android.util.Xml
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import org.xmlpull.v1.XmlPullParser
import java.io.InputStream
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.TextStyle
import java.util.Locale
import java.util.zip.ZipInputStream
import kotlin.math.sqrt

private data class RawSheet(val name: String, val rows: List<List<String>>)

data class SimRegReportRow(
    val tradeCode: String,
    val partnerName: String,
    val deviceId: String,
    val cluster: String,
    val region: String,
    val territory: String,
    val staffName: String,
    val daily: Map<Int, Int>,
    val grandTotal: Int,
    val dailyByDate: Map<LocalDate, Int> = emptyMap()
) {
    fun mtd(cutoffDay: Int): Int = daily.filterKeys { it <= cutoffDay }.values.sum()
    fun valueOnDay(day: Int): Int = daily[day] ?: 0
    fun valueOnDate(date: LocalDate): Int = dailyByDate[date] ?: daily[date.dayOfMonth] ?: 0

    /** Display-only summary for the continuous/My Devices table. This does not
     * alter payment calculation or payment resolver pathways. */
    fun monthToDate(asOf: LocalDate): Int = dailyByDate.entries
        .filter { (date, _) -> YearMonth.from(date) == YearMonth.from(asOf) && !date.isAfter(asOf) }
        .sumOf { it.value }

    /** Display-only live-cycle total for the continuous/My Devices table. */
    fun cycleTotal(asOf: LocalDate): Int = run {
        val start = PaymentRules.paymentCycleForDate(asOf).first
        dailyByDate.entries
            .filter { (date, _) -> !date.isBefore(start) && !date.isAfter(asOf) }
            .sumOf { it.value }
    }
}

data class SimRegReport(
    val sourceName: String,
    val reportType: String,
    val coverageStart: LocalDate?,
    val coverageEnd: LocalDate?,
    val sheetName: String,
    val rows: List<SimRegReportRow>,
    val isContinuous: Boolean = false
) {
    val cutoffDay: Int get() = coverageEnd?.dayOfMonth ?: rows.flatMap { it.daily.keys }.maxOrNull() ?: 0
    val totalMtd: Int get() = rows.sumOf { it.mtd(cutoffDay) }
    val isActivationReport: Boolean get() = reportType.equals("ACTIVATIONS", ignoreCase = true)
}

object SimRegReportParser {
    fun read(context: Context, uri: Uri, sourceName: String = "SIMReg report"): SimRegReport? = runCatching {
        context.contentResolver.openInputStream(uri)?.use { parse(it, sourceName) }
    }.getOrNull()

    fun parse(input: InputStream, sourceName: String): SimRegReport {
        // Do not materialize every XLSX ZIP entry (images, drawings, styles, etc.).
        // Large workbooks can contain a surprising amount of unrelated binary data.
        // We only need workbook metadata, shared strings, relationships and worksheets.
        val entries = linkedMapOf<String, ByteArray>()
        ZipInputStream(input.buffered()).use { z ->
            while (true) {
                val e = z.nextEntry ?: break
                if (e.isDirectory) continue
                val name = e.name
                val needed = name == "xl/workbook.xml" ||
                    name == "xl/sharedStrings.xml" ||
                    name == "xl/_rels/workbook.xml.rels" ||
                    name.startsWith("xl/worksheets/")
                if (needed) entries[name] = z.readBytes()
            }
        }
        require(entries.containsKey("xl/workbook.xml")) { "This is not a readable modern .xlsx workbook." }
        val shared = entries["xl/sharedStrings.xml"]?.let(::sharedStrings).orEmpty()
        val workbook = entries["xl/workbook.xml"]?.let(::workbookSheets).orEmpty()
        val rels = entries["xl/_rels/workbook.xml.rels"]?.let(::workbookRels).orEmpty()
        val sheetEntries = workbook.mapNotNull { (name, rid) ->
            val target = rels[rid] ?: return@mapNotNull null
            val path = when {
                target.startsWith("/") -> target.removePrefix("/")
                target.startsWith("xl/") -> target
                else -> "xl/$target"
            }.replace("xl/xl/", "xl/")
            if (entries[path] == null) null else Triple(name, path, entries[path]!!)
        }
        require(sheetEntries.isNotEmpty()) { "No readable worksheets were found." }

        // Most workbooks contain extra sheets. Parse only a small preview from each
        // sheet to find the detailed device table, then fully parse that one sheet.
        // This avoids parsing thousands of irrelevant rows before the real report is
        // even displayed.
        val previews = sheetEntries.map { (name, _, bytes) ->
            RawSheet(name, parseRows(bytes, shared, maxRows = 220))
        }

        // Date/type detection only needs report headings and the beginning of each
        // sheet. Joining an entire workbook into one giant String is needlessly
        // expensive for large reports and can create a large temporary heap spike.
        val diagnosticText = previews
            .flatMap { it.rows.take(120).flatten() }
            .joinToString(" ")
        val workbookRange = dateRange(diagnosticText)
        val filenameCoverage = filenameCoverage(sourceName, workbookRange)
        val (start, end) = resolveCoverage(filenameCoverage, workbookRange)
        DevMonitorLogger.import("coverage source=${if (filenameCoverage != null) "filename" else "workbook"} file=\"$sourceName\" start=$start end=$end workbookStart=${workbookRange.first} workbookEnd=${workbookRange.second}")
        val type = when {
            Regex("(?i)activations?\\s+as\\s+at").containsMatchIn(diagnosticText) -> "ACTIVATIONS"
            Regex("(?i)sim\\s*reg\\s+as\\s+at").containsMatchIn(diagnosticText) -> "SIM REG"
            Regex("(?i)activation").containsMatchIn(diagnosticText) -> "ACTIVATIONS"
            else -> "SIM REG / ACTIVATION REPORT"
        }
        val detailedPreview = previews.maxByOrNull { score(it.rows) } ?: error("No detailed SIMReg sheet found")
        val detailedBytes = sheetEntries.firstOrNull { it.first == detailedPreview.name }?.third
            ?: error("No readable bytes for detailed SIMReg sheet")
        val detailed = RawSheet(detailedPreview.name, parseRows(detailedBytes, shared))
        val headerIndex = detailed.rows.indexOfFirst { scoreHeader(it) >= 5 }
        if (headerIndex < 0) error("No detailed device table found")
        val headers = detailed.rows[headerIndex].map { normalizeHeader(it) }
        fun idx(vararg names: String): Int = names.map { normalizeHeader(it) }
            .firstNotNullOfOrNull { n -> headers.indexOfFirst { it == n }.takeIf { it >= 0 } } ?: -1
        val trade = idx("TRADE CODE")
        val partner = idx("CHANNEL PARTNER NAME")
        val device = idx("DEVICE ID", "DEVICE / PARTNER CODE", "DEVICE CODE")
        val cluster = idx("CLUSTER")
        val region = idx("REGION")
        val territory = idx("TERRITORY")
        val staff = idx("STAFF NAME")
        if (device < 0) error("Detailed sheet has no Device ID column")
        val dailyColumns = headers.mapIndexedNotNull { i, h ->
            Regex("^-?([0-9]{1,2})$").matchEntire(h)?.let { i to it.groupValues[1].toInt() }
        }.filter { it.second in 1..31 }
        val total = idx("GRAND TOTAL", "TOTAL")
        val rows = detailed.rows.drop(headerIndex + 1).mapNotNull { r ->
            val id = r.getOrNull(device).orEmpty().trim()
            if (id.isBlank() || normalizeHeader(id) in setOf("DEVICE ID", "CODE", "TOTAL", "GRAND TOTAL")) return@mapNotNull null
            val daily = dailyColumns.mapNotNull { (i, day) ->
                val raw = r.getOrNull(i)?.replace(",", "")?.trim()
                val value = raw?.toDoubleOrNull()?.toInt()
                if (value == null) null else day to value
            }.toMap()
            val grand = if (total >= 0) numberOrNull(r.getOrNull(total)) ?: daily.values.sum() else daily.values.sum()
            SimRegReportRow(
                tradeCode = r.getOrNull(trade).orEmpty().trim(),
                partnerName = r.getOrNull(partner).orEmpty().trim(),
                deviceId = r.getOrNull(device).orEmpty().trim(),
                cluster = r.getOrNull(cluster).orEmpty().trim(),
                region = r.getOrNull(region).orEmpty().trim(),
                territory = r.getOrNull(territory).orEmpty().trim(),
                staffName = r.getOrNull(staff).orEmpty().trim(),
                daily = daily,
                grandTotal = grand
            )
        }.filter { it.deviceId.isNotBlank() }
        require(rows.isNotEmpty()) { "No device records were found in the detailed worksheet." }
        return SimRegReport(sourceName, type, start, end, detailed.name, rows)
    }

    private fun score(rows: List<List<String>>): Int {
        val flat = rows.take(20).flatten().map(::normalizeHeader)
        var s = 0
        listOf("DEVICE ID", "CHANNEL PARTNER NAME", "TRADE CODE", "CLUSTER", "REGION", "TERRITORY", "STAFF NAME").forEach {
            if (flat.contains(it)) s += 2
        }
        if (flat.any { Regex("^-?[0-9]{1,2}$").matches(it) }) s += 2
        return s + rows.size.coerceAtMost(5)
    }

    private fun scoreHeader(row: List<String>): Int {
        val h = row.map(::normalizeHeader)
        return listOf("DEVICE ID", "CHANNEL PARTNER NAME", "TRADE CODE", "CLUSTER", "REGION", "TERRITORY", "STAFF NAME").count { h.contains(it) }
    }

    private fun normalizeHeader(s: String) = s.trim().uppercase(Locale.US).replace(Regex("\\s+"), " ")
    private fun number(s: String?): Int = numberOrNull(s) ?: 0
    private fun numberOrNull(s: String?): Int? = s?.replace(",", "")?.trim()?.takeIf { it.isNotEmpty() }?.toDoubleOrNull()?.toInt()

    private data class FilenameCoverage(
        val start: LocalDate?,
        val end: LocalDate?
    )

    /**
     * Global date policy: report filenames are parsed by HumanDateParser rather
     * than by a collection of one-off regular expressions. This means ordinals,
     * full/short month names, numeric forms, ISO forms and mixed-format ranges
     * all follow the same rules everywhere in the app.
     */
    private fun filenameCoverage(sourceName: String, workbook: Pair<LocalDate?, LocalDate?>): FilenameCoverage? {
        val name = sourceName.substringAfterLast('/').substringBeforeLast('.', sourceName)
        val defaultYear = workbook.second?.year ?: workbook.first?.year ?: LocalDate.now().year
        val range = HumanDateParser.parseRange(name, defaultYear)
        if (range.start != null && range.end != null) return FilenameCoverage(range.start, range.end)

        val monthYear = HumanDateParser.parseMonthYear(name, defaultYear)
        if (monthYear != null) {
            return FilenameCoverage(monthYear.atDay(1), monthYear.atEndOfMonth())
        }

        return null
    }

    private fun resolveCoverage(filename: FilenameCoverage?, workbook: Pair<LocalDate?, LocalDate?>): Pair<LocalDate?, LocalDate?> {
        if (filename == null) return workbook
        val start = filename.start ?: workbook.first
        val end = filename.end ?: workbook.second
        if (start == null || end == null) return workbook
        // A precise filename range wins. Workbook text may supply a missing side,
        // but it must never silently replace an explicitly named filename date.
        return start to end
    }

    private fun dateRange(text: String): Pair<LocalDate?, LocalDate?> {
        val dates = HumanDateParser.extractDates(text)
        if (dates.isEmpty()) return null to null
        return dates.minOrNull() to dates.maxOrNull()
    }

    private fun sharedStrings(bytes: ByteArray): List<String> {
        val out = mutableListOf<String>()
        val p = Xml.newPullParser(); p.setInput(bytes.inputStream(), "UTF-8")
        var b = StringBuilder(); var inT = false
        while (p.next() != XmlPullParser.END_DOCUMENT) when (p.eventType) {
            XmlPullParser.START_TAG -> if (p.name == "t") { b = StringBuilder(); inT = true }
            XmlPullParser.TEXT -> if (inT) b.append(p.text)
            XmlPullParser.END_TAG -> if (p.name == "t" && inT) { out.add(b.toString()); inT = false }
        }
        return out
    }

    private fun workbookSheets(bytes: ByteArray): List<Pair<String, String>> {
        val out = mutableListOf<Pair<String, String>>()
        val p = Xml.newPullParser(); p.setInput(bytes.inputStream(), "UTF-8")
        while (p.next() != XmlPullParser.END_DOCUMENT) {
            if (p.eventType == XmlPullParser.START_TAG && p.name == "sheet") {
                val name = p.getAttributeValue(null, "name").orEmpty()
                val rid = p.getAttributeValue("http://schemas.openxmlformats.org/officeDocument/2006/relationships", "id").orEmpty()
                out.add(name to rid)
            }
        }
        return out
    }

    private fun workbookRels(bytes: ByteArray): Map<String, String> {
        val out = mutableMapOf<String, String>()
        val p = Xml.newPullParser(); p.setInput(bytes.inputStream(), "UTF-8")
        while (p.next() != XmlPullParser.END_DOCUMENT) {
            if (p.eventType == XmlPullParser.START_TAG && p.name == "Relationship") {
                out[p.getAttributeValue(null, "Id")] = p.getAttributeValue(null, "Target")
            }
        }
        return out
    }

    private fun parseRows(bytes: ByteArray, shared: List<String>, maxRows: Int? = null): List<List<String>> {
        val rows = mutableListOf<List<String>>()
        val p = Xml.newPullParser(); p.setInput(bytes.inputStream(), "UTF-8")
        var row = mutableListOf<String>(); var cellType = ""; var value = ""; var currentCol = 0
        while (p.next() != XmlPullParser.END_DOCUMENT) when (p.eventType) {
            XmlPullParser.START_TAG -> when (p.name) {
                "row" -> row = mutableListOf()
                "c" -> {
                    cellType = p.getAttributeValue(null, "t").orEmpty()
                    currentCol = colIndex(p.getAttributeValue(null, "r").orEmpty())
                    while (row.size <= currentCol) row.add("")
                }
                "v", "t" -> value = ""
            }
            XmlPullParser.TEXT -> value += p.text
            XmlPullParser.END_TAG -> when (p.name) {
                "v" -> row[currentCol] = if (cellType == "s") shared.getOrNull(value.toIntOrNull() ?: -1).orEmpty() else value
                "t" -> if (cellType == "inlineStr") row[currentCol] = value
                "row" -> {
                    rows.add(row.toList())
                    if (maxRows != null && rows.size >= maxRows) return rows
                }
            }
        }
        return rows
    }

    private fun colIndex(ref: String): Int {
        val letters = ref.takeWhile { it.isLetter() }
        var n = 0
        for (c in letters) n = n * 26 + (c.uppercaseChar() - 'A' + 1)
        return (n - 1).coerceAtLeast(0)
    }
}

private data class HierarchyLine(val label: String, val devices: Int, val activity: Int)
private data class BridgeLine(val code: String, val hq: Boolean, val local: Boolean, val localLatest: Int?)

private fun normalizedReportType(type: String): String = when {
    type.equals("ACTIVATIONS", true) -> "ACTIVATIONS"
    type.equals("SIM REG", true) -> "SIM REG"
    else -> type
}

private fun reportCutoffDate(report: SimRegReport): LocalDate? = report.coverageEnd

private fun sumRange(report: SimRegReport, fromDay: Int, toDay: Int): Int {
    if (fromDay > toDay) return 0
    return report.rows.sumOf { row -> (fromDay..toDay).sumOf { row.valueOnDay(it) } }
}

private fun sumDeviceRange(report: SimRegReport, deviceId: String, fromDay: Int, toDay: Int): Int =
    report.rows.filter { it.deviceId.equals(deviceId, true) }.sumOf { row -> (fromDay..toDay).sumOf { row.valueOnDay(it) } }

private fun cycleFor(date: LocalDate): Pair<LocalDate, LocalDate> = if (date.dayOfMonth >= 21) {
    date.withDayOfMonth(21) to date.plusMonths(1).withDayOfMonth(20)
} else {
    date.minusMonths(1).withDayOfMonth(21) to date.withDayOfMonth(20)
}

private fun cycleActivationTotal(reports: List<SimRegReport>, asAt: LocalDate): Int? {
    val liveAsOf = PaymentRules.currentAwareDate(asAt)
    val activations = reports.filter { it.isActivationReport && it.coverageEnd != null }
    if (activations.isEmpty()) return null
    val (start, end) = cycleFor(liveAsOf)
    var total = 0
    var month = YearMonth.from(start)
    val endMonth = YearMonth.from(end)
    while (!month.isAfter(endMonth)) {
        val monthEnd = if (month == YearMonth.from(end)) end.dayOfMonth else month.lengthOfMonth()
        val monthStart = if (month == YearMonth.from(start)) start.dayOfMonth else 1
        val candidates = activations.filter { YearMonth.from(it.coverageEnd!!) == month && !it.coverageEnd!!.isBefore(LocalDate.of(month.year, month.month, monthEnd)) }
        val report = candidates.maxByOrNull { it.coverageEnd!! }
            ?: activations.filter { YearMonth.from(it.coverageEnd!!) == month }.maxByOrNull { it.coverageEnd!! }
            ?: return null
        val availableTo = if (month == YearMonth.from(liveAsOf)) {
            minOf(monthEnd, report.cutoffDay, liveAsOf.dayOfMonth)
        } else {
            minOf(monthEnd, report.cutoffDay)
        }
        if (availableTo < monthStart) return null
        total += sumRange(report, monthStart, availableTo)
        month = month.plusMonths(1)
    }
    return total
}

@Composable
private fun SimRegLoadingAnimation(progress: Float) {
    val infinite = rememberInfiniteTransition(label = "simreg-book")
    val openSweep by infinite.animateFloat(
        initialValue = 0.92f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "book-open"
    )
    val pageSweep by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1900, easing = FastOutSlowInEasing), RepeatMode.Restart),
        label = "page-turn"
    )
    val animatedProgress by animateFloatAsState(
        targetValue = progress.coerceIn(0f, 1f),
        animationSpec = tween(450, easing = FastOutSlowInEasing),
        label = "loading-progress"
    )

    val pageColor = MaterialTheme.colorScheme.surfaceContainerHigh
    val pageEdge = MaterialTheme.colorScheme.primary
    val pageAccent = MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)
    val glow = pageEdge.copy(alpha = 0.12f + (openSweep - 0.92f) * 0.6f)

    Box(Modifier.fillMaxWidth().height(142.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(150.dp)) {
            val w = size.width
            val h = size.height
            val centerX = w / 2f
            val top = h * 0.20f
            val bottom = h * 0.78f
            val half = w * 0.34f
            val depth = 0.80f + (openSweep - 0.92f) * 1.6f
            val leftRight = half * depth

            drawCircle(glow, radius = w * 0.43f, center = androidx.compose.ui.geometry.Offset(centerX, h * 0.50f))

            drawRoundRect(
                color = pageColor,
                topLeft = androidx.compose.ui.geometry.Offset(centerX - leftRight, top),
                size = androidx.compose.ui.geometry.Size(leftRight, bottom - top),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(16f, 16f)
            )
            drawRoundRect(
                color = pageColor,
                topLeft = androidx.compose.ui.geometry.Offset(centerX, top),
                size = androidx.compose.ui.geometry.Size(leftRight, bottom - top),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(16f, 16f)
            )
            drawLine(pageEdge, androidx.compose.ui.geometry.Offset(centerX, top + 2f), androidx.compose.ui.geometry.Offset(centerX, bottom - 2f), strokeWidth = 4f)

            val lineAlpha = 0.45f
            for (i in 0..3) {
                val y = top + 20f + i * 12f
                drawLine(pageEdge.copy(alpha = lineAlpha), androidx.compose.ui.geometry.Offset(centerX - leftRight + 16f, y), androidx.compose.ui.geometry.Offset(centerX - 14f, y), strokeWidth = 2.5f)
                drawLine(pageEdge.copy(alpha = lineAlpha), androidx.compose.ui.geometry.Offset(centerX + 14f, y), androidx.compose.ui.geometry.Offset(centerX + leftRight - 16f, y), strokeWidth = 2.5f)
            }

            val flip = kotlin.math.sin(pageSweep * Math.PI).toFloat()
            val pageX = centerX + (leftRight - 10f) * flip
            drawRoundRect(
                color = pageAccent,
                topLeft = androidx.compose.ui.geometry.Offset(pageX - 7f, top + 10f),
                size = androidx.compose.ui.geometry.Size(12f, bottom - top - 20f),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f, 6f)
            )
        }
    }

    LinearProgressIndicator(
        progress = { animatedProgress },
        modifier = Modifier.fillMaxWidth().height(7.dp),
    )
}

@Composable
fun SimRegReportScreen(
    report: SimRegReport?,
    loading: Boolean = false,
    loadingTitle: String = "Loading SIMReg report…",
    importMessage: String = "",
    localRecords: Map<String, QueryRecord> = emptyMap(),
    companyActivations: CompanyActivationStore? = null,
    deviceMonitorStore: DatabaseStore? = null,
    myDevicesStore: MyDevicesStore? = null,
    onUpdateMyDevices: () -> Unit = {},
    partnerThreshold: Int = PaymentRules.DEFAULT_PARTNER_MIN_ACTIVATIONS,
    onPartnerThresholdChanged: (Int) -> Unit = {},
    onImport: () -> Unit,
    onOnlineImport: () -> Unit = {},
    modifier: Modifier = Modifier,
    loadingProgress: Float = 0f,
    onClose: () -> Unit
) {
    var continuousReport by remember { mutableStateOf<SimRegReport?>(null) }
    var myDeviceCodes by remember { mutableStateOf<Set<String>>(emptySet()) }
    var cachedMyDeviceRows by remember { mutableStateOf<List<SimRegReportRow>>(emptyList()) }
    var myDevicesWindow by remember { mutableStateOf<Pair<LocalDate, LocalDate>?>(null) }
    var showAllDevices by remember { mutableStateOf(false) }
    var myDevicesRefreshNonce by remember { mutableIntStateOf(0) }
    var storedReports by remember { mutableStateOf(emptyList<CompanyActivationStore.StoredReport>()) }
    var pendingDeleteReportId by remember { mutableStateOf<Long?>(null) }
    // My Devices is the primary working table. The full company database is only
    // materialized after the user explicitly chooses Show All.
    val viewReport = if (showAllDevices) {
        continuousReport
    } else if (cachedMyDeviceRows.isNotEmpty() || myDeviceCodes.isNotEmpty()) {
        SimRegReport(
            sourceName = "My Devices working set", reportType = "ACTIVATIONS",
            coverageStart = myDevicesWindow?.first, coverageEnd = myDevicesWindow?.second,
            sheetName = "My Devices", rows = cachedMyDeviceRows, isContinuous = true
        )
    } else {
        report
    }

    LaunchedEffect(myDevicesStore, companyActivations, report?.sourceName, myDevicesRefreshNonce) {
        val ms = myDevicesStore ?: return@LaunchedEffect
        val snapshot = withContext(kotlinx.coroutines.Dispatchers.IO) {
            val codes = ms.codes().map(::canonicalDeviceCode).toSet()
            val storedWindow = ms.workingWindow()
            val desiredWindow = PaymentRules.myDevicesWorkingWindow()
            val needsRefresh = codes.isNotEmpty() && (storedWindow != desiredWindow)
            val refreshed = if (needsRefresh && companyActivations != null) {
                val targeted = companyActivations.loadWorkingSetForDevices(codes.toList(), desiredWindow.first, desiredWindow.second)
                if (targeted != null) ms.replaceWorkingSet(targeted.rows, codes.toList(), desiredWindow.first, desiredWindow.second)
                ms.cachedRows()
            } else {
                ms.cachedRows()
            }
            Triple(codes, refreshed, if (needsRefresh) desiredWindow else storedWindow)
        }
        myDeviceCodes = snapshot.first
        cachedMyDeviceRows = snapshot.second
        myDevicesWindow = snapshot.third
    }

    LaunchedEffect(showAllDevices, companyActivations, report?.sourceName) {
        if (!showAllDevices) {
            continuousReport = null
            return@LaunchedEffect
        }
        val store = companyActivations ?: return@LaunchedEffect
        val started = android.os.SystemClock.elapsedRealtime()
        continuousReport = withContext(kotlinx.coroutines.Dispatchers.IO) { store.loadContinuousReport() }
        DevMonitorLogger.screen("Show All loaded devices=${continuousReport?.rows?.size ?: 0} elapsed=${android.os.SystemClock.elapsedRealtime() - started}ms")
    }

    LaunchedEffect(companyActivations, report?.sourceName) {
        val store = companyActivations ?: run {
            storedReports = emptyList()
            return@LaunchedEffect
        }
        storedReports = withContext(kotlinx.coroutines.Dispatchers.IO) { store.listReports() }
    }

    val scope = rememberCoroutineScope()

    var query by remember { mutableStateOf("") }
    var filterType by remember { mutableStateOf("All") }
    var rowView by remember(viewReport?.sourceName) { mutableStateOf("All") }
    var selectedDeviceId by remember { mutableStateOf<String?>(null) }
    var paymentDeviceId by remember { mutableStateOf<String?>(null) }
    var tableZoom by remember { mutableFloatStateOf(1f) }
    var showViewOptions by remember(viewReport?.sourceName) { mutableStateOf(false) }
    var showHierarchy by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    var tableHeaderIndex by remember { mutableStateOf<Int?>(null) }

    if (paymentDeviceId != null) {
        val code = paymentDeviceId!!
        val hqRow = viewReport?.rows?.firstOrNull { canonicalDeviceCode(it.deviceId) == canonicalDeviceCode(code) }
        DevicePaymentCardScreen(
            row = hqRow,
            localRecord = localRecords.entries.firstOrNull { canonicalDeviceCode(it.key) == canonicalDeviceCode(code) }?.value,
            reportIsActivation = viewReport?.isActivationReport == true,
            companyActivations = companyActivations,
            myDevicesStore = myDevicesStore,
            deviceMonitorStore = deviceMonitorStore,
            onBack = { paymentDeviceId = null }
        )
        return
    }

    LaunchedEffect(listState) {
        snapshotFlow { listState.layoutInfo.visibleItemsInfo.firstOrNull { it.key == "report_table_header" }?.index }
            .collectLatest { index -> if (index != null) tableHeaderIndex = index }
    }

    val fixedColumns = listOf("DEVICE ID" to 170.dp, "PARTNER" to 170.dp, "TRADE" to 120.dp, "CLUSTER" to 120.dp, "REGION" to 120.dp, "TERRITORY" to 130.dp, "STAFF" to 160.dp)
    val continuousDates = if (viewReport?.isContinuous == true && viewReport.coverageStart != null && viewReport.coverageEnd != null) {
        buildList { var d = viewReport.coverageStart!!; while (!d.isAfter(viewReport.coverageEnd!!)) { add(d); d = d.plusDays(1) } }
    } else emptyList()
    val dayColumns: List<Pair<String, Dp>> = if (viewReport?.isContinuous == true) continuousDates.map { it.toString() to 78.dp } else (1..31).map { it.toString().padStart(2, '0') to 72.dp }
    val continuousSummary = viewReport?.isContinuous == true
    val mtdLabel = if (continuousSummary) "MONTH-TO-DATE" else viewReport?.coverageStart?.month?.getDisplayName(TextStyle.SHORT, Locale.getDefault())?.let { "$it MTD" } ?: "Report MTD"
    val summaryColumns = if (continuousSummary) {
        listOf("__CYCLE__" to ("CYCLE TOTAL" to 100.dp), "__MTD__" to (mtdLabel to 110.dp))
    } else {
        listOf("__MTD__" to (mtdLabel to 90.dp), "TOTAL" to ("TOTAL" to 90.dp))
    }

    val defaultColumnVisibility = remember(viewReport?.sourceName, viewReport?.isContinuous, viewReport?.coverageStart, viewReport?.coverageEnd) {
        linkedMapOf<String, Boolean>().apply {
            listOf("DEVICE ID", "PARTNER", "TRADE", "CLUSTER", "REGION", "TERRITORY", "STAFF").forEach { put(it, true) }
            (1..31).forEach { put(it.toString().padStart(2, '0'), true) }
            if (viewReport?.isContinuous == true && viewReport.coverageStart != null && viewReport.coverageEnd != null) {
                var d = viewReport.coverageStart!!
                while (!d.isAfter(viewReport.coverageEnd!!)) { put(d.toString(), true); d = d.plusDays(1) }
            }
            summaryColumns.forEach { put(it.first, true) }
        }
    }
    var columnVisibility by remember(viewReport?.sourceName, viewReport?.coverageStart, viewReport?.coverageEnd, viewReport?.isContinuous) { mutableStateOf(defaultColumnVisibility.toMutableMap()) }

    val monthTint = viewReport?.coverageStart?.monthValue?.let { monthTintFor(it, isSystemInDarkTheme()) }
    val monthHeaderTint = viewReport?.coverageStart?.monthValue?.let { monthHeaderTintFor(it, isSystemInDarkTheme()) }
    val visibleFixedColumns = fixedColumns.filter { columnVisibility[it.first] != false }
    val visibleDayColumns = dayColumns.filter { columnVisibility[it.first] != false }
    val visibleEndColumns = summaryColumns.filter { columnVisibility[it.first] != false }.map { it.second }

    val tableScroll = rememberScrollState()
    val showShortDevice by remember { derivedStateOf { tableScroll.value > 8 } }

    // After a successful import/open, bring the workbook table into view so the
    // user immediately sees the newly loaded sheet rather than the previous page position.
    LaunchedEffect(viewReport?.sourceName, viewReport?.coverageEnd, loading) {
        if (viewReport != null && !loading) {
            kotlinx.coroutines.yield()
            val headerIndex = 11 + if (viewReport.isActivationReport) 1 else 0
            listState.animateScrollToItem(headerIndex)
        }
    }

    val tableGesture = Modifier.pointerInput(Unit) {
        awaitEachGesture {
            awaitFirstDown(requireUnconsumed = false)
            var previousDistance = 0f
            while (true) {
                val event = awaitPointerEvent()
                val pressed = event.changes.filter { it.pressed }
                if (pressed.size >= 2) {
                    val a = pressed[0].position; val b = pressed[1].position
                    val dx = b.x - a.x; val dy = b.y - a.y
                    val distance = sqrt(dx * dx + dy * dy)
                    if (previousDistance > 0f && distance > 0f) {
                        val change = distance / previousDistance
                        if (change.isFinite() && change != 1f) tableZoom = (tableZoom * change).coerceIn(0.6f, 2f)
                    }
                    previousDistance = distance
                    pressed.forEach { it.consume() }
                } else previousDistance = 0f
                if (event.changes.none { it.pressed }) break
            }
        }
    }

    val filtered = remember(viewReport, query, filterType, rowView) {
        val rows = viewReport?.rows.orEmpty()
        if (query.isBlank() && filterType == "All" && rowView == "All") rows else rows.filter { r ->
            val q = query.trim()
            val matches = q.isBlank() || listOf(r.deviceId, r.staffName, r.region, r.cluster, r.territory, r.partnerName, r.tradeCode).any { it.contains(q, true) }
            val typeOk = filterType == "All" || when (filterType) {
                "Staff" -> r.staffName.isNotBlank()
                "Partner" -> r.partnerName.isNotBlank()
                "Region" -> r.region.isNotBlank()
                "Cluster" -> r.cluster.isNotBlank()
                else -> true
            }
            val activityOk = when (rowView) { "Activity" -> r.grandTotal > 0; "Zero" -> r.grandTotal == 0; else -> true }
            matches && typeOk && activityOk
        }
    }

    if (showViewOptions) {
        AlertDialog(
            onDismissRequest = { showViewOptions = false },
            title = { Text("Customize report view") },
            text = {
                Column(Modifier.heightIn(max = 520.dp)) {
                    Column(Modifier.weight(1f, false).verticalScroll(rememberScrollState())) {
                        Text("Columns", fontWeight = FontWeight.Bold)
                        (fixedColumns.map { it.first to it.first } + dayColumns.map { it.first to it.first } + summaryColumns.map { it.first to it.second.first }).forEach { (key, label) ->
                            Row(Modifier.fillMaxWidth().clickable { columnVisibility = columnVisibility.toMutableMap().apply { put(key, !(this[key] ?: true)) } }.padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(columnVisibility[key] != false, { checked -> columnVisibility = columnVisibility.toMutableMap().apply { put(key, checked) } })
                                Text(label)
                            }
                        }
                        Spacer(Modifier.height(8.dp)); Text("Rows", fontWeight = FontWeight.Bold)
                        listOf("All", "Activity", "Zero").forEach { option ->
                            Row(Modifier.fillMaxWidth().clickable { rowView = option }.padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(rowView == option, { rowView = option }); Text(when (option) { "Activity" -> "Only rows with activity"; "Zero" -> "Only zero rows"; else -> "All rows" })
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton({ showViewOptions = false }) { Text("Done") } },
            dismissButton = { TextButton({ columnVisibility = defaultColumnVisibility.toMutableMap(); rowView = "All"; showViewOptions = false }) { Text("Reset view") } }
        )
    }

    if (showHierarchy && viewReport != null) {
        AlertDialog(
            onDismissRequest = { showHierarchy = false },
            title = { Text("HQ hierarchy dashboard") },
            text = {
                Column(Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Scope: ${if (query.isBlank()) "entire report" else query}", style = MaterialTheme.typography.bodySmall)
                    val hierarchyRows = listOf(
                        "Clusters" to filtered.groupBy { it.cluster.ifBlank { "Unassigned" } }.map { (k, v) -> HierarchyLine(k, v.size, v.sumOf { it.grandTotal }) }.sortedByDescending { it.activity },
                        "Regions" to filtered.groupBy { it.region.ifBlank { "Unassigned" } }.map { (k, v) -> HierarchyLine(k, v.size, v.sumOf { it.grandTotal }) }.sortedByDescending { it.activity },
                        "Staff" to filtered.groupBy { it.staffName.ifBlank { "Unassigned" } }.map { (k, v) -> HierarchyLine(k, v.size, v.sumOf { it.grandTotal }) }.sortedByDescending { it.activity },
                        "Territories" to filtered.groupBy { it.territory.ifBlank { "Unassigned" } }.map { (k, v) -> HierarchyLine(k, v.size, v.sumOf { it.grandTotal }) }.sortedByDescending { it.activity },
                        "Partners" to filtered.groupBy { it.partnerName.ifBlank { "Unassigned" } }.map { (k, v) -> HierarchyLine(k, v.size, v.sumOf { it.grandTotal }) }.sortedByDescending { it.activity }
                    )
                    hierarchyRows.forEach { (title, lines) ->
                        Text(title, fontWeight = FontWeight.Bold)
                        lines.take(10).forEach { line ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(line.label, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("${line.devices} devices • ${line.activity}")
                            }
                        }
                        if (lines.size > 10) Text("+ ${lines.size - 10} more", style = MaterialTheme.typography.bodySmall)
                    }
                }
            },
            confirmButton = { TextButton({ showHierarchy = false }) { Text("Done") } }
        )
    }




    pendingDeleteReportId?.let { deleteId ->
        val saved = storedReports.firstOrNull { it.id == deleteId }
        AlertDialog(
            onDismissRequest = { pendingDeleteReportId = null },
            title = { Text("Delete saved database record?") },
            text = {
                Text(
                    if (saved != null) {
                        "This removes the saved record ${saved.coverageStart ?: "unknown"} to ${saved.coverageEnd ?: "unknown"} from the normalized company database. It does not delete the original Excel file."
                    } else {
                        "This removes the selected saved company report from the normalized database."
                    }
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        pendingDeleteReportId = null
                        val store = companyActivations
                        if (store != null) {
                            scope.launch {
                                val (refreshedReports, refreshedContinuous) =
                                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                                        store.deleteReport(deleteId)
                                        store.listReports() to store.loadContinuousReport()
                                    }
                                storedReports = refreshedReports
                                continuousReport = refreshedContinuous
                            }
                        }
                    }
                ) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { pendingDeleteReportId = null }) { Text("Cancel") }
            }
        )
    }

    Box(modifier.fillMaxSize().then(tableGesture)) {
        LazyColumn(
            Modifier.fillMaxSize(),
            state = listState,
            contentPadding = PaddingValues(start = 16.dp, top = 16.dp, end = 16.dp, bottom = 140.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
        item {
            Card { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("SIMReg Report Intelligence", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
                Text("Load the company's SIM Reg as-at or Activations as-at workbook. DevMonitor reads the workbook as temporary input and saves normalized activation data only.")
                DevMonitorButton(onClick = onImport, Modifier.fillMaxWidth(), enabled = !loading) { Text(if (viewReport == null) "Load Company SIMReg Report" else "Load Another Company Report") }
                DevMonitorOutlinedButton(onClick = onOnlineImport, Modifier.fillMaxWidth(), enabled = !loading) { Text("Download Report Online") }
                if (myDeviceCodes.isNotEmpty()) {
                    DevMonitorOutlinedButton(onClick = { showAllDevices = false; onUpdateMyDevices(); myDevicesRefreshNonce++ }, Modifier.fillMaxWidth(), enabled = !loading) {
                        Text("↻ Update My Devices (${myDeviceCodes.size})")
                    }
                    DevMonitorOutlinedButton(
                        onClick = { showAllDevices = !showAllDevices },
                        Modifier.fillMaxWidth(), enabled = !loading
                    ) { Text(if (showAllDevices) "← Show My Devices" else "Show All Devices") }
                    Text(
                        if (showAllDevices) "Showing the full company database. My Devices remains the primary working set."
                        else "Primary working database: My Devices only. The full company database remains stored and is available through Show All.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    myDevicesWindow?.let { (start, end) ->
                        Text("Working window: $start → $end", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Text(
                    "Choose any Excel report from the online folder. The latest report is shown first.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                DevMonitorOutlinedButton(onClick = onClose, Modifier.fillMaxWidth()) { Text("Close Report") }
            } }
        }
        item {
            Card {
                Column(
                    Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("Normalized database records", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                    Text(
                        "These are the company report records currently saved in the normalized database. Opening one only changes the table view; it does not re-import the Excel file.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    if (storedReports.isEmpty()) {
                        Text(
                            "No saved company report records found.",
                            color = MaterialTheme.colorScheme.error,
                            fontWeight = FontWeight.Bold
                        )
                    } else {
                        storedReports.forEach { saved ->
                            val startText = saved.coverageStart?.toString() ?: "Unknown start"
                            val endText = saved.coverageEnd?.toString() ?: "Unknown end"
                            Column(
                                Modifier
                                    .fillMaxWidth()
                                    .background(MaterialTheme.colorScheme.surfaceVariant)
                                    .padding(10.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text("$startText to $endText", fontWeight = FontWeight.Bold)
                                Text(
                                    "${saved.sourceName} • ${saved.deviceCount} devices • ${saved.dayCount} saved daily values",
                                    style = MaterialTheme.typography.bodySmall
                                )
                                Row(
                                    Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    DevMonitorOutlinedButton(
                                        onClick = {
                                            showAllDevices = true
                                            DevMonitorLogger.screen("inventory Show All selected id=${saved.id}; full company database requested")
                                        },
                                        Modifier.weight(1f)
                                    ) { Text("Show All") }
                                    DevMonitorOutlinedButton(
                                        onClick = { pendingDeleteReportId = saved.id },
                                        Modifier.weight(1f)
                                    ) { Text("Delete") }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (loading) item {
            AuroraGlassCard(Modifier.fillMaxWidth(), AuroraCyan) {
                Column(
                    Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    SimRegLoadingAnimation(progress = loadingProgress)
                    Text(loadingTitle, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
                    Text(
                        importMessage.ifBlank { "Reading and processing the Excel workbook…" },
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(
                        "${(loadingProgress.coerceIn(0f, 1f) * 100f).toInt()}%",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
        viewReport?.let { r ->
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("⚠ PAYMENT / INCENTIVE WARNING", fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.error)
                        Text("DevMonitor cannot certify company payment, activation, incentive or settlement records. Figures here are monitoring/estimation only. The company's official data remains final.", fontWeight = FontWeight.Bold)
                        if (!r.isActivationReport) Text("This is a SIM Reg report: registration is NOT automatically activation. Do not convert registration MTD into an activation payout estimate.", fontWeight = FontWeight.Bold)
                    }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    DevMonitorOutlinedButton({ showHierarchy = true }, Modifier.weight(1f)) { Text("Hierarchy") }
                }
            }
            item { OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), label = { Text("Search staff, region, cluster, territory, partner, trade or Device ID") }, singleLine = true) }
            item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("All", "Staff", "Region", "Cluster", "Partner").forEach { f -> FilterChip(filterType == f, { filterType = f }, label = { Text(f) }, modifier = Modifier.weight(1f)) } } }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text("Excel-style report view", fontWeight = FontWeight.Bold); Text("Tap a row to select it. The column header stays visible while rows scroll. Device ID stays pinned and changes to the SMS short code when you scroll right. Pinch with two fingers to zoom; there are no visible zoom controls.", style = MaterialTheme.typography.bodySmall) }
                    DevMonitorOutlinedButton({ showViewOptions = true }) { Text("Customize View") }
                }
            }


            item(key = "report_table_header") {
                Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface)) {
                    val deviceHeader = visibleFixedColumns.firstOrNull { it.first == "DEVICE ID" }
                    if (deviceHeader != null) {
                        TableCell("DEVICE ID", deviceHeader.second, true, false, null, tableZoom)
                    }
                    Row(Modifier.weight(1f).horizontalScroll(tableScroll)) {
                        visibleFixedColumns.filterNot { it.first == "DEVICE ID" }.forEach { (label, width) ->
                            TableCell(label, width, true, false, null, tableZoom)
                        }
                        visibleDayColumns.forEach { (label, width) ->
                            val header = if (viewReport?.isContinuous == true) runCatching { LocalDate.parse(label).formatMonthDay() }.getOrDefault(label) else label
                            TableCell(header, width, true, false, null, tableZoom, if (viewReport?.isContinuous == true) runCatching { monthTintFor(LocalDate.parse(label).monthValue, isSystemInDarkTheme()) }.getOrNull() else monthHeaderTint)
                        }
                        visibleEndColumns.forEach { (label, width) ->
                            TableCell(label, width, true, false, null, tableZoom)
                        }
                    }
                }
            }
            items(filtered.take(300), key = { it.deviceId }) { row ->
                val rowFocused = selectedDeviceId == row.deviceId
                Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface)) {
                    val deviceColumn = visibleFixedColumns.firstOrNull { it.first == "DEVICE ID" }
                    if (deviceColumn != null) {
                        TableCell(
                            if (showShortDevice) canonicalDeviceCode(row.deviceId) else row.deviceId,
                            deviceColumn.second,
                            false,
                            rowFocused,
                            { paymentDeviceId = row.deviceId },
                            tableZoom
                        )
                    }
                    Row(
                        Modifier
                            .weight(1f)
                            .horizontalScroll(tableScroll)
                            .clickable { selectedDeviceId = row.deviceId }
                    ) {
                        visibleFixedColumns.filterNot { it.first == "DEVICE ID" }.forEach { (label, width) ->
                            val value = when (label) {
                                "PARTNER" -> row.partnerName.ifBlank { "-" }
                                "TRADE" -> row.tradeCode.ifBlank { "-" }
                                "CLUSTER" -> row.cluster.ifBlank { "-" }
                                "REGION" -> row.region.ifBlank { "-" }
                                "TERRITORY" -> row.territory.ifBlank { "-" }
                                "STAFF" -> row.staffName.ifBlank { "-" }
                                else -> "-"
                            }
                            TableCell(value, width, false, rowFocused, { selectedDeviceId = row.deviceId }, tableZoom)
                        }
                        visibleDayColumns.forEach { (label, width) ->
                            val value = if (viewReport?.isContinuous == true) runCatching { row.valueOnDate(LocalDate.parse(label)) }.getOrDefault(0) else row.valueOnDay(label.toIntOrNull() ?: 0)
                            val tint = if (viewReport?.isContinuous == true) runCatching { monthTintFor(LocalDate.parse(label).monthValue, isSystemInDarkTheme()) }.getOrNull() else monthTint
                            TableCell(value.toString(), width, false, rowFocused, { selectedDeviceId = row.deviceId }, tableZoom, tint)
                        }
                        visibleEndColumns.forEach { (label, width) ->
                            val value = if (continuousSummary) {
                                when (label) {
                                    "CYCLE TOTAL" -> row.cycleTotal(PaymentRules.currentAwareDate(LocalDate.now())).toString()
                                    mtdLabel -> row.monthToDate(PaymentRules.currentAwareDate(LocalDate.now())).toString()
                                    else -> row.grandTotal.toString()
                                }
                            } else if (label == mtdLabel) {
                                row.mtd(r.cutoffDay).toString()
                            } else {
                                row.grandTotal.toString()
                            }
                            TableCell(value, width, false, rowFocused, { selectedDeviceId = row.deviceId }, tableZoom)
                        }
                    }
                }
            }
            if (filtered.size > 300) item { Text("Showing first 300 matches. Narrow the search to investigate a specific scope.") }
        }
    }

    val showStickyTableHeader = tableHeaderIndex != null && listState.firstVisibleItemIndex > (tableHeaderIndex ?: Int.MAX_VALUE)
        if (showStickyTableHeader) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(horizontal = 16.dp)
            ) {
                val deviceHeader = visibleFixedColumns.firstOrNull { it.first == "DEVICE ID" }
                if (deviceHeader != null) {
                    TableCell("DEVICE ID", deviceHeader.second, true, false, null, tableZoom)
                }
                Row(Modifier.weight(1f).horizontalScroll(tableScroll)) {
                    visibleFixedColumns.filterNot { it.first == "DEVICE ID" }.forEach { (label, width) ->
                        TableCell(label, width, true, false, null, tableZoom)
                    }
                    visibleDayColumns.forEach { (label, width) ->
                        val header = if (viewReport?.isContinuous == true) runCatching { LocalDate.parse(label).formatMonthDay() }.getOrDefault(label) else label
                        TableCell(header, width, true, false, null, tableZoom, if (viewReport?.isContinuous == true) runCatching { monthTintFor(LocalDate.parse(label).monthValue, isSystemInDarkTheme()) }.getOrNull() else monthHeaderTint)
                    }
                    visibleEndColumns.forEach { (label, width) ->
                        TableCell(label, width, true, false, null, tableZoom)
                    }
                }
            }
        }
    }
}

private fun LocalDate.formatMonthDay(): String = "${month.getDisplayName(TextStyle.SHORT, Locale.getDefault())} ${dayOfMonth.toString().padStart(2, '0')}"

private fun Int.formatNaira(): String = "%d".format(Locale.US, this)

private fun monthTintFor(month: Int, dark: Boolean): Color = when ((month - 1) % 3) {
    0 -> if (dark) Color(0xFF203A28) else Color(0xFFEAF6ED) // green
    1 -> if (dark) Color(0xFF3B351F) else Color(0xFFFFF7DE) // amber
    else -> if (dark) Color(0xFF1D3740) else Color(0xFFE8F8FC) // cyan
}

private fun monthHeaderTintFor(month: Int, dark: Boolean): Color = when ((month - 1) % 3) {
    0 -> if (dark) Color(0xFF31553C) else Color(0xFFD5EBDD)
    1 -> if (dark) Color(0xFF5A512D) else Color(0xFFFFEDB5)
    else -> if (dark) Color(0xFF315764) else Color(0xFFD3F1F7)
}

@Composable
private fun TableCell(
    text: String,
    width: Dp,
    header: Boolean = false,
    focused: Boolean = false,
    onClick: (() -> Unit)? = null,
    zoom: Float = 1f,
    monthTint: Color? = null
) {
    Box(
        Modifier
            .width(width * zoom)
            .heightIn(min = 44.dp * zoom)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .background(when {
                focused && header -> MaterialTheme.colorScheme.primaryContainer
                focused -> MaterialTheme.colorScheme.secondaryContainer
                monthTint != null -> monthTint
                header -> MaterialTheme.colorScheme.surfaceVariant
                else -> MaterialTheme.colorScheme.surface
            })
            .padding(horizontal = 8.dp, vertical = 6.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        Text(text, fontWeight = if (header) FontWeight.Bold else FontWeight.Normal, fontSize = (14f * zoom).sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}
