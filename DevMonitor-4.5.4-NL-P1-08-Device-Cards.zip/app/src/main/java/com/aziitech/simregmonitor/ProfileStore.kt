package com.aziitech.simregmonitor

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Global profile registry. Only profile metadata and the active profile ID live here. */
data class DeviceProfile(
    val id: String, val name: String, val phone: String, val userType: String,
    val staffLevel: String, val partnerCode: String, val deviceId: String,
    val division: String, val region: String, val staffName: String,
    val territory: String, val codes: List<String>
)

class ProfileStore(private val context: Context) {
    companion object {
        const val PREFS_NAME = "fieldpulse_profiles"
        const val PROFILES_PREF = "device_profiles_v2"
        const val ACTIVE_ID_PREF = "active_device_profile_id"
    }
    private val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun load(): List<DeviceProfile> {
        val raw = prefs.getString(PROFILES_PREF, "").orEmpty()
        if (raw.isBlank()) migrateLegacyIfNeeded()
        return decode(prefs.getString(PROFILES_PREF, "").orEmpty())
    }
    fun activeId(): String? = prefs.getString(ACTIVE_ID_PREF, null)?.takeIf { it.isNotBlank() }
    fun setActive(id: String) { prefs.edit().putString(ACTIVE_ID_PREF, id).apply() }
    fun saveAll(profiles: List<DeviceProfile>) { prefs.edit().putString(PROFILES_PREF, encode(profiles)).apply() }

    private fun migrateLegacyIfNeeded() {
        val legacy = StateStore(context)
        try {
            if (legacy.getSetting("my_devices_setup_complete") != "true") return
            val codes = legacy.getSetting("my_devices_codes").orEmpty().replace('|', '\n').lines()
                .flatMap { it.split(',', '\t', ';') }.map(::canonicalDeviceCode).filter { it.isNotBlank() }.distinct()
            val profile = DeviceProfile(
                id="default", name=legacy.getSetting("my_devices_name").orEmpty().ifBlank { "My Devices" },
                phone=legacy.getSetting("my_devices_phone").orEmpty(), userType=legacy.getSetting("my_devices_user_type").orEmpty(),
                staffLevel=legacy.getSetting("my_devices_staff_level").orEmpty(), partnerCode=legacy.getSetting("my_devices_partner_code").orEmpty(),
                deviceId=legacy.getSetting("my_devices_device_id").orEmpty(), division=legacy.getSetting("my_devices_division").orEmpty(),
                region=legacy.getSetting("my_devices_region").orEmpty(), staffName=legacy.getSetting("my_devices_staff_name").orEmpty(),
                territory=legacy.getSetting("my_devices_territory").orEmpty(), codes=codes)
            legacy.close()
            migrateLegacyDatabaseFile(context, profile.id)
            saveAll(listOf(profile)); setActive(profile.id)
        } finally { runCatching { legacy.close() } }
    }

    private fun migrateLegacyDatabaseFile(context: Context, profileId: String) {
        if (profileId != "default") return
        val old = context.getDatabasePath(ProfileDatabaseNames.LEGACY_DATABASE)
        val target = context.getDatabasePath(ProfileDatabaseNames.deviceMonitor(profileId))
        if (!old.exists() || target.exists()) return
        old.copyTo(target, overwrite = false)
        listOf("-wal", "-shm").forEach { suffix ->
            val sidecar = java.io.File(old.path + suffix)
            if (sidecar.exists()) sidecar.copyTo(java.io.File(target.path + suffix), overwrite = false)
        }
    }

    private fun encode(profiles: List<DeviceProfile>) = JSONArray().apply {
        profiles.forEach { p -> put(JSONObject().apply {
            put("id",p.id); put("name",p.name); put("phone",p.phone); put("userType",p.userType); put("staffLevel",p.staffLevel)
            put("partnerCode",p.partnerCode); put("deviceId",p.deviceId); put("division",p.division); put("region",p.region)
            put("staffName",p.staffName); put("territory",p.territory); put("codes",JSONArray(p.codes))
        }) }
    }.toString()

    private fun decode(raw:String):List<DeviceProfile> {
        if (raw.isBlank()) return emptyList(); val a=runCatching{JSONArray(raw)}.getOrNull()?:return emptyList(); val out=mutableListOf<DeviceProfile>()
        for(i in 0 until a.length()) { val o=a.optJSONObject(i)?:continue; val codes=mutableListOf<String>(); val ca=o.optJSONArray("codes")?:JSONArray()
            for(j in 0 until ca.length()){val c=canonicalDeviceCode(ca.optString(j));if(c.isNotBlank()&&c !in codes)codes.add(c)}
            out+=DeviceProfile(o.optString("id").ifBlank{UUID.randomUUID().toString()},o.optString("name").ifBlank{"My Devices"},o.optString("phone"),o.optString("userType"),o.optString("staffLevel"),o.optString("partnerCode"),o.optString("deviceId"),o.optString("division"),o.optString("region"),o.optString("staffName"),o.optString("territory"),codes)
        }; return out
    }
}
