package com.aziitech.simregmonitor

import java.time.LocalDate
import java.time.YearMonth

/**
 * Reconstructs ONLY the live 21st-to-20th payment cycle.
 *
 * The payment-cycle start is a hard boundary: data before cycleStart can never
 * contribute to the current Device Monitor progression. This is especially
 * important on rollover day (the 21st), when the previous cycle must reset to 0
 * until the new cycle has qualifying data.
 *
 * Loaded Reports provide normalized daily activation values. Device Monitor SMS
 * observations provide the company's cumulative calendar-month Active counter.
 * They may be stitched within the current cycle, but neither source may import
 * the previous payment cycle into the new one.
 */
object PaymentCycleResolver {
    data class Result(
        val cycleStart: LocalDate,
        val cycleEnd: LocalDate,
        val asOf: LocalDate,
        val total: Int,
        val knownFrom: LocalDate?,
        val complete: Boolean,
        val sourceSummary: String,
        val smsOverrideToday: Int? = null
    )

    fun resolve(
        deviceId: String,
        asOfRequested: LocalDate = LocalDate.now(),
        companyStore: CompanyActivationStore?,
        deviceStore: DatabaseStore,
        myDevicesStore: MyDevicesStore? = null
    ): Result {
        val asOf = PaymentRules.currentAwareDate(asOfRequested)
        // HARD PAYMENT-CYCLE BOUNDARY:
        // On/after the 21st, the previous cycle is closed. Only dates from the
        // new 21st through today are eligible. For example, on 2026-09-21 the
        // active cycle is 2026-09-21..2026-10-20; August and Sep 1..20 are
        // historical and must not contribute. When October arrives, Sep 21..30
        // naturally remains inside that October cycle.
        val (cycleStart, cycleEnd) = PaymentRules.paymentCycleForDate(asOf)
        val cycleLast = minOf(cycleEnd, asOf)
        val code = canonicalDeviceCode(deviceId)

        if (cycleStart.isAfter(cycleLast)) {
            return Result(cycleStart, cycleEnd, asOf, 0, null, false, "No current-cycle dates are available yet.")
        }

        var total = 0
        var knownFrom: LocalDate? = null
        var complete = true
        val sourceLabels = mutableListOf<String>()
        var smsOverrideToday: Int? = null

        var month = YearMonth.from(cycleStart)
        val endMonth = YearMonth.from(cycleLast)
        while (!month.isAfter(endMonth)) {
            val segmentStart = maxOf(cycleStart, month.atDay(1))
            val segmentEnd = minOf(cycleLast, month.atEndOfMonth())
            val segment = resolveMonthSegment(code, month, segmentStart, segmentEnd, companyStore, deviceStore, myDevicesStore)
            total += segment.total
            if (segment.knownFrom != null && (knownFrom == null || segment.knownFrom.isBefore(knownFrom))) {
                knownFrom = segment.knownFrom
            }
            complete = complete && segment.complete
            if (segment.sourceSummary.isNotBlank()) sourceLabels += segment.sourceSummary
            if (segment.smsToday != null && segmentStart <= asOf && asOf <= segmentEnd) smsOverrideToday = segment.smsToday
            month = month.plusMonths(1)
        }

        val summary = sourceLabels.distinct().joinToString(" + ")
        DevMonitorLogger.payment(
            "cycle resolver device=$code CURRENT_CYCLE_ONLY cycle=$cycleStart..$cycleEnd asOf=$asOf total=$total knownFrom=${knownFrom ?: "none"} complete=$complete sources=${summary.ifBlank { "none" }}"
        )
        return Result(cycleStart, cycleEnd, asOf, total, knownFrom, complete, summary, smsOverrideToday)
    }

    private data class SegmentResult(
        val total: Int,
        val knownFrom: LocalDate?,
        val complete: Boolean,
        val sourceSummary: String,
        val smsToday: Int?
    )

    private fun resolveMonthSegment(
        code: String,
        month: YearMonth,
        segmentStart: LocalDate,
        segmentEnd: LocalDate,
        companyStore: CompanyActivationStore?,
        deviceStore: DatabaseStore,
        myDevicesStore: MyDevicesStore? = null
    ): SegmentResult {
        // IMPORTANT: a loaded activation report is authoritative for any exact
        // device/date it contains. SMS Active is cumulative and can represent
        // older calendar-month activity, so it must never overwrite a newer
        // normalized report row for the same date. This is the key rollover fix:
        // on 2026-09-21, a loaded value of 14 stays 14 instead of becoming the
        // previous-month/SMS-derived value (for example 42).
        val primaryLoaded = myDevicesStore?.dailyCoverageForDevice(code, segmentStart, segmentEnd).orEmpty()
        val loaded = if (primaryLoaded.isNotEmpty()) primaryLoaded else companyStore?.dailyCoverageForDevice(code, segmentStart, segmentEnd).orEmpty()
        val loadedSource = if (primaryLoaded.isNotEmpty()) "My Devices working database" else if (loaded.isNotEmpty()) "Normalized Loaded Reports fallback" else ""
        val observations = deviceStore.observationsBetween(code, month.atDay(1), segmentEnd)
            .filter { it.active != null || it.today != null }
            .sortedBy { it.date }

        val smsInSegment = observations.filter {
            val d = LocalDate.parse(it.date)
            !d.isBefore(segmentStart) && !d.isAfter(segmentEnd) && it.active != null
        }

        var total = loaded.values.sumOf { it.coerceAtLeast(0) }
        var knownFrom: LocalDate? = loaded.keys.minOrNull()
        var complete = true
        val sources = mutableListOf<String>()
        var smsToday: Int? = null

        if (loaded.isNotEmpty()) {
            sources += "${loadedSource.ifBlank { "Normalized Loaded Reports fallback" }} ${segmentStart}..${segmentEnd} (authoritative)"

            // SMS may fill dates AFTER the newest imported report date, but it
            // cannot replace an imported date. To calculate a cumulative SMS
            // delta safely, require an SMS Active snapshot on the last loaded
            // date; otherwise the pre-SMS portion is an unknown boundary and is
            // deliberately not guessed.
            val latestLoadedDate = loaded.keys.maxOrNull()!!
            val smsAfterLoaded = smsInSegment.filter { LocalDate.parse(it.date).isAfter(latestLoadedDate) }
            val baselineObservation = smsInSegment.lastOrNull { LocalDate.parse(it.date) == latestLoadedDate }

            if (smsAfterLoaded.isNotEmpty() && baselineObservation?.active != null) {
                var previousActive = baselineObservation.active ?: 0
                for (obs in smsAfterLoaded) {
                    val currentActive = obs.active ?: previousActive
                    total += (currentActive - previousActive).coerceAtLeast(0)
                    previousActive = currentActive
                }
                sources += "Device Monitor SMS delta after latest report"
            }

            // If the report explicitly covers a date but the device has no row,
            // that absence is still not permission to invent a zero. Keep the
            // result based on the rows actually normalized for this device.
            var d = segmentStart
            while (!d.isAfter(segmentEnd)) {
                if (!loaded.containsKey(d) && companyStore?.hasReportCoverage(d) != true) {
                    complete = false
                }
                d = d.plusDays(1)
            }
        } else if (smsInSegment.isNotEmpty()) {
            // No current-cycle report rows exist. SMS can therefore be used as
            // the live source, but only within the current payment-cycle boundary.
            val first = smsInSegment.first()
            val firstActive = first.active ?: 0
            val baseline = baselineActiveForMonth(code, month, segmentStart, LocalDate.parse(first.date), emptyMap(), observations, companyStore)
            if (baseline != null) {
                total = (firstActive - baseline).coerceAtLeast(0)
                knownFrom = segmentStart
                sources += "Device Monitor SMS Active"
            } else {
                // No trustworthy boundary snapshot: use today's/observed SMS
                // increments only rather than importing previous-cycle history.
                total = (first.today ?: 0).coerceAtLeast(0)
                knownFrom = LocalDate.parse(first.date)
                complete = false
                sources += "Device Monitor SMS from ${first.date}"
            }

            var previousActive = firstActive
            for (i in 1 until smsInSegment.size) {
                val current = smsInSegment[i]
                val currentActive = current.active ?: previousActive
                total += (currentActive - previousActive).coerceAtLeast(0)
                previousActive = currentActive
            }
        } else {
            // No current-cycle report rows and no SMS evidence.
            var d = segmentStart
            while (!d.isAfter(segmentEnd)) {
                if (companyStore?.hasReportCoverage(d) == true) {
                    if (knownFrom == null) knownFrom = d
                    sources += "Loaded Reports ${segmentStart}..${segmentEnd}"
                } else {
                    complete = false
                }
                d = d.plusDays(1)
            }
        }

        smsToday = smsInSegment.lastOrNull { LocalDate.parse(it.date) == segmentEnd }?.today
        return SegmentResult(total, knownFrom, complete, sources.distinct().joinToString("; "), smsToday)
    }

    private fun baselineActiveForMonth(
        code: String,
        month: YearMonth,
        segmentStart: LocalDate,
        firstSmsDate: LocalDate,
        loaded: Map<LocalDate, Int>,
        observations: List<DailyObservation>,
        companyStore: CompanyActivationStore?
    ): Int? {
        val boundary = segmentStart.minusDays(1)
        if (segmentStart == month.atDay(1)) return 0

        // A same-month SMS snapshot immediately before the payment segment is the
        // strongest boundary because it is the company's own Active counter.
        observations
            .filter { LocalDate.parse(it.date).isBefore(segmentStart) && it.active != null }
            .maxByOrNull { it.date }
            ?.let { return it.active }

        // Otherwise reconstruct the calendar-month Active baseline from the loaded
        // report only when THIS DEVICE has an explicit activation row for every date
        // needed. Global report coverage is insufficient: missing device/date rows are
        // unknown, not zero. Treating them as zero makes a calendar-month Active snapshot
        // look like payment-cycle sales and is exactly the report-import jump this resolver
        // must avoid.
        val monthStart = month.atDay(1)
        if (companyStore?.hasCompleteDeviceCoverage(code, monthStart, boundary) == true) {
            var sum = 0
            var d = monthStart
            while (!d.isAfter(boundary)) {
                val value = loaded[d] ?: return null
                sum += value.coerceAtLeast(0)
                d = d.plusDays(1)
            }
            DevMonitorLogger.payment(
                "SMS Active baseline device=$code month=$month boundary=$boundary source=loaded-report sum=$sum"
            )
            return sum
        }
        DevMonitorLogger.payment(
            "SMS Active baseline unavailable device=$code month=$month boundary=$boundary; loaded report cannot replace unknown dates with zero"
        )
        return null
    }
}
