package com.aziitech.simregmonitor

import android.content.Context
import java.time.LocalDate

/**
 * Profile-scoped operational state. The profile registry itself lives outside
 * this store; once a profile is active, all Device Monitor/SMS/query state is
 * routed to that profile's database.
 */
class StateStore(context: Context) {
    private val appContext = context.applicationContext
    private var db = openForActiveProfile()
    val database: DatabaseStore get() = db

    private fun openForActiveProfile(): DatabaseStore {
        val activeId = appContext.getSharedPreferences(ProfileStore.PREFS_NAME, Context.MODE_PRIVATE)
            .getString(ProfileStore.ACTIVE_ID_PREF, null)
        return if (activeId.isNullOrBlank()) {
            DatabaseStore(appContext, ProfileDatabaseNames.LEGACY_DATABASE)
        } else {
            DatabaseStore(appContext, ProfileDatabaseNames.deviceMonitor(activeId))
        }
    }

    fun switchProfile(profileId: String) {
        db.close()
        appContext.getSharedPreferences(ProfileStore.PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putString(ProfileStore.ACTIVE_ID_PREF, profileId).apply()
        db = openForActiveProfile()
    }

    fun close() = db.close()
    fun saveCurrent(c:List<String>,r:Map<String,QueryRecord>)=db.saveCurrent(c,r); fun loadCurrent()=db.loadCurrent()
    fun saveList(n:String,c:List<String>)=db.saveList(n,c); fun updateSavedListMembership(n:String,addCodes:List<String> = emptyList(),removeCodes:List<String> = emptyList())=db.updateSavedListMembership(n,addCodes,removeCodes); fun deleteList(n:String)=db.deleteList(n); fun loadLists()=db.loadLists()
    fun archive(c:String)=db.archive(c); fun loadArchived()=db.loadArchived(); fun restoreArchived(c:String)=db.restoreArchived(c); fun deleteCode(c:String)=db.deleteCode(c)
    fun addHistory(r:Map<String,QueryRecord>)=db.addHistory(r); fun loadHistory(l:Int=100)=db.loadHistory(l); fun clearHistory()=db.clearHistory(); fun clearAllData()=db.clearAllData()
    fun countCodes()=db.countCodes(); fun countArchived()=db.countArchived(); fun countRecords()=db.countRecords(); fun countHistory()=db.countHistory()
    fun addSms(s:String,b:String,t:Long)=db.addSms(s,b,t); fun smsAfter(i:Long)=db.smsAfter(i); fun allSms()=db.allSms(); fun latestSmsId()=db.latestSmsId(); fun clearSms()=db.clearSms()
    fun recordSmsQuery(o:String,c:String,d:String,t:Long,a:Int)=db.recordSmsQuery(o,c,d,t,a); fun smsQueryAttemptsForCodes(c:List<String>,s:Long=0L)=db.smsQueryAttemptsForCodes(c,s); fun pruneSmsQueryAttempts()=db.pruneSmsQueryAttempts(); fun clearSmsRecoveryData()=db.clearSmsRecoveryData(); fun smsCount()=db.smsCount()
    fun databaseCodes(s:String="",a:Boolean=true)=db.databaseCodes(s,a); fun getSetting(k:String)=db.getSetting(k); fun setSetting(k:String,v:String?)=db.setSetting(k,v)
    fun recordObservation(r:SimRegResult,date:String=LocalDate.now().toString())=db.recordObservation(r,date); fun dashboard(date:String=LocalDate.now().toString())=db.dashboard(date); fun observationsForMonth(m:String)=db.observationsForMonth(m); fun observationsBetween(start:LocalDate,end:LocalDate)=db.observationsBetween(start,end); fun observationsForCode(c:String,l:Int=60)=db.observationsForCode(c,l); fun setRetentionMonths(m:Int)=db.setRetentionMonths(m)
}

data class HistoryRecord(val completedAt:Long,val record:QueryRecord)
