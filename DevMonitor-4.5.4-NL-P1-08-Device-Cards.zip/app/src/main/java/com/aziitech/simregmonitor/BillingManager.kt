package com.aziitech.simregmonitor

import android.app.Activity
import android.content.Context
import android.provider.Settings
import android.util.Log
import com.xiaomi.billingclient.api.BillingClient
import com.xiaomi.billingclient.api.BillingClientStateListener
import com.xiaomi.billingclient.api.BillingFlowParams
import com.xiaomi.billingclient.api.BillingResult
import com.xiaomi.billingclient.api.Purchase
import com.xiaomi.billingclient.api.PurchasesUpdatedListener
import com.xiaomi.billingclient.api.SkuDetails
import com.xiaomi.billingclient.api.SkuDetailsParams
import com.xiaomi.billingclient.api.SkuDetailsResponseListener
import com.xiaomi.billingclient.api.PurchasesResponseListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.security.MessageDigest

/**
 * Xiaomi GetApps IAP entitlement manager.
 *
 * This build is intentionally GetApps-first: Google Play Billing is not used here.
 * Both Premium products are recurring Xiaomi GetApps subscriptions.
 *
 * Configure these same product IDs in the Xiaomi GetApps Developer Console:
 *   fieldpulse_remove_ads_monthly
 *   fieldpulse_remove_ads_yearly
 *
 * Recommended Xiaomi server-side purchase verification can be added later using
 * the purchaseToken returned by the SDK. The client still re-queries the store
 * on startup/resume so the entitlement is not permanently based on a local flag.
 */
class DevMonitorBillingManager(context: Context) : PurchasesUpdatedListener {
    companion object {
        const val DEFAULT_MONTHLY_ID = "fieldpulse_remove_ads_monthly"
        const val DEFAULT_YEARLY_ID = "fieldpulse_remove_ads_yearly"
        private const val PREFS = "fieldpulse_billing"
        private const val KEY_ADS_REMOVED = "ads_removed"
        private const val KEY_ACCOUNT_ID = "xiaomi_obfuscated_account_id"
        private const val TAG = "DevMonitorXiaomiIAP"
    }

    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val monthlyId = BuildConfig.BILLING_MONTHLY_PRODUCT_ID
    private val yearlyId = BuildConfig.BILLING_YEARLY_PRODUCT_ID

    private val _adsRemoved = MutableStateFlow(prefs.getBoolean(KEY_ADS_REMOVED, false))
    val adsRemoved: StateFlow<Boolean> = _adsRemoved
    private val _monthly = MutableStateFlow<SkuDetails?>(null)
    val monthly: StateFlow<SkuDetails?> = _monthly
    private val _yearly = MutableStateFlow<SkuDetails?>(null)
    val yearly: StateFlow<SkuDetails?> = _yearly

    private var billingClient: BillingClient? = null
    private var connecting = false

    fun start() {
        if (!BuildConfig.MONETIZED_BUILD || billingClient != null || connecting) return
        connecting = true
        billingClient = BillingClient.newBuilder(appContext)
            .setListener(this)
            .build()
        billingClient?.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(result: BillingResult) {
                connecting = false
                Log.d(TAG, "setup code=${result.responseCode}, msg=${result.debugMessage}")
                if (result.responseCode == 0) {
                    if (billingClient?.supportSubscription() == true) {
                        queryProducts()
                        restorePurchases()
                    } else {
                        Log.w(TAG, "Xiaomi GetApps subscription feature is unavailable")
                    }
                }
            }

            override fun onBillingServiceDisconnected() {
                connecting = false
                Log.w(TAG, "Xiaomi GetApps billing service disconnected")
            }
        })
    }

    private fun ensureConnected() {
        if (billingClient?.isReady == true) return
        if (!connecting) start()
    }

    private fun queryProducts() {
        val client = billingClient ?: return
        val params = SkuDetailsParams.newBuilder()
            .setSkusList(listOf(monthlyId, yearlyId))
            .setType("subs")
            .build()
        client.querySkuDetailsAsync(params, object : SkuDetailsResponseListener {
            override fun onSkuDetailsResponse(
                billingResult: BillingResult,
                list: MutableList<SkuDetails>?
            ) {
                Log.d(TAG, "sku query code=${billingResult.responseCode}, count=${list?.size ?: 0}")
                if (billingResult.responseCode != 0) return
                list.orEmpty().forEach { details ->
                    when (details.sku) {
                        monthlyId -> _monthly.value = details
                        yearlyId -> _yearly.value = details
                    }
                }
            }
        })
    }

    private fun restorePurchases() {
        val client = billingClient ?: return
        _adsRemoved.value = false
        prefs.edit().putBoolean(KEY_ADS_REMOVED, false).apply()
        client.queryPurchasesAsync(
            "subs",
            object : PurchasesResponseListener {
                override fun onQueryPurchasesResponse(
                    billingResult: BillingResult,
                    list: MutableList<Purchase>
                ) {
                    Log.d(TAG, "purchase query code=${billingResult.responseCode}, count=${list?.size ?: 0}")
                    if (billingResult.responseCode == 0) {
                        processPurchases(list.orEmpty())
                    }
                }
            }
        )
    }

    private fun processPurchases(purchases: List<Purchase>) {
        var active = false
        purchases.forEach { purchase ->
            if (purchase.purchaseState == 1 && purchaseProductIds(purchase).any { it == monthlyId || it == yearlyId }) {
                active = true
                if (!purchase.isAcknowledged) acknowledge(purchase)
            }
        }
        setAdsRemoved(active)
    }

    /**
     * Xiaomi has shipped SDK revisions whose acknowledgePurchase signature differs.
     * Use a small compatibility bridge so the app compiles against the published
     * 1.1.9 artifact while still acknowledging subscriptions at runtime.
     */
    private fun acknowledge(purchase: Purchase) {
        val client = billingClient ?: return
        runCatching {
            val methods = client.javaClass.methods.filter { it.name == "acknowledgePurchase" }
            val method = methods.firstOrNull { it.parameterTypes.size == 2 }
                ?: methods.firstOrNull()
                ?: return@runCatching
            val listenerType = method.parameterTypes.lastOrNull()
            if (method.parameterTypes.size == 2 && listenerType != null) {
                val listener = java.lang.reflect.Proxy.newProxyInstance(
                    listenerType.classLoader,
                    arrayOf(listenerType)
                ) { _, name, args ->
                    if (name.name == "onAcknowledgePurchaseResponse") {
                        val result = args?.firstOrNull()
                        Log.d(TAG, "acknowledge response=$result")
                    }
                    null
                }
                val firstType = method.parameterTypes[0]
                val firstArg = if (firstType == String::class.java) {
                    purchase.purchaseToken
                } else {
                    buildAcknowledgeParams(firstType, purchase.purchaseToken)
                }
                if (firstArg != null) method.invoke(client, firstArg, listener)
            }
        }.onFailure {
            Log.e(TAG, "Unable to acknowledge Xiaomi purchase", it)
        }
    }

    private fun buildAcknowledgeParams(type: Class<*>, token: String): Any? {
        return runCatching {
            val builderMethod = type.getMethod("newBuilder")
            val builder = builderMethod.invoke(null)
            builder.javaClass.getMethod("setPurchaseToken", String::class.java).invoke(builder, token)
            builder.javaClass.getMethod("build").invoke(builder)
        }.getOrNull()
    }

    /** Extract product IDs without depending on one particular Xiaomi SDK field name. */
    private fun purchaseProductIds(purchase: Purchase): List<String> {
        val result = mutableListOf<String>()
        runCatching {
            purchase.javaClass.methods
                .filter { it.parameterTypes.isEmpty() && it.name in setOf("getSku", "getProductId") }
                .forEach { it.invoke(purchase)?.toString()?.let(result::add) }
            purchase.javaClass.methods
                .filter { it.parameterTypes.isEmpty() && it.name in setOf("getSkus", "getProducts") }
                .forEach { method ->
                    val value = method.invoke(purchase)
                    when (value) {
                        is Iterable<*> -> value.filterNotNull().forEach { result.add(it.toString()) }
                        is Array<*> -> value.filterNotNull().forEach { result.add(it.toString()) }
                    }
                }
        }
        if (result.isNotEmpty()) return result
        runCatching {
            val json = purchase.javaClass.methods.firstOrNull { it.name == "getOriginalJson" && it.parameterTypes.isEmpty() }
                ?.invoke(purchase)?.toString().orEmpty()
            val regex = Regex("""\"(?:sku|productId)\"\s*:\s*\"([^\"]+)\"""")
            regex.findAll(json).forEach { result.add(it.groupValues[1]) }
        }
        return result.distinct()
    }

    private fun setAdsRemoved(value: Boolean) {
        _adsRemoved.value = value
        prefs.edit().putBoolean(KEY_ADS_REMOVED, value).apply()
    }

    private fun stableObfuscatedAccountId(): String {
        val existing = prefs.getString(KEY_ACCOUNT_ID, null)
        if (!existing.isNullOrBlank()) return existing
        val androidId = Settings.Secure.getString(appContext.contentResolver, Settings.Secure.ANDROID_ID).orEmpty()
        val raw = "${appContext.packageName}:$androidId"
        val digest = MessageDigest.getInstance("SHA-256").digest(raw.toByteArray())
        val value = digest.joinToString("") { "%02x".format(it) }
        prefs.edit().putString(KEY_ACCOUNT_ID, value).apply()
        return value
    }

    fun launchMonthly(activity: Activity): BillingResult? = launch(activity, _monthly.value)

    fun launchYearly(activity: Activity): BillingResult? = launch(activity, _yearly.value)

    private fun launch(activity: Activity, details: SkuDetails?): BillingResult? {
        if (details == null) {
            ensureConnected()
            return null
        }
        val offerToken = details.subscriptionOfferDetails
            ?.firstOrNull()
            ?.offerToken
            ?: return null
        val client = billingClient ?: return null
        val params = BillingFlowParams.newBuilder()
            .setSkuDetails(details)
            .setOfferToken(offerToken)
            .setObfuscatedAccountId(stableObfuscatedAccountId())
            .build()
        return client.launchBillingFlow(activity, params)
    }

    fun restorePremium() {
        ensureConnected()
        if (billingClient?.isReady == true) restorePurchases()
    }

    fun manageSubscriptions(activity: Activity, purchaseToken: String? = null) {
        val client = billingClient ?: return
        runCatching {
            if (!purchaseToken.isNullOrBlank()) {
                client.linkedSubsDetail(activity, 9001, purchaseToken, "")
            } else {
                client.linkedSubsList(activity, 9000, "")
            }
        }.onFailure { Log.e(TAG, "Unable to open Xiaomi subscription management", it) }
    }

    override fun onPurchasesUpdated(result: BillingResult, purchases: MutableList<Purchase>?) {
        Log.d(TAG, "purchase update code=${result.responseCode}, msg=${result.debugMessage}")
        if (result.responseCode == 0) {
            processPurchases(purchases.orEmpty())
        }
    }

    fun close() {
        billingClient?.endConnection()
        billingClient = null
        connecting = false
    }
}
