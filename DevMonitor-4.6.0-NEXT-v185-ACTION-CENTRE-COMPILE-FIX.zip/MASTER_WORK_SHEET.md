
## v185 — GitHub Actions compile correction

- Fixed the `CompanyActivationStore.loadReportForDevice()` daily-map type mismatch reported by GitHub Actions.
- The established `SimRegReportRow.daily` contract remains `Map<Int, Int>` (day-of-month to count).
- Exact-date activation values are additionally retained in `dailyByDate` for the targeted Loaded Report result.
- No business-rule or UI behaviour was changed by this correction.
- v184 Staff Action Centre visibility remains intact: Staff hidden; Agent/Partner visible.


## v183 — Remove automatic post-profile dashboard guided tour

**Status: IMPLEMENTED IN v183 SOURCE PACKAGE**

- Removed the automatic/static main-dashboard orientation that previously launched after a new profile was created.
- Dashboard no longer enters a guided-tour state after profile creation.
- Removed the dashboard-tour target tracking and tour-specific scrolling from the dashboard presentation.
- The normal dashboard cards and navigation remain unchanged.
- The separate BUILD PROFILE first-setup spotlight remains governed by the no-profile condition.
- The SMS CHECKER guided tour remains removed as previously established.
- No payment, HQ report, Device Monitor, SMS operational, Profile Builder, or report-search business logic was changed by this removal.

# DevMonitor — CURRENT ARCHITECTURE OVERRIDE — 4.6.0-NEXT v184

> **Current build identity:** `versionCode = 184` / `4.6.0-NEXT`

> **Current v170 recovery override:** v162.1 is the recovery code base. Approved post-v162.1 UI improvements are selectively retained, especially the single informative floating waiting window. This override supersedes earlier same-coverage rejection wording and any older four-MOM-database wording where they conflict with the current v161/v165 architecture.



## 4.6.0-NEXT v176 — Company Skeleton compile correction
- Corrected two `SimRegReportRow` constructor calls in `CompanyActivationStore.kt`.
- The calls were passing `Map<LocalDate, Int>` into the `division: String` parameter because the optional `division` slot had been omitted.
- The fix explicitly supplies an empty division string and preserves the date-keyed activation map in `dailyByDate`.
- No payment, activation calculation, report import, Company Skeleton, profile hierarchy, or HQ storage logic was changed by this correction.
- This is a compile-only correction to the v176 Company Skeleton / Profile onboarding package.

## 4.6.0-NEXT v173 — Device Monitor compact result cards
- Reduced vertical footprint of My Devices / Device Monitor result cards to improve field scanning and reduce unnecessary scrolling.
- Device code remains the strongest visual identifier; ownership, status, flags, performance metrics, errors and recheck behavior remain visible.
- Performance metrics are presented in one compact row (Today, MTD, B48, B96) when a result exists.
- Successive unflagged cards use subtle Aurora accent variation (blue, emerald, violet); flagged cards retain the error accent.
- Removed the duplicate in-card payment-progression viewer. Each result now has one primary **EARNING PROGRESS** button, alongside **Recheck**.
- This is presentation/navigation-only. PaymentEngine, PaymentRules, PaymentCycleResolver, Device Monitor/SMS logic and payment data pathways were not changed.

## 4.6.0-NEXT v172 — Historical Fixes + Loaded Report Carry-Forward
- v172 carries forward the non-conflicting documented fixes from the historical line rather than treating Loaded Report as the only change.
- Profile Builder scrolling, profile deletion, MOM search/detail, Device Monitor payment freshness protection, targeted payment search, and the unified floating waiting window remain active.
- Dashboard search preserves the selected source when opening a result.
- Payment-page presentation is simplified without changing search or payment logic.
- Loaded Report import remains calculation-isolated but immediately displays the exact validated report; Open Loaded Report directly retrieves the latest stored report.
- PaymentEngine, payment formulas, Device Monitor/SMS rules, and the two-month HQ architecture remain protected.

## 4.6.0-NEXT v162 — Dashboard clarity / role-aware UX
- Dashboard quick actions use plain-language names: **SMS CHECKER**, **MY DEVICES**, **LOAD REPORT**, and **EARNING PROGRESS**.
- The same EARNING PROGRESS terminology is used for the bottom navigation destination.
- The dashboard Action Centre is shown only for **AGENT** and **PARTNER** profiles; it is hidden for **STAFF** profiles.
- Removed the obsolete **Manage authentication & authorization** Settings button completely.
- Removed developer-facing Google OAuth/SHA-1 troubleshooting text from normal Settings UI.
- Replaced technical Google Drive storage explanation with a concise user-facing connection message.
- Google sign-in, backup/restore behavior, payment logic, report logic and underlying authentication implementation are otherwise unchanged.
- Added profile-level saved-device management: individual devices can be removed from My Devices with confirmation; removal changes only the profile working set and does not delete underlying HQ/report history.

## Monthly HQ snapshot storage / import policy
- **Two physical HQ month databases only:** one file for the current calendar month and one file for the immediately previous calendar month, named `fieldpulse_company_YYYY_MM.db`.
- The previous rolling three-calendar-month HQ database is superseded by this architecture. Historical material beyond the two active months is not retained in the HQ activation store.
- HQ activation reports are treated as **authoritative monthly exports**. A report covers exactly one calendar month.
- Import is **Replace All for the report month**: when a newer report for that month is accepted, the existing monthly snapshot is atomically cleared and replaced with the new HQ export. Devices absent from the new export are therefore removed from that month's stored snapshot, correctly reflecting HQ transfers, additions, removals/expunged devices and zero-activity devices.
- **Import ordering:** the current and previous month are independently addressable. A valid August report can be imported after September has already been stored. The existence of newer September data does not block August.
- **Older-report safeguard:** within a month, an incoming report with an older coverage end than the stored snapshot is rejected. A report with the same coverage end is **accepted as a replacement**, not treated as a duplicate. A newer coverage end also replaces the stored snapshot. The accepted report is a complete monthly snapshot.
- Reports outside the current/previous two-month window are rejected.
- Import is **storage-only**. It does not refresh My Devices, Device Monitor, Month-on-Month, payment progression, dashboard intelligence, estimations, or other derived views. Existing Refresh/action buttons remain responsible for those operations.
- Payment calculation, payment-cycle rules, progression thresholds and estimator formulas are protected. They now retrieve their Loaded Report evidence through the month-aware CompanyActivationStore rather than relying on a single continuous three-month database.
- Month-on-Month no longer maintains four duplicate physical SQLite databases. Its calculation/search layer reads the same two authoritative monthly HQ stores and may use Device Monitor only as its established read-only freshness/enrichment source.
- The former `devmonitor_mom_*` derived databases are obsolete caches and are removed on migration.
- Existing users are migrated from `fieldpulse_company_activations.db` into the current/previous month files once; only the final normalized monthly state is carried forward.
- Version/build target: **versionCode 162**, versionName `4.6.0-NEXT`.

---

## 4.6.0-NEXT v170 — Recovery / PC + Cloud Build Alignment
- Recovery source base is **v162.1**. Later Loaded Report workflow/render-selection experiments are not inherited wholesale.
- Retained approved post-v162.1 UI work, especially the **single app-wide floating waiting window** with operation, current major step, projected overall percentage, one progress bar and concise status.
- The waiting-window percentage is a fixed representation of the existing workflow stages; it is not a new row-counting, calculation or performance-monitoring system.
- HQ same-coverage replacement is now authoritative: older coverage is rejected; newer coverage replaces; **same coverage date also replaces** the complete monthly snapshot.
- Current and previous calendar months remain independently addressable and import order does not matter.
- Current month on 1 October 2026 is October 2026; previous month is September 2026. August is outside the active two-month HQ window.
- PaymentEngine/payment formulas, Device Monitor/SMS logic, Profile Builder, and release identity remain protected.
- Added `BUILD_FOR_PC.md` as the explicit desktop/PC compilation guide. The PC path uses the standard desktop Android SDK/AAPT2 toolchain; it must not use the phone-only ARM AAPT2 override.
- `BUILD_CLOUD.md`, `README.md`, `MASTER_WORK_SHEET.md`, and the PC build guidance are kept aligned so the PC-oriented branch can advance without losing the phone/cloud build paths.

---

## 4.5.2.1 — Notification & Inbox compile correction / cloud build preparation
- Fixed the nullable `activeProfileId` arguments introduced by the Notification & Inbox layer. Notification storage now receives a resolved profile ID while preserving profile isolation.
- Fixed the Compose notification-drawer `Text()` call so the `Modifier` is supplied correctly.
- Added a GitHub Actions cloud-build workflow using Java 17, Gradle wrapper 8.7 and `assembleDebug`.
- Added phone-only cloud-build instructions in `CLOUD_BUILD.md`.
- No notification behavior, payment logic, SMS logic, report logic, profile database rules, or performance policy was intentionally changed.

## 4.5.2 — NEXT LEVEL notification/inbox foundation
- Added a lightweight, profile-scoped **Notifications & Inbox** for user-facing operational notices.
- Added unread count badge in the top bar and drawer access.
- Notifications are local and capped; they do not require network access or background processing.
- Added notices for completed monitoring, monitoring failures/timeouts, report imports, exports, and the existing 18th–20th payment-cycle reminder.
- Month-end remains a reminder only: no automatic monitoring, calculation, estimation, synchronization, or heavy work is triggered.
- Opening/switching profiles only loads that profile's cached notification list; it does not perform operational calculations.
- Users can mark individual notifications read or mark all read.
- Performance policy remains: heavy work is user initiated; natural immediate continuation after a foreground action is allowed.

## Next appearance direction
- Appearance/theme evolution is now an approved creative phase, not a blanket theme replacement.
- The overall DevMonitor visual language may be refined freely while green/emerald/mint are introduced as selected variations.
- Aurora remains a foundation but may be substantially evolved where useful.

## 4.5.1 — Appearance / Theme Evolution

- NEXT LEVEL appearance work has begun from the compile-fixed 4.5.0 Sound & Haptics baseline.
- Existing Aurora visual language remains the foundation; this is an evolution, not a forced theme replacement.
- Added a richer green family (emerald, mint, deep green) as selective Aurora variations.
- Added subtle green tinting to shared Aurora backgrounds/cards and introduced green variation into selected dashboard quick actions and metrics.
- Payment-cycle presentation now uses an emerald accent while retaining the existing status semantics.
- Existing blue/cyan/violet accents remain in use so the interface keeps visual variety and hierarchy.
- No business logic, payment rules, profile isolation, SMS behavior, reporting rules, or user-initiated performance policy was changed by the appearance work.
- Phone performance remains a design constraint: visual polish must not introduce heavy background processing.
## NEXT LEVEL — 4.5.0 Phase 1

### Modern productivity-suite foundation
- Added the NEXT LEVEL product roadmap and incremental delivery tracker.
- Dashboard upgraded into a command-centre experience with global active-profile search, quick actions, live payment-cycle progression and an Action Centre.
- Payment-cycle dashboard value is calculated from the existing payment-cycle/company activation pathways; no duplicate payment rules were introduced.
- Search and Action Centre drill-downs reuse existing Device Monitor/payment/flags pathways.
- Profile-scoped operational data architecture remains intact.
- Remaining Phase 1 work is explicitly tracked in `NEXT_LEVEL_TRACKER.md`.

## 0. CURRENT DEVELOPMENT NOTE — 4.4.2

### Dashboard Month-on-Month card + payment wording
- Expanded the dashboard **MONTH-ON-MONTH COMPARISON** section into a full Aurora card rather than a mini header strip.
- The dashboard card displays the currently available Month-on-Month result: current MTD, same-period-last-month total, change/percentage and as-of date.
- Added separate **Refresh** and **Open Full Comparison** actions; the existing Month-on-Month calculation/data architecture is unchanged.
- Payment estimate cards now label the primary progression number **Current Activation Achieved** instead of **Activations used**.
- No payment calculation, progression thresholds, Month-on-Month calculation, report processing, or database logic was changed by this wording/presentation update.

## 0. CURRENT DEVELOPMENT NOTE — 4.4.1

### One-off Device Enquiry
- **My Devices remains the persistent default working group.**
- Device Monitor input now has a separate **Check Now — don't add to My Devices** path for random/new device enquiries.
- Check Now sends the entered code(s) directly instead of appending them to the My Devices queue. This prevents a single new enquiry from waiting behind the entire My Devices batch.
- One-off results are displayed separately from My Devices results.
- One-off checks still record normal Device Monitor observations/history and can open the existing payment estimate/progression card.
- **Add list**, **Replace**, batch Start/Refresh, Continue and Retry retain their existing working-set behavior.
- Payment calculation/resolver/progression, Month-to-Month architecture, report processing, and the My Devices database are protected and unchanged by this feature.

### 4.3.5.58 — Superseded Month-to-Month Search Draft
- 4.3.5.58 temporarily introduced a staff search against the full company device/hierarchy database.
- That search scope was superseded by 4.3.5.59 and must not be treated as the final architecture.
- The final search scope is the four dedicated Month-to-Month databases only, with Device Monitor allowed only as a read-only peek for matching-result enrichment.


### 4.3.5.57 — Isolated Month-to-Month Data Layer
- Month-to-Month is now a self-contained data feature. Its calculator does not query `fieldpulse_company_activations.db` or the existing normalized activation tables.
- Dedicated databases: `devmonitor_mom_previous.db`, `devmonitor_mom_previous_my_devices.db`, `devmonitor_mom_current.db`, `devmonitor_mom_current_my_devices.db`.
- Fifth source is a read-only peek at the existing Device Monitor `daily_observations` database at calculation time.
- Previous month: partial files replace the isolated snapshot until a filename containing `activation` represents a complete first-to-last-day month; that full activation snapshot locks the month.
- Current month: incremental replacement continues as newer same-month reports arrive.
- Filename month controls which Month-to-Month store can be updated.
- My Devices projections are rebuilt when a report is imported or the My Devices profile changes.
- Comparison cutoff is the newest valid current-month date among the isolated loaded-report snapshot and genuinely newer Device Monitor observations. Previous-month side stops at the same day-of-month.
- Payment logic is protected and untouched by this work.


## 4.5.0 — NEXT LEVEL performance-policy correction
### User-initiated operations refinement
- Month-end background monitoring remains disabled; the legacy scheduler/receiver only cancels old alarms and never starts operational work.
- On the 18th–20th, the dashboard may display a lightweight **Month-end review reminder**. It is informational only and asks the user to decide when to refresh/review.
- The reminder does not calculate, estimate, monitor SMS, import reports, sync data or launch heavy work.
- Switching profiles remains a presentation/cache action: the selected profile shows its last-known dashboard values, with explicit Refresh controls available when the user wants fresh calculations.

# DevMonitor — MASTER WORK SHEET

**Project:** DevMonitor / SIMReg Monitor  
**Stable source baseline:** DevMonitor 4.1 Premium / Xiaomi GetApps  
**Current development workstream:** 4.3.5.57 — Isolated Month-to-Month Data Layer  
**Previous milestone:** 4.3.4 — Authentication foundation  
**Status:** Development build; phone build and full device testing still required before calling 4.3.4.1 stable.

---

## 0. CURRENT DEVELOPMENT NOTE — 4.3.5.59

### Final Month-to-Month search/security correction
- The Month-to-Month search is strictly limited to the four dedicated Month-to-Month databases: Previous Month, Previous Month My Devices, This Month, and This Month My Devices.
- The previous 4.3.5.58 implementation that searched the full company database is superseded and must not be revived.
- Device Monitor is only a read-only peek for matching Month-to-Month search results. It may enrich a matching device with a newer observation/Active value, but it never expands the Month-to-Month search population.
- Search remains read-only and cannot change comparison totals, cutoffs, database contents, My Devices, or payment logic.
- Staff search visibility is determined exactly once, on the first Month-to-Month run after installation. The raw profile phone must be exactly 11 digits, all numeric, and start with `0805557`. No formatting normalization is performed.
- A qualifying phone stores `STAFF`; any other value stores `NON_STAFF`. The result is set in stone until a fresh install/app-data reset. Later profile-phone changes do not reclassify the installation.
- Non-staff failure is silent: no alert and no search field. Month-to-Month comparison itself remains available.
- Device Monitor freshness in Month-to-Month comparison continues to use `received_at` versus loaded-report `imported_at`, and when genuinely newer, the Device Monitor **Active** value is used; the Device Monitor MTD field is not used for this comparison.
- Payment calculation, resolver, progression, and payment pathway code remain protected and unchanged by this feature.

## 0. CURRENT DEVELOPMENT NOTE — 4.3.5.57

### Isolated Month-to-Month Data Layer
- Month-to-Month calculator no longer reads the existing normalized company activation database.
- Four dedicated SQLite files hold previous month, previous-month My Devices, current month, and current-month My Devices.
- The live Device Monitor database is only a read-only fifth source at calculation time.
- Filename month controls import routing. Previous month can be replaced by partial reports until a complete filename-containing-`activation` full-month report arrives; that report locks the previous snapshot. Current month remains incremental.
- My Devices projections are rebuilt after report imports and profile changes.
- The current cutoff is the newest valid current-month date from loaded reports or genuinely newer Device Monitor data; the previous side uses the same elapsed day in the previous-month snapshot.
- Payment calculation/pathways remain protected.

### Global Human Date Parser
- All external/report date text should pass through `HumanDateParser`; do not create one-off filename/date regexes for new features.
- Supported families include ISO/YMD, numeric DMY/MDY, compact numeric dates, full/abbreviated month names, ordinals, Roman-numeral months, month/year periods, and mixed-format range endpoints.
- When a numeric date is genuinely ambiguous (for example `03/04/2026`), DevMonitor uses the established day/month convention rather than silently switching interpretation. If one side is greater than 12, the unambiguous interpretation is used.
- External date strings are normalized to canonical ISO `yyyy-MM-dd` before storage/comparison.
- Report filename coverage is now represented as an actual start/end date pair, so a filename such as `SEPT 1-23RD` cannot accidentally become September 30.
- Do not alter payment calculation/pathway code as part of this date-parser work.

## 1. PRODUCT PURPOSE

DevMonitor is a mobile-first operational monitoring and decision-support application for GLO company/partner device codes and partner codes.

It supports:
- SMS-based device/partner monitoring;
- daily and monthly observations;
- SMS recovery and deliberate rechecks;
- Bar 48 / Bar 96 monitoring;
- Active, MTD, Today and flag analytics;
- agents/partners and linked device records;
- payment/incentive monitoring;
- Excel export and file sharing;
- Google Drive private backup/restore;
- guided onboarding;
- Premium/AdMob monetization for the public/GetApps build;
- and, now, intelligent reading of headquarters SIMReg/Activations Excel reports.

**DevMonitor is NOT the company's official accounting, activation-validation, or payment system.**

---

## 2. NON-NEGOTIABLE PAYMENT / AUTHORITY WARNING

Whenever DevMonitor shows payment, incentive, payout, activation-reward, or settlement information, the UI must make this warning prominent:

> **⚠ PAYMENT / INCENTIVE WARNING — MONITORING / ESTIMATION ONLY**  
> DevMonitor cannot validate or certify company payment records. Any payment, activation, incentive, or settlement figure shown by DevMonitor is for monitoring/estimation unless separately confirmed by the company. **The company's official data remains the final authoritative report.**

Purpose: prevent users from treating DevMonitor estimates as a company-certified amount and then creating unnecessary disputes.

This warning belongs around payment information in:
- Device Monitor;
- SIMReg Report;
- Agent/Partner Payment Tracking;
- future payment-cycle screens;
- partner incentive screens;
- exports that contain estimated payout information.

---

## 3. STABLE 4.1 FUNCTIONAL BASELINE — DO NOT REGRESS

### Monitoring
- GLO-GD = company ownership.
- GLO-DD / GLO-FD = partner ownership.
- Standalone non-blank partner codes are supported; partner format is intentionally open.
- User input is case-insensitive and normalized to uppercase for SMS transmission.
- Hyphens are preserved.
- Destination 3030 receives the canonical short GLO device form immediately before transmission.
- Other SMS destinations receive the normalized code as entered.
- No RCS fallback; SMS uses Android `SmsManager`.
- Visible SIM selector supports dual/multi-SIM phones.
- Phone/default active SIM handling is preserved.
- SMS sent/delivery monitoring is preserved; negative delivery can trigger up to two immediate retries before the next query, with visible warning while the batch continues.
- Normal batch queries use the established 2-minute response timeout.
- SMS batch automation supports the established default single send and optional repeat counts.
- SMS permissions are requested in response to the relevant operation and accompanied by disclosure.

### Stable GLO identity
Example:
`GLO-GD-OGN-da3-3GOGN047-666D` → `GLO-GD-666D`

Same canonicalization applies to GLO-DD/GLO-FD. Non-GLO codes remain unchanged.

Canonical identity is used for:
- code entry/import;
- daily observations;
- agent/device links;
- saved-list membership;
- report comparisons;
- Excel export de-duplication.

### Same-day monitoring
- A device may be checked repeatedly on the same calendar day.
- A previous successful result never permanently locks the device.
- Daily key remains `canonical_device_code + calendar_date`.
- Later/cumulative same-day results replace the current daily snapshot while operational history remains traceable.
- This is essential because sales/activity can continue throughout the day.

### SMS recovery/recheck
- Optional READ_SMS recovery reconciles relevant existing SMS after interruption/app closure.
- Recovery is limited to the configured monitoring destination and valid SIMReg responses.
- Direct code matching is preferred.
- Otherwise persisted outbound query attempts are used for timestamp/sequence correlation.
- Ambiguous responses are never silently assigned.
- Query attempts are retained for 14 days and pruned.
- Supported workflows include Recheck this code, Recheck previously checked, Continue unresolved and Recheck all.

### Analytics
Existing observation fields:
- Today
- MTD
- Active
- Bar 48
- Bar 96
- Duplicates
- Monthly Target
- received_at

Existing analytics/flags include:
- company day-1 zero-sales behavior;
- company day-7 zero-sales monitoring rule remains part of the established operational logic;
- company day-15 MTD-below-10 logic;
- consecutive zero-sales-day monitoring;
- Conversion Lost / Bar 48 increases;
- increasing Conversion Lost trend;
- recent-pattern deviation monitoring;
- company/partner summary totals.

The day-15 MTD-below-10 diagnostic flag remains hidden from normal UI by default and can be revealed using the existing diagnostic gesture.

Analytics retention supports up to 60 months through the existing setting.

---

## 4. DEVICE MONITOR PAYMENT / INCENTIVE RULES

**All confirmed payment/incentive rules apply to Device Monitor and the new SIMReg Report workflow through one common rules engine.** There must not be two contradictory calculators.

### Activation vs registration
- A SIM Reg/registration is not automatically an activation.
- The company pays primarily on **activations**, not mere registration.
- Activation qualification involves the company's known rule: at least **₦20 recharge** and the required call/use behavior over the following monitoring period represented operationally by the Bar 48 / Bar 96 process.
- The ₦20 qualification threshold is distinct from the ₦200 minimum used for the separate estimated first-recharge incentive calculation.

### Individual/device reward tiers currently captured
- 30 activations → ₦9,000
- 40 → ₦16,000
- 50 → ₦22,500
- 70 → ₦35,000
- 100 → ₦65,000

### Estimated recharge component
- Minimum recharge basis for the incentive estimate: **₦200**.
- Estimated first-recharge bonus: **₦250 per activation**.
- The report cannot determine the actual recharge class achieved by each activation, so this is an **estimate**, not confirmed payout.

Examples:
- 24 activations → estimated ₦6,000 recharge bonus; no fixed performance tier yet.
- 27 → 3 more to 30 → ₦9,000 fixed tier when reached.
- 38 → 2 more to 40 → ₦16,000 fixed tier when reached.
- 48 → 2 more to 50 → ₦22,500 fixed tier when reached.

Preferred encouragement:
**“Do more. Reach the next level. Earn better.”**

Do not use discouraging wording such as “No performance reward” when someone is below 30; show the attainable next level instead.

### Important implementation boundary
The reward tiers are activation-based. A SIM Reg report alone must not be silently converted into activation counts for payout estimation. When the imported workbook is a SIM Reg report, DevMonitor may show registration performance but must clearly state that payment estimation cannot be certified from registration alone. An Activations report can be used for activation-based monitoring estimates.

### Partner-wide incentive
- Minimum known partner threshold: **500 activations** across the partner portfolio in the applicable payment cycle.
- Some partners use 1,000 or 1,500 thresholds.
- Partner payout amounts/rules vary and are not yet fully specified.
- Partner thresholds and payout rules must therefore be configurable rather than hard-coded as universal facts.
- Partner-wide target and individual device reward position are separate concepts.

---

## 5. PAYMENT CYCLE

Default company/payment cycle:

**21st of previous month → 20th of current month**

Example:
- September payment cycle = August 21 → September 20.

A calendar-month option already exists in the operational payment tracker, but the 21–20 cycle is the default.

Payment-cycle performance is distinct from:
- calendar MTD;
- same-period previous-month comparison;
- Today;
- Bar 48/96.

### Existing payment tracker
The 4.1 baseline already contains:
- Agent database;
- multiple phone numbers;
- linked device/partner codes;
- payment cycles;
- payment records;
- payment-cycle observation records (performance fields only); payment status is not displayed or tracked as a DevMonitor responsibility;
- month-end snapshot scheduling.

### Required future correction/extension
The current payment snapshot stores the latest observation snapshot. A future payment-calculation implementation must calculate **actual activation counts within the 21–20 cycle**, not incorrectly substitute calendar MTD. Preserve the existing tracker while extending it carefully.

---


### 4.2 payment-status boundary
- DevMonitor does not track, display, label, or infer whether a company payment has been made.
- The previous PAID/UNPAID display has been removed from payment-cycle views.
- Payment/incentive figures remain monitoring/estimation only, with the company's official data as the final authority.

### 4.2 HQ report table view
- Imported SIM Reg / Activations search results use an Excel-like horizontal table rather than individual tiles/cards.
- Each device occupies one row so multiple devices can be compared vertically.
- Columns include Device ID, Partner, Trade, Cluster, Region, Territory, Staff, daily columns 01–31, MTD, and GRAND TOTAL.
- The table scrolls horizontally so the full month can be inspected on a phone.
- Search and hierarchy filters continue to reduce the visible rows.

## 6. HEADQUARTERS REPORT INTELLIGENCE

Headquarters currently supplies two report flavors that serve the same monitoring purpose:

### A. SIM Reg as at [date]
Represents registrations/sales recorded at that point in time.

A line can appear here even though it has not yet qualified as an activation.

### B. Activations as at [date]
Represents activation-qualified results.

DevMonitor must accept **either** report flavor.

### Authority rule
Headquarters has the final authoritative data. DevMonitor is a monitoring/operational tool and cannot validate the company's final report.

---

## 7. HEADQUARTERS XLSX STRUCTURE DETECTION

Do NOT assume:
- a fixed filename;
- a fixed sheet name;
- the first sheet;
- the second sheet;
- a fixed column letter.

A workbook may have one sheet or multiple sheets.

The importer should identify the detailed working sheet by structure/content. Strong indicators include:
- Device ID;
- Channel Partner Name;
- Trade Code;
- Cluster;
- Region;
- Territory;
- Staff Name;
- daily date/day columns;
- GRAND TOTAL/Total;
- many individual device records.

The current real headquarters workbook demonstrated this structure with a summary sheet and a detailed GLOZONE device-level sheet. The implementation must generalize beyond those exact names.

---

## 8. HQ REPORT DATA MODEL

Detailed rows may contain:
- Trade Code
- Channel Partner Name
- Device ID
- Cluster
- Region
- Territory
- Staff Name
- daily values (`-01`, `-02`, … or equivalent date/day columns)
- GRAND TOTAL
- additional report-specific columns

Headers must be normalized and found by name.

Preserve the original displayed capitalization and values from the report.

---

## 9. ORGANIZATIONAL HIERARCHY

Current operational hierarchy:

**Cluster → Region → Staff Name → Territory → Device ID**

Partner relationship fields sit alongside the hierarchy:

**Channel Partner Name + Trade Code**

Do not invent a Division level. Do not hard-code current column letters.

---

## 10. REPORT ENTRY / FILTER PATTERNS

One underlying HQ dataset supports different user entry patterns.

### GLO staff
Search by Staff Name and show:
- all devices;
- Device ID;
- Channel Partner Name;
- Trade Code;
- Territory;
- Region;
- Cluster;
- daily values;
- totals;
- relevant additional fields.

### Regional management
Search by Region and reveal subordinate:
- Staff Names;
- Territories;
- Devices;
- partner/trade information;
- daily values/totals.

### Cluster management
Search by Cluster and reveal:
- Regions;
- Staff Names;
- Territories;
- Devices;
- partner/trade information;
- activation/registration information.

### Channel partner
Search by Channel Partner Name or Trade Code and show:
- all associated devices;
- Cluster;
- Region;
- Territory;
- responsible Staff Name;
- device performance;
- partner portfolio total;
- configurable partner target/progress;
- devices approaching individual reward thresholds.

### General device investigation
Search by:
- full Device ID; or
- partial Device ID, including remembered last four characters.

Partial search can return multiple devices. Always display the full Device ID for each match.

Once a device is selected, show its complete associated record.

### Matching rule
All searches are case-insensitive. Examples:
- AYETORO = Ayetoro = ayetoro.
- Device ID case variants match.
- Partner/trade/staff/region/cluster searches are case-insensitive.

---

## 11. REPORT CUTOFF AND MTD

The first practical question after finding a device is:

**“How much has it done up to this point in the month?”**

Rules:
- MTD uses the effective report cutoff.
- Do not blindly use the phone's current date.
- Do not rely on the filename alone.
- Inspect workbook content/metadata/date columns where available.
- HQ reports may lag the phone date by 1–2 days.
- A report cannot legitimately contain future sales beyond the effective reporting date.
- Sum daily values through the effective cutoff.

For a SIM Reg report, call the measure **registration MTD** unless the report explicitly represents activations.

For an Activations report, call the measure **activation MTD**.

---

## 12. MONTH-OVER-MONTH COMPARISON

When comparing current and previous month:
- compare equal elapsed periods;
- current Sep 1–cutoff compares with Aug 1–same day;
- do not compare partial current month against the full previous month;
- use effective report cutoff, not phone date.

Show both:
1. sales/activation pattern;
2. absolute number of sales/activations.

The same comparison engine can later operate at:
- device;
- staff;
- territory;
- region;
- cluster;
- partner.

---

## 13. DEVICE MONITOR ↔ HQ REPORT BRIDGE

Keep the datasets distinct:

**HQ SIMReg:** what headquarters reported.  
**DevMonitor Device Monitor:** what DevMonitor monitored locally.

An optional combined working view compares:
A. devices in the current HQ report;
B. devices saved/monitored locally.

A local device absent from HQ must remain visible in the user's working view because it may still be operationally important, especially when locally monitored activity is zero.

Example combined status:
- HQ SIMReg: Not present
- DevMonitor Monitor: Present
- Latest local result: 0
- Monitoring status: Active

Never destructively merge or overwrite one source with the other.

---

## 14. PRIVATE CROSS-MONTH MISSING-DEVICE ANALYSIS

This is **private/user-only functionality**, not a normal manager alert.

Compare previous completed-month HQ report against current HQ report.

Definitions:
- Listed in current report with MTD 0 → **confirmed zero** (because the device is actually listed).
- Listed previously but absent from current report → **missing/inferred**, NOT proof of zero.

Reason for privacy:
- Devices can be legitimately removed from a user's local database.
- Historical disappearance must not automatically expose deletion history or create routine management questions.

### Private Find Device
For each private missing device:
- use the full canonical Device ID;
- search the entire current HQ workbook, not just the user's current scope;
- determine whether it moved to another Staff, Territory, Region, Cluster, Channel Partner or Trade Code;
- show the current location/ownership context if found;
- leave it unresolved if not found.

Unlock mechanism is intentionally not finalized yet.

---

## 15. HQ REPORT RETENTION

### Current period
Keep a rolling window of the **three most recently uploaded/current-period reports**.

Example:
- Sep 2 → Sep 2
- Sep 4 → Sep 2, Sep 4
- Sep 6 → Sep 2, Sep 4, Sep 6
- Sep 8 → Sep 4, Sep 6, Sep 8; remove Sep 2
- Sep 10 → Sep 6, Sep 8, Sep 10; remove Sep 4

### Full-month historical archives
A completed full-month report is historical reference data and is NOT part of the rolling three-report deletion rule.

Keep three months of completed monthly reports. Once older than the retained three-month archive window, the oldest eligible historical report can be removed.

Retention decisions must use:
- coverage period;
- report period;
- upload/received metadata;
- report type;
not filename alone.

---

## 16. FILES, CLOUD AND SHARING — 4.0 BASELINE

### Google account / Drive
- Optional Google Sign-In.
- Private Google Drive app-data backup/restore.
- Local SQLite remains primary operational storage.
- Nothing is uploaded until the user explicitly chooses Backup.
- Restore replaces the local database only after explicit user choice and reload.
- Uses private `drive.appdata` scope.
- No client secret/service-account credential embedded in APK.

### Files & Analysis
- Attach spreadsheets/reports/reference files.
- Keep associated file names.
- Share last attached file.
- Share last Excel report.
- Android Share sheet can send to WPS Office, email, cloud storage or an available analysis service.

---

## 17. SAVED LISTS

- Saved Lists support Manage.
- Add one or multiple normalized codes.
- Remove selected codes.
- Duplicate additions are ignored.
- GLO canonicalization is preserved.
- Removing a code from a saved list does not delete main device/history data.
- Existing Load/Delete behavior remains.

---

## 18. GUIDED TOUR / ONBOARDING
## 18.1 CURRENT ONBOARDING TOUR REQUIREMENT — IMPLEMENTED

**Status: IMPLEMENTED in the current development package; build verification is pending because the local environment cannot download Gradle 8.7 while offline.**

### A. SMS CHECKER operational guided tour

- Restore the **old Device Monitor guided tour** and attach it to the renamed dashboard action **SMS CHECKER**.
- This is the operational tour for the SMS Checker itself. It is the same established guided-tour flow that previously belonged to Device Monitor/SMS checking, rather than a new generic app tour.
- The same operational tour must remain available from the application menu.
- The tour should explain the SMS Checker controls and workflow, but it does **not** need to force the user through steps that are already established by the way they entered the screen. For example, if SIM selection has already been completed by the entry flow, the tour may skip that part.
- The tour must use the real SMS Checker controls/workflow; it must not simulate SMS sending, results, exports, or other operational actions merely for the tour.
- A first-time visit to SMS CHECKER from either of these routes must be able to start the guided tour:
  1. Dashboard → **SMS CHECKER**.
  2. Dashboard → **CHECK MY DEVICES** when that flow takes the user into SMS Checker.
- The first-time trigger should be based on the user reaching SMS Checker for the first time, not solely on which dashboard button was pressed.
- After the tour has been completed or deliberately skipped, it should not repeatedly auto-launch. The existing manual/restart route from the menu remains available.

### B. New-user dashboard orientation after profile creation

- After a new user successfully creates/saves their profile, the first return to the main dashboard should start a **brief dashboard orientation tour**.
- This dashboard orientation is separate from the SMS CHECKER operational tour and separate from the first-run introduction/profile-building spotlight.
- The dashboard tour should require **no button press to advance**. It automatically moves from one major dashboard section/card to the next.
- Each major dashboard card/section is highlighted in turn with a short plain-language explanation of what that section does and why the user would use it.
- The description should remain visible long enough for a normal person to read and comprehend without feeling rushed. **Approximately 5 seconds per highlighted section** is the initial documented target; this is a UX timing target, not a new background-processing operation.
- The tour should progress through the major dashboard actions, including the current primary areas such as:
  - **BUILD PROFILE** / profile management when applicable;
  - **SMS CHECKER**;
  - **MY DEVICES**;
  - **LOAD REPORT**;
  - **EARNING PROGRESS**;
  - other major dashboard cards that are actually present for the user's role/profile.
- The tour must be role-aware: it should only explain dashboard sections that the user can actually see/use.
- The user should have a clear way to dismiss/skip the orientation rather than being trapped in it.
- This automatic dashboard orientation is a **one-time first-run experience after profile creation**. It must not replay on every dashboard visit.
- Re-editing or rebuilding an existing profile must not restart the dashboard orientation as though the user were a new user.

### C. Relationship to the BUILD PROFILE card

- The prominent **BUILD PROFILE** card remains a first-setup aid while no profile has been successfully built/saved.
- Once a profile is successfully built/saved, that prominent first-setup card disappears from the dashboard.
- The normal profile-management capability remains available through the established profile/settings paths.
- The post-profile dashboard orientation must therefore explain the dashboard in its new post-setup state rather than treating BUILD PROFILE as an outstanding action.

### Implementation notes

- The restored SMS CHECKER tour starts when the user first reaches SMS Checker from the dashboard or from the Check My Devices route, and it can begin at the first relevant operational step instead of forcing an already-completed entry step.
- The existing manual Guided Tour entry remains available from the menu.
- The post-profile dashboard orientation is a separate automatic overlay with approximately 5-second reading intervals and no Next button.
- The dashboard orientation is recorded as completed so it does not replay on subsequent dashboard visits.
- The BUILD PROFILE first-setup card continues to disappear naturally once a profile exists.
- No payment, report, Device Monitor data, Company Skeleton, hierarchy, MOM, or calculation logic was intentionally changed by this onboarding implementation.

### D. Protected boundaries

These onboarding changes are UI/onboarding changes only. They must not modify:

- established payment formulas or progression rules;
- the 21st-to-20th payment cycle;
- Device Monitor/SMS business rules;
- Company Skeleton data model;
- Cluster (Division) → Region → Territory → Staff → Devices / Trade Codes hierarchy;
- two-month authoritative HQ storage;
- atomic Replace-All report import;
- Loaded Report calculation/display rules;
- Month-on-Month architecture;
- explicit-refresh/performance rules.

**Implementation status remains: DOCUMENTED ONLY.**

## 19. SETTINGS / APP EXPERIENCE

Existing Settings includes:
- System default / Light / Dark theme;
- Monitor settings;
- SMS destinations;
- analytics retention;
- Guided Tour Again;
- local data summary;
- Google account/cloud backup/restore;
- Premium controls;
- Files & Analysis;
- About;
- Feedback.

Full left navigation drawer contains:
- Guided Tour;
- About the App;
- Feedback & Suggestions;
- Files & Analysis;
- Settings;
- Open Device Monitor quick access.

Dashboard bottom navigation includes:
- Devices;
- Agents;
- Payments;
- Settings.

---

## 20. AGENT / PARTNER DATABASE

Stores:
- Agent/partner name;
- address;
- multiple phone numbers;
- latitude/longitude;
- linked device/partner codes.

Phone numbers can be selected from Android Contacts.

Location can use present/last-known device location or manually entered coordinates.

Google Maps can be opened for coordinate verification.

---

## 21. MONTH-END AUTOMATION

Existing month-end scheduler:
- checks the last calendar day at approximately 20:30 local time;
- captures the current payment snapshot;
- attempts to reopen/run the normal monitoring workflow;
- preserves the saved snapshot even if Android defers background activity launch.

Do not remove this behavior when extending payment-cycle calculations.

---

## 22. MONETIZATION — 4.1 GETAPPS PREMIUM BASELINE

Xiaomi GetApps Premium build:
- Monthly target: ₦2,000/month.
- Yearly target: ₦20,000/year; store-configured price is authoritative.
- Premium removes banner, interstitial and rewarded ads.
- Premium bypasses rewarded-export restriction.
- Restore Premium and Manage Subscription are available.
- Xiaomi GetApps IAP SDK 1.1.9.
- SKUs:
  - `fieldpulse_remove_ads_monthly`
  - `fieldpulse_remove_ads_yearly`
- Stable obfuscated account ID used for purchase flow.
- Subscription entitlement is rechecked on startup/restore.

Production AdMob IDs are preserved from the established production configuration.

Do not change monetization/toolchain configuration while implementing HQ report intelligence unless necessary.

---

## 23. EXCEL EXPORT BASELINE

Existing export:
- one row per canonical device identity;
- GLO device rows use short form;
- legacy long/short duplicates collapse to one row;
- latest completed result wins;
- report includes Sales Report, Flags and Summary;
- Excel can be opened/shared through Android flows.

Existing rewarded export policy for free/public users remains:
- first 10 successful exports are free;
- after that, completed rewarded ads grant export credits;
- credit is consumed only after successful export;
- Premium bypasses the restriction.

The HQ report importer must remain dependency-light and must not introduce Apache POI.

---

## 24. HQ FOUNDATION PRESENT IN THIS DEVELOPMENT ZIP

Current foundation files include:
- `SimRegReport.kt` — structure-aware HQ XLSX parsing and report UI foundation.
- `PaymentRules.kt` — shared incentive rule definitions.

Foundation behavior:
- identifies detailed sheet by content/structure;
- supports one or multiple sheets;
- reads shared strings and inline values;
- detects SIM Reg vs Activations report text where available;
- extracts report coverage dates from workbook text where available;
- extracts hierarchy/partner/device fields;
- extracts daily columns and totals;
- supports case-insensitive searching;
- calculates report-period MTD through effective cutoff;
- displays prominent payment authority warning.

### Not yet complete
- rolling three-current-report automatic retention;
- three-month full-month archive cleanup;
- private previous/current report comparison;
- private Find Device across the full current workbook;
- complete HQ↔Device Monitor reconciliation screen;
- complete staff/region/cluster/partner scope dashboards;
- configurable partner payout structures;
- exact payment-cycle activation aggregation;
- complete integration of the shared incentive engine into every Device Monitor payment presentation.

These must not be described as finished until implemented and tested.

---

## 25. BUILD ENVIRONMENT — PRESERVE EXACTLY

Established successful phone-build environment:
- Android Code Studio / ARM64 Android phone;
- AGP 8.6.1;
- Gradle 8.7;
- Kotlin 2.0.21;
- Kotlin Compose plugin 2.0.21;
- Java/JDK/JVM target 17;
- compileSdk 36;
- targetSdk 36;
- minSdk 26;
- Gradle workers = 1;
- parallel Gradle execution disabled;
- no Apache POI;
- XLSX handling through internal ZIP/XML APIs.

### ARM64 AAPT2 — critical
The successful phone build does NOT depend on the normal desktop Linux AAPT2 binary.

`build-phone.sh` automatically searches these Android Code Studio/phone locations:
- `$HOME/.androidide/aapt2`
- `$PREFIX/bin/aapt2`
- `/data/data/com.tom.rv2ide/files/usr/bin/aapt2`
- `/data/data/com.tom.rv2ide/files/home/.androidide/aapt2`
- `/data/user/0/com.tom.rv2ide/files/usr/bin/aapt2`
- `/data/user/0/com.tom.rv2ide/files/home/.androidide/aapt2`

It then passes the discovered binary using:
`-Pandroid.aapt2FromMavenOverride="$AAPT2"`

If no ARM-compatible AAPT2 is found, the script stops instead of silently falling back to an incompatible desktop binary.

### Build commands
Debug/release APK:
`sh build-phone.sh assembleRelease`

AAB:
`sh build-phone.sh bundleRelease`

For first validation of a new development build, use:
`sh build-phone.sh assembleDebug --console=plain`

### Gradle properties
- `org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8`
- AndroidX enabled;
- one Gradle worker;
- parallel disabled;
- compileSdk 36 compatibility warning suppressed.

Do not change AGP/Gradle/Kotlin versions simply to add the HQ report feature.

---

## 26. DATABASE BASELINE

SQLite database:
`simreg_monitor.db`

Current database version: **9**.

Existing tables/areas include:
- codes;
- records;
- history;
- daily observations;
- saved lists;
- SMS inbox/recovery;
- persisted SMS query attempts;
- agents;
- agent phones;
- agent-device links;
- payment cycles;
- payment records;
- settings.

Migration history includes canonicalization of GLO device identities and SMS recovery tables.

Do not reset or destructively replace existing user data when adding HQ reports.

---

## 27. PRIVACY BOUNDARIES

Normal manager/colleague views must not expose the private missing-device comparison.

Normal report views may show current HQ report additions and operational information needed for the selected scope.

Private missing/disappeared historical-device analysis is deliberately separate.

Do not expose local deletion history as a proxy for HQ disappearance.

Payment estimates must never be presented as company-authoritative.

---

## 28. DEVELOPMENT RULES

1. Preserve all working 4.1 behavior unless a change is intentional.
2. Preserve SMS transmission and recovery behavior.
3. Preserve Saved Lists and membership management.
4. Preserve Google Drive backup/restore.
5. Preserve AdMob and GetApps Premium behavior.
6. Preserve guided tour and onboarding behavior.
7. Avoid dependency/toolchain churn.
8. Do not add Apache POI.
9. Use internal ZIP/XML XLSX processing compatible with the phone build.
10. Test on actual Android Code Studio/ARM64 hardware.
11. Never claim a build is verified unless it actually compiled/tested.
12. Do not treat registration as activation for payment calculations.
13. Keep HQ and Device Monitor datasets distinguishable.
14. Keep private missing-device analysis out of normal manager views.
15. Make payment warnings prominent wherever estimates are displayed.
16. Do not invent partner payout rules.
17. Do not assume report filename/sheet order/column letter.
18. Preserve original report display values while matching case-insensitively.
19. Use full canonical Device ID for private Find Device.
20. Retain enough HQ reports for the defined rolling/current and historical windows.

---

## 29. ACCEPTANCE TESTS — EXISTING 4.1 REGRESSION

- App launches and initial introduction remains separate from guided tour.
- Drawer opens and all established entries work.
- Theme changes persist.
- SIM selection works on multi-SIM phone.
- SMS permissions/disclosure work.
- Normal SMS batch works.
- Delivery monitoring/retry works where supported.
- App-killed SMS recovery works.
- Ambiguous SMS is not guessed.
- Same-day recheck updates the daily snapshot.
- Long/short GLO forms remain one device.
- Non-GLO partner codes remain unchanged.
- Saved List Manage works.
- Excel export works.
- Rewarded export limits work for free users.
- Premium removes ads/export restriction.
- Google backup/restore works when configured.
- Share last report/file works.
- Payment tracker opens and cycle snapshots are preserved.
- Month-end scheduler remains intact.

---

## 30. ACCEPTANCE TESTS — HQ REPORT FOUNDATION

1. Import a multi-sheet workbook with the detailed sheet not first.
2. Import a one-sheet detailed workbook.
3. Import SIM Reg as-at report.
4. Import Activations as-at report.
5. Detect report type from content when available.
6. Detect effective coverage dates from workbook content when available.
7. Find the detailed table structurally rather than by fixed sheet name.
8. Read Device ID, Staff, Territory, Region, Cluster, Partner and Trade Code.
9. Search every supported field case-insensitively.
10. Search partial Device ID and display full matches.
11. Calculate registration MTD for SIM Reg reports.
12. Calculate activation MTD for Activations reports.
13. Do not calculate activation payout from SIM Reg merely because a row has a daily value.
14. Show the prominent payment/authority warning.
15. Verify the same incentive rules are used by the eventual Device Monitor and report payment views.
16. Preserve the current Device Monitor dataset independently from HQ data.
17. Verify local-only devices remain visible in the bridge view.
18. Verify private missing-device analysis is not exposed to ordinary manager views.
19. Verify current-report rolling retention.
20. Verify full-month historical retention.

---

## 31. CONTINUITY NOTE

When continuing this project in a future chat, treat this worksheet and the latest source ZIP as the authoritative development context.

**Do not replace the 4.1 phone-build environment. Do not assume the HQ report is always named or structured the same way. Do not treat DevMonitor payment estimates as company-authoritative.**

## Android Excel “Open With DevMonitor” Integration — 4.2
### Purpose
DevMonitor can now be selected by Android as an application for opening supported Excel workbooks. This provides a natural workflow when HQ sends a report through Downloads, a file manager, Google Drive, WhatsApp/document sharing, or another Android app that exposes the workbook with a compatible MIME type.

### External open flow
1. User taps an `.xlsx` workbook in another Android app.
2. Android may show DevMonitor among the available apps for opening the workbook.
3. DevMonitor receives the workbook URI through `ACTION_VIEW`.
4. DevMonitor shows an explicit **Import Excel sheet?** dialog with the workbook filename.
5. User chooses **Import** or **Cancel**.
6. Import uses the existing `SimRegReportParser`, so the same structure-aware sheet detection, SIM Reg vs Activations detection, coverage-date logic, hierarchy extraction, daily values, and MTD behavior are retained.
7. A successful import opens the SIMReg Report analyzer.

### Safety / behavior
- No external workbook is imported silently.
- Cancel does not modify the workbook or DevMonitor data.
- Filename is display-only; the parser continues to inspect workbook contents rather than trusting the filename.
- Supported external format in 4.2: `.xlsx` (Office Open XML). Legacy binary `.xls` is not claimed as supported.
- Existing in-app **Import SIMReg Report** remains available.
- This is an import/analyze flow, not an editor for modifying the HQ workbook.

### 4.2 Excel Open/Import build correction
The first Excel Open/Import package contained two Kotlin compile-time mistakes that have now been corrected: the parser explicitly returns its `SimRegReport`, and the report screen reads `report.reportType` rather than expecting a `reportType` property on `SimRegReportRow`. No business-rule behavior was changed by this correction.

## 4.2 — Excel report row/column focus refinement
- Device rows are selectable by normal tap.
- The selected device row remains visibly highlighted while horizontally scrolling through daily values, MTD, and TOTAL.
- Daily, MTD, and TOTAL columns can also be selected; the selected column is highlighted across rows for easier vertical comparison.
- A small focus indicator identifies the selected device and selected column.
- Row/column focus is presentation-only and never changes imported HQ data.

## CURRENT DEVELOPMENT PATCH — Excel table interaction repair

### Problem found in 4.2.x
The Excel-style SIMReg table became difficult/unresponsive to scroll after entering the table. The implementation placed `horizontalScroll(tableScroll)` on every device row and also placed transform-gesture detectors on the header and every row. Those nested gesture handlers competed with the outer vertical `LazyColumn`.

### Corrected design
- Device rows are rendered as items in the report screen's main `LazyColumn`, so off-screen rows are not all composed at once.
- Stable `Device ID` keys are supplied to the row items for better Compose reuse/recycling.
- The header and every virtualized device row share the same horizontal `ScrollState`, keeping columns aligned.
- Vertical scrolling remains controlled by the report screen's main `LazyColumn`.
- Pinch zoom is handled only when at least two fingers are down.
- Zoom remains 60%–200%; visible +/- controls and zoom percentage are removed. Pinch is the only zoom control.
- The original workbook data, parsing, filtering, Customize View, focus behavior, and business rules remain unchanged.

### Acceptance test for this patch
1. Open an imported SIMReg/Activations report.
2. Drag vertically through the report and continue smoothly through the table area.
3. Drag horizontally on any table cell/header and verify the entire table follows the same horizontal position.
4. Scroll vertically again without the table becoming stuck.
5. Pinch with two fingers and verify the table zooms smoothly.
6. Confirm there is no visible +/- zoom control or zoom percentage.
7. Confirm one-finger scrolling does not accidentally zoom or freeze.
8. Verify row/column focus still works.
9. Verify Customize View still works.
10. Verify no report values or parsing behavior changed.

### Build status
Source patch prepared in the current development ZIP. The cloud/container environment cannot download the project's Gradle 8.7 distribution, so compilation must be performed in the established Android Code Studio phone environment before release.

## CURRENT DEVELOPMENT PATCH — Pinch zoom compile correction
The first table interaction repair did not compile because the project's Compose version does not expose the imported `calculateZoom()` extension, and the gesture block used an invalid nested restricted coroutine scope.

### Correction
- Pinch zoom now calculates the distance between the first two active pointers directly.
- The gesture handler uses `awaitEachGesture` directly without nesting another `awaitPointerEventScope`.
- Only two-finger events are consumed.
- One-finger horizontal and vertical scrolling remains available to the normal scroll containers.
- Zoom remains 60%–200% with the existing +/- controls.

### Required phone acceptance test
1. Build successfully with Android Code Studio.
2. Open a SIMReg/Activations report.
3. Scroll vertically through the table continuously.
4. Scroll horizontally and verify the whole table moves together.
5. Pinch with two fingers and verify the table zooms smoothly.
6. Confirm there is no visible +/- zoom control or zoom percentage.
7. Release one finger and confirm ordinary scrolling remains responsive.


## CURRENT DEVELOPMENT PATCH — SIMReg table virtualization / crash prevention
The table rendering was changed after reports of freezing/crashing while scrolling an imported Excel workbook. The previous implementation composed up to 300 wide spreadsheet rows inside one regular `Column`, which could create a very large Compose layout/draw workload.

### Performance correction
- The outer report `LazyColumn` now owns the table rows directly through keyed `items(...)`.
- Only rows near the viewport are composed by Compose's lazy list mechanism.
- Header and rows retain a shared horizontal scroll state so horizontal movement remains synchronized.
- Two-finger pinch remains the only zoom mechanism, with the internal 60%–200% limit.
- No parser, workbook persistence, report calculations, or business-rule changes are included.

### Required phone acceptance test
1. Build successfully with Android Code Studio.
2. Import/open a real SIMReg/Activations workbook.
3. Scroll vertically from the top through many rows continuously.
4. Continue scrolling through the table and confirm the UI remains responsive without freezing/crashing.
5. Scroll horizontally on a row/header and confirm the same horizontal position is reflected by the other table rows.
6. Pinch with two fingers and verify the table scales smoothly.
7. Confirm there are no visible zoom buttons or percentage.
8. Confirm row/column focus and Customize View still work.

## 4.2.x — Company SIMReg intelligence consolidation status
The practical HQ-report features discussed for the company SIMReg import are now implemented in the development source:
- report-type-aware SIM REG vs ACTIVATIONS treatment;
- report-cutoff MTD and equal-elapsed previous-report comparison;
- Cluster / Region / Staff / Territory / Partner hierarchy dashboard;
- private full/partial Device ID search and missing/inferred analysis;
- HQ ↔ Device Monitor non-destructive reconciliation summary;
- retained-report-based 21→20 activation-cycle aggregation when source coverage is sufficient;
- shared activation incentive estimation with next-level messaging;
- persisted configurable partner activation target (default 500);
- virtualized Excel-style table with shared horizontal scroll and pinch-only zoom;
- internal workbook persistence and existing retention policy.

Still deliberately not invented because company rules are not fully specified:
- partner payout amounts beyond the configurable activation threshold;
- any claim that DevMonitor can certify company payment status or activation qualification from registration alone.

Phone build and device testing remain mandatory before calling this stable.


---

## 29. 4.3.4 — AUTHENTICATION FOUNDATION

4.3.4 introduced the DevMonitor staff-account authentication model without changing the established monitoring, parser, payment-estimation, SMS, or local SQLite business logic.

### Account identity
- DevMonitor Account ID is separate from the Google email address.
- Google is the identity anchor.
- Firebase Authentication is now the authentication authority for the 4.3.4.1 build.
- The account is intended to be shared conceptually across future Android/Web/PC clients.
- Android installation state must not be treated as the authoritative authorization state.

### Staff-line classification
The known staff-line format is used only as an eligibility/classification signal:
- configured candidate prefix: `0805557`;
- total Nigerian number length: 11 digits;
- final four digits identify the individual line within that known pattern.

A matching pattern is **not** treated as proof that the person is staff. DevMonitor has no authoritative staff registry in the current implementation.

### Staff access and Payment Intelligence
- A successful Google/Firebase authentication followed by successful OTP verification of the configured staff line establishes the user as a DevMonitor staff account.
- A verified staff account is placed in `AUTHORIZED` state and has full access to **all DevMonitor functionality**, including Payment Intelligence and the raw HQ/SIMReg data processed by the app.
- There is no second Payment Intelligence authorization gate for a verified staff account.
- Agent/partner numbers use the separate Device Manager authorization-request path when that path is retained.
- The staff-line pattern is an eligibility filter because DevMonitor does not have access to the authoritative staff registry.

---

## 30. 4.3.4.1 — AUTHENTICATION HARDENING

### Firebase integration
- Added the supplied `google-services.json` for Firebase project `fieldpulse-b3eb3`.
- Android package remains `com.aziitech.simregmonitor`.
- Existing Google Sign-In now exchanges the Google ID token for a Firebase Authentication credential.
- The Firebase UID is associated with the local DevMonitor account.
- Signing out clears both Google Sign-In and Firebase Authentication state.

### Staff-line OTP gate
The paid SMS verification path is deliberately restricted before Firebase is asked to send an OTP:
1. User must first authenticate with Google/Firebase.
2. Main phone must be a valid Nigerian 11-digit number.
3. Main phone must match the configured `0805557xxxx` staff-candidate pattern.
4. Only then may Firebase Phone Authentication request an SMS OTP.
5. The OTP credential is linked to the already authenticated Firebase/Google account.
6. Successful verification records the Firebase UID and phone-verification timestamp locally.
7. Successful staff-line verification sets the account to `AUTHORIZED` and enables full DevMonitor staff access.

Therefore an arbitrary Nigerian number cannot simply be entered and trigger a DevMonitor staff-verification SMS.

### OTP abuse controls
- A 10-minute resend cooldown is enforced in the authentication UI.
- The cooldown applies before a resend request is issued.
- Firebase's own verification throttling and SMS limits remain the final server-side protection.
- Firebase Authentication documentation supports SMS-region policy controls and imposes verification-request/SMS limits; Nigeria should be the only enabled SMS region for this project unless deployment requirements change.
- Do not attempt to defeat Firebase throttling by repeatedly retrying failed requests.

### Important limitation
The `0805557xxxx` rule is not an authoritative staff registry. Without a central staff-line registry, the app cannot independently prove that every number matching the pattern is a current employee. The OTP proves possession of the qualifying line; under the DevMonitor operating model, successful OTP verification is nevertheless the staff-account verification event that grants full app access.

### Database
Authentication schema advanced from version 8 to version 9:
- `firebase_uid`
- `phone_verified_at`

Existing authentication records are migrated in place; the existing database is not reset.

---

## 31. APP NAME / STORE IDENTITY

A current Google Play search shows an unrelated app already published as **DevMonitor** by Flicent Inc., so the Android display name should not remain exactly `DevMonitor` for public store deployment.

For the current build:
- internal project/product name remains **DevMonitor**;
- Android display/store-facing working name is **DevMonitor Monitor**;
- application ID remains `com.aziitech.simregmonitor`;
- Firebase registration remains tied to the existing application ID.

The display-name change does not change the package/application identity or existing local database.

---

## 32. FIREBASE CONSOLE CHECKLIST BEFORE PHONE TEST

The source code alone cannot enable the Firebase-side providers/policies. Before the first real OTP test:

1. Open Firebase project `fieldpulse-b3eb3`.
2. Enable **Google** under Firebase Authentication sign-in providers.
3. Enable **Phone** under Firebase Authentication sign-in providers.
4. Set the Firebase Authentication SMS region policy to **Nigeria only** for this deployment.
5. Confirm the Android app registered in Firebase uses `com.aziitech.simregmonitor`.
6. Add the SHA-1/SHA-256 fingerprints required by the Firebase/Google configuration for the actual signing key(s) used for testing and production.
7. Confirm the web OAuth client used for the Google ID token is present in the Firebase-generated `google-services.json`.
8. Test Google sign-in before testing phone verification.
9. Test one staff-pattern number only after the Google/Firebase sign-in succeeds.
10. Verify that a non-staff-pattern number is rejected locally without any OTP request.
11. Verify resend cooldown and Firebase throttling behavior.

Do not claim OTP is operational until the Firebase console configuration and actual phone test both succeed.

---

## 33. 4.3.4.1 ACCEPTANCE TEST

### Identity
1. Fresh install launches as **DevMonitor Monitor**.
2. Google sign-in succeeds.
3. Firebase Authentication receives the Google credential.
4. A DevMonitor Account ID and Firebase UID are associated.
5. Sign-out clears the Google/Firebase session.

### Staff verification
6. Enter an invalid Nigerian number → no OTP request.
7. Enter a valid Nigerian number outside `0805557xxxx` → no OTP request.
8. Enter a valid `0805557xxxx` number before Google/Firebase sign-in → no OTP request.
9. After Google/Firebase sign-in, enter a `0805557xxxx` number → Firebase OTP request is allowed.
10. Enter the correct OTP → phone is linked to the Firebase account.
11. Verify the local account records the phone verification timestamp.
12. Repeat resend immediately → blocked by the 10-minute cooldown.
13. A successfully OTP-verified staff phone places the account in `AUTHORIZED` and unlocks full DevMonitor access, including Payment Intelligence.

### Existing DevMonitor behavior
14. Existing Device Monitor/SMS workflow remains operational.
15. SIMReg import/parser remains unchanged.
16. Payment calculation rules remain unchanged.
17. Existing SQLite data survives the version-8 → version-9 migration.
18. Google Drive backup/restore remains operational.
19. Ads/billing behavior remains unchanged.
20. Build with the established Android Code Studio phone environment before declaring stable.

---

## 34. 4.3.4.3 — STAFF ACCESS CORRECTION

The 4.3.4.1 hardening build incorrectly retained a second authorization gate after successful staff-line OTP verification. That does not match the established DevMonitor operating model.

For 4.3.4.3:
- successful Google/Firebase sign-in + successful OTP on a qualifying `0805557xxxx` staff line sets the local account to `AUTHORIZED`;
- the verified staff account receives full access to all DevMonitor features;
- Payment Intelligence is available to the verified staff account;
- raw HQ/SIMReg data remains available to the verified staff account according to the existing app functionality;
- no separate central authorization step is required for staff accounts;
- the non-staff/agent authorization path remains separate.

## 35. BUILD / DEVELOPMENT DISCIPLINE FOR 4.3.4.3

- Keep AGP 8.6.1.
- Keep Gradle 8.7.
- Keep Kotlin 2.0.21.
- Keep Java/JDK 17.
- Keep compileSdk/targetSdk 36.
- Keep the ARM-compatible AAPT2 phone-build override.
- Do not replace the phone build with a desktop-only AAPT2 workaround.
- Do not introduce Apache POI.
- Do not reset the SQLite database.
- Do not weaken the staff-pattern OTP gate to make testing easier.
- Treat successful OTP verification of a qualifying staff line as the staff-account authorization event for the current DevMonitor operating model.
- Do not claim the build is stable until it has been compiled and tested on the actual Android Code Studio phone environment.


## 4.3.4.6 — Payment Landing Access Model
- Payment landing page has two primary access paths: **Staff Login** and **Partner Login**.
- Verified staff: Google/Firebase identity + successful qualifying staff-line OTP grants full DevMonitor access, including all Payment Intelligence.
- Partner: enters phone number + Trade Code and submits an approval request to a staff member. Partner payment details remain locked until staff approval.
- Current 4.3.4.6 implementation sends the partner approval request through WhatsApp; a network-backed approval/synchronization mechanism can be added as the next step if required.


### 4.3.4.7.1 — Debug Authentication Fingerprint / Build Environment
- Debug signing report verified successfully with `sh gradlew signingReport`.
- Debug keystore: `/data/user/0/com.tom.rv2ide/files/home/.android/debug.keystore`
- Debug alias: `AndroidDebugKey`
- Debug SHA-1: `4B:41:36:12:EA:4C:9F:ED:93:46:1E:C6:68:77:45:7B:65:59:E0:02`
- Debug SHA-256: `1D:BE:EE:61:64:A2:FC:97:55:C3:BD:8A:7B:54:02:4A:68:22:64:69:0E:55:91:15:6D:4D:86:AE:B6:C8:AA:AA`
- Build environment: Android Code Studio on Android phone; Gradle 8.7; AGP 8.6.1; Kotlin 2.0.21; JDK 17; compileSdk/targetSdk 36; ARM-compatible AAPT2 override via `build-phone.sh`.
- Version naming for this authentication workstream remains the `4.3.4.x` family; corrections stay within that family.
- This fingerprint is the debug certificate used by the current phone development build. It must be added to the Firebase Android app configuration before retesting Google sign-in.

### 4.3.4.8 — Firebase Android OAuth Configuration
- Refreshed Firebase `google-services.json` integrated.
- Android OAuth client now present for `com.aziitech.simregmonitor` and matches the debug signing certificate.
- Build environment remains Android Code Studio on Android phone; Gradle 8.7; AGP 8.6.1; Kotlin 2.0.21; JDK 17; compile/target SDK 36; ARM-compatible AAPT2 override through `build-phone.sh`.
- Authentication corrections remain in the `4.3.4.x` family.

## 36. 4.3.4.9 — PARTNER ACCESS ARCHITECTURE (NEXT DEVELOPMENT STEP)

The next authentication/payment-access step is the real shared Partner Login → Staff Approval → Partner Unlock workflow.

### Authoritative partner approval model
- Partner approval must belong to the **partner account + Trade Code**, not to one physical Android device.
- Once staff approves a partner for a Trade Code, that approval remains valid when the partner changes phone, provided the partner authenticates as the same approved partner account.
- The same approved partner account may use the authorized Trade Code from the Android app, PC client, and web client.
- A new device is therefore a new authenticated session/device, not a new staff approval requirement.
- Device/session security remains separate from the underlying partner/Trade Code authorization.
- Staff revocation of the partner authorization must remove access across all platforms/devices using the shared authorization state.

### Access boundary
- Partner identity must be established before payment details are exposed.
- The backend must verify that the authenticated partner account has an active approval for the requested Trade Code.
- Knowing a Trade Code alone must never unlock payment information.
- A different partner account using the same Trade Code must not inherit another partner's approval.
- An approved partner Trade Code must not grant staff-level DevMonitor access.
- Verified staff accounts retain their existing full-access rule; no second Payment Intelligence gate is introduced for staff.

### Shared-platform requirement
The Android app, future PC client, and future web client must use one shared authorization authority. Local SQLite may cache operational state, but it must not become the authoritative source for cross-device partner approval.

The central authorization record should conceptually contain:
- partner account identifier;
- partner phone/contact identifier as applicable;
- Trade Code;
- approval status (`PENDING`, `APPROVED`, `REJECTED`, `REVOKED`);
- approving staff account identifier;
- request/approval/revocation timestamps;
- optional reason/audit information;
- platform/device/session audit information where useful for security.

### Current implementation gap
4.3.4.8 currently has the Partner Login form and WhatsApp approval-request notification path, plus a local authorization audit table. It does **not** yet provide a shared backend approval state that can synchronize staff approval to a partner's Android/PC/web sessions. The next implementation must add this shared authorization layer rather than pretending a WhatsApp message itself is approval.

### Database safety
- Extend the existing SQLite schema through migration only.
- Do not reset the existing database.
- Local audit/history should be preserved.
- Shared authorization identifiers must be stable across Android, PC, and web clients.

### Proposed workflow
1. Partner signs in/identifies the partner account and submits phone + Trade Code + staff approval target.
2. DevMonitor creates a unique authorization request with `PENDING` status in the shared backend.
3. Staff receives the request notification and reviews it while authenticated as a verified DevMonitor staff account.
4. Staff approves or rejects the specific partner account + Trade Code request.
5. The shared backend records the decision and audit information.
6. Partner sessions query/subscribe to the shared authorization state.
7. `APPROVED` unlocks only the authorized Trade Code's partner payment details.
8. Phone/device changes do not invalidate the approval.
9. `REVOKED` or other non-approved states lock the payment details again across platforms.

### Build/environment findings from inspection of DevMonitor 4.3.4.8
The project source still specifies the established phone-build environment:
- AGP 8.6.1
- Gradle 8.7
- Kotlin 2.0.21
- JDK 17
- compileSdk/targetSdk 36
- ARM-compatible AAPT2 supplied through `build-phone.sh`

A compilation attempt in the current non-phone inspection environment did **not** reach Kotlin/Java compilation. `build-phone.sh assembleDebug --console=plain` stopped immediately because this environment has no ARM-compatible AAPT2 at the configured locations. The diagnostic showed:
- `HOME=/home/oai`
- `PREFIX=`
- `ANDROID_HOME=`

A direct Gradle-wrapper check also could not download Gradle 8.7 because this inspection environment has no network access (`UnknownHostException: services.gradle.org`).

Therefore this inspection environment cannot certify a compilation result. The established Android Code Studio phone environment remains the authoritative place to run the actual build.

### Next phone compilation command
From the project root on the Android Code Studio phone:

`sh build-phone.sh assembleDebug --console=plain`

If the phone build reports a real Kotlin/Android compilation error after AAPT2 is found, capture that complete error before making source changes. Do not change AGP/Gradle/Kotlin versions merely to resolve an unrelated compilation problem.


## 37. 4.3.4.9 — SHARED PARTNER AUTHORIZATION FOUNDATION IMPLEMENTED

- Implemented the first working shared authorization layer using Firebase Firestore.
- The authoritative approval identity is **Firebase partner account UID + Trade Code**.
- Physical device is explicitly not the owner of approval. Device model is retained only as request/audit context.
- Partner approvals are designed to survive phone changes and to be usable by Android, future PC, and future web clients that authenticate the same partner account.
- Added shared request lifecycle: `PENDING` → `APPROVED` / `REJECTED`, with `REVOKED` supported for future revocation workflows.
- Added staff approval UI to the Payment Intelligence landing flow for verified staff accounts.
- Partner payment view filters the available payment rows to the approved Trade Code only.
- Partner checks for an existing approved Trade Code before creating a duplicate request.
- Pending request status can update live through a Firestore document listener.
- Added `firestore.rules`; rules require the partner to create/read its own request and require the configured verified staff-line identity for staff review/update.
- The shared backend is now the cross-platform authorization authority; SQLite remains local operational storage and is not authoritative for partner approval.
- Existing DevMonitor database is preserved; no reset or destructive migration was introduced.
- Version advanced to `4.3.4.9` (versionCode 67).
- 4.3.4.8 Firebase `google-services.json` was retained unchanged.

### Build status
- 4.3.4.8 is confirmed compiled and working on the user's Android phone.
- This 4.3.4.9 source was prepared from that confirmed baseline.
- The present inspection environment cannot execute the Gradle build because it cannot download Gradle 8.7 (`UnknownHostException: services.gradle.org`) and lacks the phone ARM AAPT2 binary.
- Therefore the authoritative 4.3.4.9 compilation test must be performed in Android Code Studio on the user's phone.

### Required Firebase console step before shared approval can work
- Enable **Cloud Firestore** in the existing Firebase project `fieldpulse-b3eb3` if it is not already enabled.
- Publish the included `firestore.rules` to the project's Firestore database.
- Do not use permissive/test rules in production.
- The Android app code now expects the collection `partner_authorization_requests`.

## 38. 4.3.4.10 — AUGUST HISTORICAL SEED + SAVED REPORT DELETE

- The confirmed 4.3.4.9 partner-authorization build remains the source baseline.
- The supplied August 2026 full-month SIMReg workbook is bundled at `app/src/main/assets/historical/august_2026_simreg_report.xlsx`.
- It is installed only once into the existing saved SIMReg report library using a stable seed ID, preventing duplicate copies on later launches.
- The source workbook bytes are not rewritten. Because the workbook heading contains an inconsistent date range, the seed metadata deliberately records `2026-08-01` through `2026-08-31` and `fullMonth=true` so historical comparison logic uses August correctly.
- The seed participates in the existing three completed-full-month historical archive retention policy and may eventually age out automatically.
- Saved SIMReg reports now have `Open` and `Delete` actions. Delete requires confirmation and removes only that saved workbook/metadata entry; Device Monitor/SMS data are unaffected.
- Next phone build: DevMonitor 4.3.4.10.
- Phone build command remains: `sh build-phone.sh assembleDebug --console=plain`.

## 39. 4.3.4.11 — AURORA UI REDESIGN

- Visual redesign applied from the confirmed 4.3.4.10 baseline.
- Replaced the former green-dominant palette with a deep navy/aurora palette using blue, cyan and violet accents.
- Added dimensional primary and outlined buttons with restrained elevation/shadow to create a 3D feel without changing button behavior.
- Added animated transitions between the main Dashboard, Devices, Agents, Payments and Settings pages.
- Added selected bottom-navigation icon scale animation.
- Navigation drawer continues to use native Material motion and now inherits the new visual language.
- Redesigned adaptive and legacy launcher artwork with the DevMonitor FP/signal identity.
- Avoided continuous high-cost animations so the redesign does not unnecessarily worsen the previously observed sluggishness.
- No authentication, Firestore authorization, SIMReg, August historical seed, SQLite, SMS or payment business logic was intentionally changed.
- Version advanced to `4.3.4.11` (versionCode 69).
- Phone build command remains: `sh build-phone.sh assembleDebug --console=plain`.

## 40. 4.3.4.12 — AURORA UI BUILD CORRECTION
- Correction build for the 4.3.4.11 Aurora UI source.
- Fixed over-broad Compose control replacement: native TextButton/IconButton calls are restored; intended Button/OutlinedButton calls remain wrapped by DevMonitorButton/DevMonitorOutlinedButton.
- Fixed DevMonitorUi outlined-button colors to use Material 3 ButtonColors/ButtonDefaults.outlinedButtonColors().
- No authentication, Firestore authorization, SIMReg, August seed, SQLite, SMS or payment behavior intentionally changed.
- Next phone compilation command: `sh build-phone.sh assembleDebug --console=plain`.


## 4.3.4.13 correction
- Fixed four Kotlin `return@Button` labels in `Authentication.kt` after the Aurora custom button migration. Changed them to `return@DevMonitorButton`.
- Preserved Firebase authentication configuration and all existing functionality.


## 4.3.4.14 — Aurora UI Polish
- Visual correction from device screenshots: disabled controls no longer carry heavy shadows, light surfaces are blue-white rather than lavender, and Payment Intelligence respects Scaffold insets.


## 4.3.4.15 — AURORA UI COMPOSITION REDESIGN
- This build is the substantive UI redesign following the 4.3.4.13/4.3.4.14 screenshot review.
- Dashboard composition was rebuilt around the Aurora hero + live metric cards + attention centre + batch control + HQ report intelligence.
- Bottom navigation replaced Unicode glyphs with custom vector-like Canvas icons and a dark DevMonitor navigation surface.
- Payment Intelligence landing cards, Agents page and Settings page now share the Aurora glass-panel hierarchy.
- Device Monitor top-level container uses the Aurora panel treatment while its operational controls remain functionally unchanged.
- No reset of SQLite or parser/auth/payment logic.
- Phone build command: `sh build-phone.sh assembleDebug --console=plain`.


## 4.3.4.16 — Aurora Compose Import Fix
- Fixed missing Compose imports in ManagementScreens.kt for background() and RoundedCornerShape().
- No functional/authentication/database/parser changes.

## DEVICE MONITOR ACTIVATION SOURCE — NON-NEGOTIABLE

For Device Monitor:

- **Active is the activation count used by payment/progression.**
- **MTD is display/monitoring information only.**
- Never substitute MTD for Active in payment calculations.
- If Active is unavailable, the activation count is unknown; do not silently fall back to MTD or zero.

Payment flow:
`Device Monitor → Active → activation count → payment-cycle/progression calculation`

This rule applies to all future Device Monitor/payment integrations.


# RECENT MASTER WORK RECORD — 4.3.5.37 THROUGH 4.3.5.51

## 4.3.5.37 — Compile correction
- Corrected Kotlin function-type invocation in `MainActivity.kt` where named arguments were invalid for `beginRun`.
- Calls were changed to positional arguments only.
- No payment calculation/pathway changes were intended.
- Phone/Android Code Studio remains the authoritative build environment.

## 4.3.5.38 — Performance and report-loading stabilization
- Reduced report-screen gesture overhead by using one shared pinch/zoom gesture path instead of per-row gesture detectors.
- Shared horizontal table scrolling and reduced unnecessary Compose recomposition.
- XLSX parsing was made more selective so irrelevant ZIP entries such as drawings/images are not unnecessarily processed.
- Removed the previous giant workbook-to-one-String approach and introduced worksheet preview/targeted parsing.
- Added normalized-report query indexes.
- Avoided unnecessary XLSX byte-array copies.
- Goal: reduce file-loading latency, scrolling stalls, memory pressure and crash risk without changing payment calculations.

## 4.3.5.39 — My Devices primary working database
- Established `my_devices.db` as the user's primary everyday working database.
- Company normalized activation data remains authoritative historical storage.
- Newer imported SIMReg/Activations data replaces older values for the same device/date in normalized storage.
- My Devices is rebuilt from saved device codes and the configured working date window.
- My Devices is shown by default; `Show All Devices` remains the explicit full-company escape hatch.
- Payment/progression reads My Devices first, with company-normalized fallback.
- Migration to My Devices schema v2 was documented/fixed.
- Payment calculation/resolver logic was intentionally protected.

## 4.3.5.40 — Isolated Payment Card Display Fork
- Experimental, isolated display-only fork for showing separate Device Monitor and Loaded Report payment cards.
- No payment calculation, resolver or payment database changes were intended.
- Mainline baseline remains separate unless the fork is explicitly requested for merging.

## 4.3.5.41 — My Devices/date-window and totals refinement
- My Devices working window: 1st–20th uses previous-month 21st through today; 21st onward uses current-month 1st through today.
- Company normalized storage retains configured historical data.
- General device-monitor totals use the labels `CYCLE TOTAL` and `MONTH-TO-DATE`.
- Device ordering no longer applies alphabetical/numerical sorting; parsed/import order is retained.
- No special GLO-GD-first ordering rule is used.

## 4.3.5.42–4.3.5.44 — Initial Month-to-Month implementation and corrections
- Added a persistent Month-to-Month Comparison feature with manual Refresh and retained results.
- The feature is month-based, not payment-cycle-based.
- Current period is current-month data through the effective available-data cutoff.
- Previous period is the previous month through the corresponding day-of-month cutoff.
- Corrected visibility/setup behavior so the Month-to-Month entry is available without auto-calculating.
- Documented the initial My Month-on-Month implementation.

## 4.3.5.45–4.3.5.48 — Month-to-Month/report-aware refinement
- Refined Month-to-Month to use the latest reliable available report/current-month data rather than blindly assuming today's date contains data.
- Comparison cutoff is driven by actual available data and is shared appropriately for the comparison population.
- Device Monitor data remains an eligible source whenever available and newer than loaded report data.
- The feature remains strictly month/report-data based; cycle and activation-cycle concepts must not be introduced into this calculation.

## 4.3.5.49 — Month-to-Month by Device
- Added the Month-on-Month by Device expansion for supported Cluster Manager/Partner views.
- Kept the feature separate from the payment calculation pathway.
- Preserved the report-aware cutoff principle.

## 4.3.5.50 — Fork documentation process
- Added the formal `FORK_DOCUMENTATION.md` process for deferred experiments.
- First documented fork: Historical Device Ownership for Month-to-Month Comparisons.
- Fork remains deferred and must not be merged into mainline without explicit request.
- Future forks should record: problem, intended approach, protected behavior, normalization impact, performance questions, testing, acceptance criteria and merge conditions.

## 4.3.5.51 — Report cutoff and historical-scope correction
- Corrected Month-to-Month scope around the latest available current-month report date and corresponding historical comparison cutoff.
- The current population is the devices currently attributed to the user in the current-month data through the available cutoff.
- The previous population is the devices attributed to the user in the previous month through the same day-of-month cutoff.
- Device populations do not have to be identical between months.
- Staff/device transfers are NOT solved by this release; historical ownership attribution remains a deferred fork.
- Do not introduce cycle-based or activation-based language into Month-to-Month.
- This release continues to protect payment calculation/pathway code from unrelated changes.

## 4.3.5.53 — Month-on-Month cutoff integrity fix
- Root cause identified: the XLSX importer could normalize future/placeholder daily columns that were physically present in a workbook but outside the report's declared coverage window.
- Example: a September 1–23 report may contain columns 24–31 filled with zeros; those cells are not available data and must not become report dates.
- Import normalization now filters daily values to `coverageStart..coverageEnd`.
- Normalized report selection also respects each report's declared `coverage_end`.
- Without a newer Device Monitor observation, the comparison cutoff follows the latest actual report coverage date.
- Verified with supplied AIYETORO data: Sep 1–23 = 1,204; Aug 1–23 = 1,058; expected change +146 (+13.8%), cutoff 2026-09-23.
- The prior 1,155 previous-month value represented August 1–25 and therefore did not satisfy the same-period rule.
- Payment calculation/resolver/progression/pathway logic remains protected.

## 4.3.5.55 — Month-on-Month Device Monitor freshness fix
- Prevented stale/restored Device Monitor observations from extending the current report cutoff.
- A Device Monitor observation can extend a loaded current-month report only when its `received_at` timestamp is strictly newer than that report's `imported_at` timestamp.
- The same freshness gate is applied when choosing the current-month Device Monitor `Active` value, preventing stale monitor rows from overriding newer report data.
- If no current-month report exists, Device Monitor remains eligible to provide the current cutoff.
- Supplied AIYETORO acceptance target remains: cutoff 2026-09-23; current 1,204; previous 1,058; change +146 (+13.8%).
- Payment calculation/resolver/progression/pathway logic remains protected.

## Ongoing non-negotiable rules
- Do not modify payment calculation/resolver/pathway code for unrelated tasks.
- Device Monitor `Active` remains the activation count used by payment/progression; MTD is display/monitoring information only.
- My Devices is the primary everyday working DB; company normalized data remains authoritative historical storage.
- Newer report data replaces older normalized values for the same device/date.
- User-facing import update messaging should remain a single overall notification rather than a detailed per-cell audit UI.
- Month-to-Month is month-based/report-data-based, never cycle-based.
- Deferred forks are documented first and are not merged without explicit instruction.

## 4.3.5.52 — Month-on-Month data-selection correction
- Corrected the remaining Month-on-Month issue where the page could fall back to the phone date instead of the latest actual current-month report data date.
- Current report selection now prefers normalized activation data and uses the newest actual current-month activation date as the cutoff.
- Previous report selection likewise prefers normalized activation data for the previous month.
- Normal STAFF attribution now uses `staff_name` from each month's report rather than substituting territory for ownership.
- Current and previous populations remain independently determined for their respective months.
- Device/hierarchy drill-down calculations are explicitly restricted to their requested codes.
- Added a visible **Refresh Comparison** button inside the Month-on-Month performance card.
- No payment calculation/resolver/progression/database pathway was modified.
- Historical device transfer handling remains deferred to Fork 001.

## 4.3.5.60 refinement
- 4.3.5.60 compile correction: preserved the refinement UI/search behavior while fixing local-function declaration order and routing Month-to-Month search through CompanyActivationStore.
- Cosmetic/interaction: user-scoped notice is now a top, layout-participating banner rather than a bottom Snackbar overlay.
- Partner enquiry: Loaded Report menu accepts Trade Code or Channel Partner Name; name resolves to a unique Trade Code for existing workflows.
- No payment pathway changes.

## 4.5.0 — Sound & Haptics UX layer
- Added a lightweight local feedback layer through `DevMonitorSound` using four bundled PCM tones.
- Meaningful task events can provide sound/haptic feedback: monitoring start, successful task completion, warnings/failures, retry completion, Excel export completion/failure, and explicit dashboard/payment refresh completion.
- Ordinary navigation and routine taps remain silent to avoid notification fatigue.
- Added `Sound & Haptics` controls under Monitor Settings with Event Sounds and Haptic Feedback toggles.
- Sound is local-only; no network audio, streaming, background playback or persistent audio service was introduced.
- Added Android `VIBRATE` permission solely for the optional short haptic confirmations.
- Existing monitoring, payment, report, profile isolation and user-initiated performance rules are unchanged.


## DevMonitor 4.5.3 — Visual Trends
- Added the Phase 1 visual-trends layer using the existing profile-scoped `daily_observations` data.
- Users can inspect 7-day or 30-day charts for SIMReg sales, Active totals and Bar 48/Conversion Lost, plus Company/Partner sales mix.
- Trend range queries are read-only and use the active profile database.
- Heavy trend aggregation is explicitly user initiated through Refresh or range selection; merely opening the trends view never starts a calculation.
- Missing observation days are not converted into zero-sales days, preserving the established monitoring semantics.
- Added Visual Trends entry points from the dashboard and app drawer.
- Payment calculation/resolver/progression, Device Monitor SMS behavior, report authority, Month-to-Month architecture and profile isolation remain protected.


# LOCKED PERFORMANCE BASELINE — DevMonitor 4.5.17

On 2026-09-29 the user explicitly accepted DevMonitor 4.5.17 as the protected performance baseline. The user reported that table scrolling was exceptionally fluid, navigation between sections was fluid, existing data opened intact rather than as an empty app, and a phone release build that had previously taken about 32 minutes completed in about 4 minutes. Future changes must preserve these observed characteristics unless the user explicitly authorizes a new baseline.

## 4.6.0-NEXT fork

The NEXT LEVEL development fork starts from this locked baseline and bundles the mapped Phase 3 and Phase 4 milestones into one integrated experimental build: explicit-refresh advanced trends, deterministic anomaly detection, local-vs-HQ reconciliation, explain-this context, offline/data-freshness status, Sync Centre recovery controls, diagnostics, SQLite optimization and an incremental feature-module registry. Substantial NEXT LEVEL calculations run away from the Compose UI thread and remain user initiated. Payment logic, the 21st-to-20th payment cycle, the four physical Month-on-Month databases, SMS protocol and report authority are preserved.

## v170 — Recovery Base + Floating Loader + Same-Coverage HQ Replacement

This is the advanced recovery package name/version of the same controlled development point. No functional regression or new application feature is implied by the version-number advance; the code remains based on v162.1 with the approved floating waiting UI and same-coverage HQ replacement behavior.

## v165 — Recovery Base + Floating Loader + Same-Coverage HQ Replacement

- Recovery base: v162.1.
- Retained approved post-v162.1 UI improvement: single informative floating waiting window with operation, major step, projected percentage, one progress bar, and concise status.
- Changed HQ import acceptance so same coverage/end date is a valid complete-snapshot replacement rather than a duplicate rejection.
- Preserved older-report rejection and newer-report replacement.
- Current and immediately previous calendar months remain independent physical HQ stores.
- Deliberately did not carry forward the v163-v165 Loaded Report workflow/render-selection experiments; those remain separate work for controlled reimplementation.
- Protected PaymentEngine, payment formulas/progression, Device Monitor/SMS logic, Profile Builder, v162 dashboard/settings/My Devices UI, and release identity.
- Current date testing note: October 2026 current month; September 2026 previous month; August is outside the active two-month HQ window.


## v171 — Historical snapshot safeguards and Loaded Report display recovery (2026-10-01)

- Kept the two-physical-HQ-month architecture: current calendar month and immediately previous calendar month.
- Preserved complete-snapshot replacement, older-coverage rejection, same-coverage replacement, out-of-order month acceptance, and transactional database replacement. Added a pre-write guard so a workbook with no usable device records cannot replace a stored snapshot.
- Refined import semantics to **calculation-isolated, not UI-isolated**: importing does not trigger Device Monitor, payment, MOM, dashboard, or estimate recalculation; the exact parsed report is nevertheless presented immediately in Loaded Report.
- Opening Loaded Report now retrieves the latest stored report directly from the stored-report index instead of routing through the current-month cutoff/filter helper.
- The report viewer explicitly prioritizes the supplied/imported report over the My Devices working set and retains the established automatic table positioning.
- The single app-wide floating waiting window remains visible at 100% until the report table has been positioned and is ready; no duplicate loader or new progress-calculation system was added.
- PaymentEngine, payment formulas, cycle rules, and payment progression were not modified.
- Build versionCode advanced to 171; versionName remains 4.6.0-NEXT.


## v176 — Company Structure Cascade Clarification

**Status: IMPLEMENTED IN v176 SOURCE PACKAGE**

The supplied `GLOZONE - NEW REG` structure is now represented in Profile Builder as:

**Cluster (Division) → Region → Territory → Staff**

The existing internal `division` field is retained for compatibility; the UI explicitly labels it **Cluster (Division)**. The Company Skeleton remains identity-only and is the source for these selectors before activation data exists. Territory is selected before Staff so the final staff list is constrained by all three organisational levels.

Selector-only source variations caused by case or apostrophe typography are deduplicated for display, while the original source values remain stored. No activation, payment, HQ snapshot, or MOM calculation pathway is changed.

## v175 — Company Skeleton / Profile-First Onboarding

**Status: IMPLEMENTED IN v175 SOURCE PACKAGE**

Fresh-install scope now starts from a lightweight Company Skeleton rather than requiring a full activation report before profile construction. The skeleton contains identifiers and organisational relationships only. It is separate from the two authoritative HQ month stores.

Required fields from the supplied company workbook: SN, Trade Code, Channel Partner Name, Device ID, Cluster, Region, Territory, Staff Name. The supplied workbook did not contain a detailed DIVISION column; the parser supports DIVISION for future workbooks without inventing one for the current source.

Profile Builder now searches the skeleton and supports LOAD COMPANY DATA to rebuild the skeleton from another company workbook without importing activation/performance data or triggering downstream calculations.

Dashboard now presents BUILD PROFILE prominently. Fresh installs receive a one-action Build Profile spotlight with Skip. The introduction ends with BUILD PROFILE.

Imported HQ report presentation prioritizes My Devices, then same staff context, region, division when supplied, and the wider company. This is presentation ordering only; authoritative HQ import remains atomic and complete.

Protected: payment logic, Device Monitor business rules, two-month HQ architecture, MOM logic, and explicit-refresh performance culture.

## v179 — SMS CHECKER tour compile correction

**Status: IMPLEMENTED IN v179 SOURCE PACKAGE**

The GitHub cloud build for v178 reached Kotlin compilation and reported one source error at `MainActivity.kt:4598`: the dashboard `LazyColumn` supplied a positional `Modifier` argument after the named `state` argument. The call was corrected to use the named `modifier =` parameter.

No SMS CHECKER tour logic, Device Monitor logic, payment logic, report logic, Company Skeleton logic, or database architecture was changed by this compile correction.

The versionCode is advanced from 178 to 179 so the corrected source package is unambiguous in cloud-build selection.

## v178 — Context-aware static SMS CHECKER guided tour

**Status: IMPLEMENTED IN v178 SOURCE PACKAGE**

The SMS CHECKER tour is now a dashboard-entry tour rather than a general Device Monitor-arrival tour. It automatically launches only when the user presses **SMS CHECKER** on the dashboard for the first time. The Check My Devices route, which can already have established the user's profile, SIM, and device scope, does not launch it.

The tour uses a dedicated `sms_dashboard_tour_completed` state. Existing Device Monitor/Check My Devices usage therefore does not falsely mark the dashboard tour as completed.

The SMS CHECKER tour is context-aware and static/automatic in presentation. It skips setup stages already satisfied by the current state (for example an active selected SIM or already-loaded codes) and does not require a separate Next button. Where a real workflow action is still required, the tour highlights that actual control and advances when the operation reaches the next state.

Manual **Take the Guided Tour Again** remains available and can intentionally restart the tour.

Protected: Check My Devices workflow, SMS protocol, payment logic, HQ report authority, Company Skeleton/profile hierarchy, MOM architecture, and phone-performance rules.


## v180 — Profile onboarding + SMS CHECKER simplification + dashboard tour targeting

**Status: IMPLEMENTED IN v180 SOURCE PACKAGE**

### SMS CHECKER
- Removed the SMS CHECKER guided tour completely.
- SMS CHECKER no longer launches a guided tour from the dashboard, Check My Devices, Device Monitor, the drawer, or Settings.
- Removed the SMS-specific guided-tour state and restart entry points.
- SMS operational behavior, SIM selection, SMS protocol, batch checking and saved-list behavior remain protected.

### Dashboard tour
- Corrected dashboard tour scrolling/target positioning so stages covering **LOAD REPORT** and **EARNING PROGRESS** keep the actual action-card row in view.
- The tour no longer scrolls past those cards to unrelated lower dashboard content such as Company/Partner cards.
- The actual `load_report` and `earning` targets remain the rendered cards themselves.

### Profile Builder
- Prominent **BUILD PROFILE** dashboard card is now shown only while no profile exists. After at least one profile is successfully built, that prominent first-run card is removed.
- Added **Manage Current Profile** access when profiles exist so profile management, including deletion, remains discoverable after multiple profiles are created.
- Added a visible profile verification reminder asking users to confirm that the populated identity, role, organisational scope and selected device accurately describe them before saving.
- When User Type is **Agent**, the selected device is explicitly constrained to one device. The user can search, select one matching device and continue; returned search results are not registered wholesale.
- Agent profile save/rebuild paths use that one selected device as the profile's My Devices scope.

### User-facing terminology
- **Company Skeleton** is retained as an internal engineering/data-store term only.
- User-facing Profile Builder/onboarding language now uses **Company Directory** / company data wording instead.
- No internal `CompanySkeletonStore` architecture or identity-data model was renamed merely for UI wording.

### Device Monitor / Report presentation requirement
- Fresh entry to the Report/Device Monitor table starts with **My Devices only**.
- Additional hierarchy levels are user-initiated through incremental loading controls.
- Expanded table state may remain during the active app session, but a newly opened app/report session starts again at My Devices.
- The full company dataset remains indexed/available for general search even when not rendered in the initial table view.

Protected: PaymentEngine/payment formulas and progression, 21st-to-20th payment cycle, HQ report authority, two-month HQ architecture, SMS protocol, profile isolation, and explicit-refresh performance culture.


## v181 — SMS CHECKER removal hardening + profile/device workflow correction

**Status: IMPLEMENTED IN v181 SOURCE PACKAGE**

- Removed the SMS CHECKER guided-tour implementation without removing the underlying SMS workflow, permissions, SIM discovery, contact/location helpers, or `beginRun` execution path.
- Restored the required SMS helper/launcher declarations after the v180 cleanup accidentally removed their declarations while removing the tour.
- Dashboard orientation tour order is now explicitly: Today's Operations → Your Profile → LOAD REPORT → EARNING PROGRESS → SMS CHECKER → MY DEVICES → PAYMENT CYCLE. The LOAD REPORT and EARNING PROGRESS stages therefore target their own registered dashboard cards.
- BUILD PROFILE remains visible only while no profile exists.
- Agent profile selection remains one-device: search results are choices, and the user selects one device before continuing.
- Profile verification warning remains required before saving.
- Multiple-profile management retains a Delete Profile action for the currently edited profile.
- User-facing Company Skeleton terminology remains replaced by Company Directory/company-data wording.
- My Devices remains the default freshly opened Report/Device Monitor table view; broader hierarchy loading remains explicit and the full indexed company dataset remains available for general search.

**Protected:** payment formulas/progression, 21st–20th payment cycle, SMS protocol, Device Monitor business rules, report authority, database architecture, and existing profile-owned data cleanup rules.

## v182 — Dashboard Loaded Report search crash isolation (2026-10-03)

**Status: IMPLEMENTED IN v182 SOURCE PACKAGE**

### Dashboard Search Source Routing
- Dashboard payment search can return two source-specific results for the same device: **Device Monitor** and **Loaded Report**.
- Tapping **Device Monitor** continues to open the Device Monitor payment/result context.
- Tapping **Loaded Report** now opens a targeted Loaded Report context for the selected device rather than loading the entire HQ snapshot into Compose state.
- The targeted path reads only the selected device's company metadata and activation-day records from the authoritative stored report.
- This prevents a large HQ report from being materialized solely to satisfy a single dashboard search result, addressing the observed wait → freeze → Android process termination behaviour.
- The normal dashboard **LOAD REPORT** action is unchanged and remains the deliberate route for opening the broader stored report viewer.

### Protection
- No payment calculation/progression logic changed.
- No 21st-to-20th payment-cycle rule changed.
- No SMS protocol or SMS CHECKER workflow changed.
- No HQ import/storage authority or two-month database architecture changed.
- No profile or My Devices ownership rules changed.

## v184 — Dashboard Action Centre role visibility

Implemented dashboard visibility rule: the **ACTION CENTRE** card is for Agent/Partner device-monitoring workflows and is hidden for Staff profiles. The active profile is the primary source for the role so switching profiles updates visibility correctly; the stored role setting is only a fallback. This change does not alter the Action Centre alert logic or any payment/SMS/report behaviour.

