## Build target: DevMonitor 4.5.14 / versionCode 148

# Cloud build — DevMonitor 4.5.13

This package is intended for the current cloud build workflow.

```sh
./gradlew :app:assembleDebug --no-daemon --console=plain
```

For a release build, use the project's existing release signing configuration.
The source code and database architecture are identical to the phone package.
