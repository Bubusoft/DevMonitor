# NEXT LEVEL — Incremental Delivery Tracker

This file is the machine-readable human tracker for the NEXT LEVEL product programme. Every future upgrade should update this file, `MASTER_WORK_SHEET.md`, and `CHANGE_LOG.md` in the same change set.

| ID | Phase | Upgrade | Status | Version | Notes |
|---|---|---|---|---|---|
| NL-P1-01 | 1 | Command-centre dashboard foundation | DONE | 4.5.0 | Dashboard hierarchy expanded around operations, actions and intelligence; dashboard calculations are now explicit-refresh driven. |
| NL-P1-02 | 1 | Global dashboard search | DONE | 4.5.0 | Searches active profile device codes and visible alerts. |
| NL-P1-03 | 1 | Quick action strip | DONE | 4.5.0 | Monitor, My Devices, Reports and Payments. |
| NL-P1-04 | 1 | Payment-cycle progression card | DONE | 4.5.0 | Uses existing PaymentRules/company cycle data; progression is calculated only when the user refreshes it. |
| NL-P1-05 | 1 | Action Centre | DONE | 4.5.0 | Shows priority flags and opens existing alert/payment pathways. |
| NL-P1-06 | 1 | In-app notification/inbox | DONE | 4.5.2 | Profile-scoped local inbox, unread badge, action notices and month-end reminder. |
| NL-P1-07 | 1 | Visual trends | DONE | 4.5.3 | User-initiated 7-day/30-day profile-scoped trend charts for sales, active devices, Bar 48 and ownership mix. |
| NL-P1-08 | 1 | Device-card redesign | DONE | 4.5.4 | Display-only redesign of Device Monitor result cards; existing payment calculation/pathway remains unchanged. |
| NL-P1-09 | 1 | Loading/empty/error/offline states | DONE | 4.5.5 | Standardized reusable states across dashboard, Device Monitor, Visual Trends, payment search and online reports; no business/payment logic changed. |
| NL-P1-10 | 1 | Motion/accessibility polish | DONE | 4.5.6 | Reduced-motion-aware feedback, reusable accessibility semantics and touch-target polish; no business/payment logic changed. |
| NL-P1-11 | 1 | Sound & haptics feedback | DONE | 4.5.0 | Short local event cues and optional haptic feedback; no background audio. |
| NL-P1-12 | 1 | Appearance/theme evolution — Aurora refinement + selective green variations | DONE | 4.5.1 | Shared Aurora surfaces, dashboard accents and payment-cycle presentation refined with emerald/mint/deep-green variations while retaining blue/cyan/violet roles. |
| NL-P2-01 | 2 | Tasks/follow-ups | DONE | 4.5.7 | Persistent user-created operational tasks linked to devices, partners or staff; manual completion and due dates; no automatic heavy processing. |
| NL-P2-02 | 2 | Notes | DONE | 4.5.8 | Persistent profile-local operational notes linked to devices, partners or staff; manual pin/edit/delete/search; no automatic heavy processing. |
| NL-P2-03 | 2 | Device activity timeline | DONE | 4.5.9 | Unified device history surface combining SIMReg observations, query history, tasks and notes; user-initiated only. |
| NL-P2-04 | 2 | Shareable daily snapshot | DONE | 4.5.10 | Image/PDF daily operational summary; user-triggered. |
| NL-P2-05 | 2 | Intelligent export menu | DONE | 4.5.10 | Quick/Detailed/Payment/Exception/HQ/Full export choices over existing workbook engine. |
| NL-P2-06 | 2 | Payment engine + rolling report database | DONE | 4.5.11 | Separate Loaded Report and Device Monitor calculators; Device Monitor may use Loaded Reports only for historical Active baselines; continuous three-calendar-month report retention with current-month default table view. |
| NL-P3-01 | 3 | Advanced trends | PLANNED | — | 7/30-day performance. |
| NL-P3-02 | 3 | Anomaly detection | PLANNED | — | Deterministic operational signals first. |
| NL-P3-03 | 3 | HQ reconciliation | PLANNED | — | Local vs authoritative HQ evidence. |
| NL-P3-04 | 3 | Explain-this panels | PLANNED | — | Explain data sources and calculations. |
| NL-P4-01 | 4 | Offline-first status | PLANNED | — | Explicit connectivity/data freshness. |
| NL-P4-02 | 4 | Sync Centre | PLANNED | — | Drive backup/sync state and recovery. |
| NL-P4-03 | 4 | Performance/database optimization | PLANNED | — | Indexes, profiling and cached summaries. |
| NL-P4-04 | 4 | Diagnostics Centre | PLANNED | — | SMS/SIM/database/cloud/storage health. |
| NL-P4-05 | 4 | Modular architecture | PLANNED | — | Break down MainActivity by feature. |

## Global product/performance correction — 4.5.0

- Product name is now **DevMonitor** in current UI, roadmap, tracker, master sheet and change log.
- Legacy lowercase database/table, preference, Firebase-project and billing identifiers are intentionally retained for compatibility; they are technical storage IDs, not product branding.
- Dashboard aggregation is no longer recalculated automatically when profiles/codes change.
- Payment progression on the dashboard is explicitly refreshed by the user.
- Existing month-end background scheduling is disabled; the compatibility receiver is inert and cancels legacy alarms.
- Dashboard shows a lightweight month-end review reminder on the 18th–20th; the reminder never starts operations.
- A dashboard refresh may follow a completed user-started monitoring pass because it is the natural immediate next step and remains foreground-bound.
- No new heavy background processing was introduced.

## Change protocol

For every completed item:
1. Update this tracker.
2. Add the implementation note to `MASTER_WORK_SHEET.md`.
3. Add a dated/versioned entry to `CHANGE_LOG.md`.
4. Preserve existing business logic unless the tracker explicitly calls for a logic change.
5. Record build/test status separately from implementation status.

### 4.5.0 UX enhancement — Sound & Haptics
- Added `NL-P1-11 Sound & Haptics feedback` — **DONE** in 4.5.0.
- Four short local sound cues cover meaningful operational events: monitoring start, successful completion, warning/failure, and completed retry pass.
- Export and explicit dashboard/payment refresh completion also use the success cue.
- Added user controls under Monitor Settings for Event Sounds and Haptic Feedback.
- No background audio, network audio, or continuous playback was introduced.

## 4.5.2 compile correction / cloud-build preparation
- Corrected nullable active-profile ID usage in the Notification & Inbox layer by resolving a safe profile ID before calling `NotificationStore`.
- Corrected the notification drawer `Text()` call to pass its modifier by name, avoiding the Kotlin/Compose argument-order error.
- Added `.github/workflows/android-build.yml` for GitHub Actions Java 17 / Gradle 8.7 debug builds.
## 4.5.3 — Visual Trends
- Completed `NL-P1-07 Visual trends`.
- Added explicit-refresh 7-day and 30-day visual trend views for the active profile.
- Charts cover SIMReg sales, active-device totals and Bar 48/Conversion Lost movement, with Company/Partner sales mix.
- Missing observation days remain missing rather than being interpreted as zero sales.
- Trend aggregation is user initiated and profile scoped; opening the screen does not trigger heavy calculation.
- Added a dashboard entry point and drawer entry point.
- Added `DatabaseStore.observationsBetween(...)` as a read-only range query.
- No payment, SMS, report authority, Month-to-Month or background-processing logic was changed.

## 4.5.5 — Loading / empty / error / offline states
- Completed `NL-P1-09 Loading/empty/error/offline states`.
- Added reusable state components and applied them to major user-facing surfaces.
- Explicit loading, empty, retry/error and offline messaging now uses a consistent DevMonitor presentation.
- No payment, SMS, database-authority or background-processing logic was changed.

## 4.5.4 — Device-card redesign
- Completed `NL-P1-08 Device-card redesign`.
- Redesigned the My Devices result cards with clearer ownership/status hierarchy, compact Today/MTD/Bar 48/Bar 96 metrics, payment-progression entry, flag/error visibility, and clearer primary/recheck actions.
- The redesign only presents existing Device Monitor result data and routes to the existing Device Payment Card.
- **Payment calculator, PaymentRules, PaymentCycleResolver, progression thresholds, and payment data pathways were not changed.**
- No new background processing was introduced.
