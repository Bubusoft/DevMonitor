package com.aziitech.simregmonitor

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.time.YearMonth
import java.time.LocalDate
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun AgentManagementDialog(
    store: DatabaseStore,
    codes: List<String>,
    onDismiss: () -> Unit,
    onPickContact: (Long) -> Unit,
    onGetLocation: () -> Pair<Double, Double>?,
    onOpenMaps: (Double?, Double?) -> Unit
) {
    var search by remember { mutableStateOf("") }
    var agents by remember { mutableStateOf(store.agents()) }
    var editing by remember { mutableStateOf<Agent?>(null) }
    var name by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var lat by remember { mutableStateOf("") }
    var lon by remember { mutableStateOf("") }
    var showEditor by remember { mutableStateOf(false) }
    var selectedAgent by remember { mutableStateOf<Agent?>(null) }
    var linkCode by remember { mutableStateOf("") }

    fun newAgent() {
        editing = null
        name = ""
        address = ""
        lat = ""
        lon = ""
        showEditor = true
    }
    fun editAgent(a: Agent) {
        editing = a
        name = a.name
        address = a.address
        lat = a.latitude?.toString() ?: ""
        lon = a.longitude?.toString() ?: ""
        showEditor = true
    }

    if (showEditor) {
        AlertDialog(
            onDismissRequest = { showEditor = false },
            title = { Text(if (editing == null) "New Agent / Partner" else "Edit Agent / Partner") },
            text = {
                Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text("Agent name") }, placeholder = { Text("e.g. AAGENCY079") })
                    OutlinedTextField(address, { address = it }, Modifier.fillMaxWidth(), label = { Text("Address") }, placeholder = { Text("e.g. Ayetoro, Ijebu North, Ogun State") }, minLines = 2)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(lat, { lat = it }, Modifier.weight(1f), label = { Text("Latitude") }, placeholder = { Text("e.g. 6.9018") })
                        OutlinedTextField(lon, { lon = it }, Modifier.weight(1f), label = { Text("Longitude") }, placeholder = { Text("e.g. 3.3154") })
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        DevMonitorOutlinedButton(onClick = {
                            val p = onGetLocation()
                            if (p != null) { lat = p.first.toString(); lon = p.second.toString() }
                        }) { Text("Present location") }
                        DevMonitorOutlinedButton(onClick = { onOpenMaps(lat.toDoubleOrNull(), lon.toDoubleOrNull()) }) { Text("Google Maps") }
                    }
                    Text("For a map point, open Google Maps, select/copy the coordinates, then enter them above.", style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (name.isNotBlank()) {
                        val id = store.saveAgent(Agent(editing?.id ?: 0L, name, address, lat.toDoubleOrNull(), lon.toDoubleOrNull(), editing?.createdAt ?: System.currentTimeMillis(), System.currentTimeMillis()))
                        selectedAgent = store.agents().firstOrNull { it.id == id }
                        agents = store.agents(search)
                        showEditor = false
                    }
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showEditor = false }) { Text("Cancel") } }
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Agent / Partner Database") },
        text = {
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(search, { search = it; agents = store.agents(it) }, Modifier.fillMaxWidth(), label = { Text("Search agent") }, placeholder = { Text("e.g. Sunnetik") }, singleLine = true)
                DevMonitorButton(onClick = { newAgent() }, Modifier.fillMaxWidth()) { Text("Add agent / partner") }
                LazyColumn(Modifier.heightIn(max = 360.dp)) {
                    items(agents, key = { it.id }) { a ->
                        Card(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                            Column(Modifier.padding(8.dp)) {
                                Text(a.name, fontWeight = FontWeight.Bold)
                                if (a.address.isNotBlank()) Text(a.address)
                                Text("Location: ${a.latitude ?: "-"}, ${a.longitude ?: "-"}")
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    TextButton(onClick = { editAgent(a) }) { Text("Edit") }
                                    TextButton(onClick = { onPickContact(a.id) }) { Text("Add phone") }
                                    TextButton(onClick = { selectedAgent = a }) { Text("Phones / Codes") }
                                    TextButton(onClick = { store.deleteAgent(a.id); agents = store.agents(search); if(selectedAgent?.id==a.id) selectedAgent=null }) { Text("Delete") }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )

    selectedAgent?.let { a ->
        val phones = store.phonesForAgent(a.id)
        AlertDialog(
            onDismissRequest = { selectedAgent = null },
            title = { Text(a.name) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Phone numbers", fontWeight = FontWeight.Bold)
                    phones.forEach { p ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${p.phone} ${p.label}")
                            TextButton(onClick = { store.deleteAgentPhone(p.id); selectedAgent = a.copy() }) { Text("Remove") }
                        }
                    }
                    DevMonitorOutlinedButton(onClick = { onPickContact(a.id) }) { Text("Link phone from contacts") }
                    OutlinedTextField(linkCode, { linkCode = it }, Modifier.fillMaxWidth(), label = { Text("Link device/partner code") }, placeholder = { Text("e.g. GLO-DD-OGN-ABE-OGU0035-138K") })
                    DevMonitorButton(onClick = { if(linkCode.isNotBlank()){store.linkDeviceToAgent(a.id,linkCode.trim().uppercase());linkCode=""} }) { Text("Link code") }
                }
            },
            confirmButton = { TextButton(onClick = { selectedAgent=null }) { Text("Close") } }
        )
    }
}

@Composable
fun DevicePaymentCardScreen(
    row: SimRegReportRow?,
    localRecord: QueryRecord?,
    reportIsActivation: Boolean,
    reportMonth: YearMonth? = null,
    reportCutoffDay: Int? = null,
    companyActivations: CompanyActivationStore? = null,
    myDevicesStore: MyDevicesStore? = null,
    deviceMonitorStore: DatabaseStore? = null,
    deviceMonitorMode: Boolean = false,
    showBothSources: Boolean = false,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val codeForPayment = row?.deviceId ?: localRecord?.code
    var companyCycleTotal by remember(codeForPayment) { mutableStateOf<Int?>(null) }
    var companyCycleContributions by remember(codeForPayment) { mutableStateOf<List<CompanyActivationStore.CycleContribution>>(emptyList()) }
    var companySundayTotal by remember(codeForPayment) { mutableIntStateOf(0) }
    var paymentCycleResolution by remember(codeForPayment) { mutableStateOf<PaymentEngine.Progression?>(null) }

    LaunchedEffect(codeForPayment, companyActivations, deviceMonitorMode, showBothSources) {
        if (codeForPayment == null || companyActivations == null) return@LaunchedEffect
        withContext(Dispatchers.IO) {
            val loaded = PaymentEngine.LoadedReports.calculate(
                deviceId = codeForPayment,
                asOfRequested = PaymentRules.currentAwareDate(),
                companyStore = companyActivations
            )
            val monitor = if ((deviceMonitorMode || showBothSources) && deviceMonitorStore != null) {
                PaymentEngine.DeviceMonitor.calculate(
                    deviceId = codeForPayment,
                    asOfRequested = PaymentRules.currentAwareDate(),
                    deviceStore = deviceMonitorStore,
                    companyStore = companyActivations
                )
            } else null
            withContext(Dispatchers.Main.immediate) {
                companyCycleTotal = loaded.activations
                companySundayTotal = companyActivations.cycleSundayActivations(codeForPayment)
                companyCycleContributions = companyActivations.cycleContributions(codeForPayment)
                paymentCycleResolution = monitor
            }
        }
    }

    val liveDate = PaymentRules.currentAwareDate()
    val livePaymentCycle = PaymentRules.paymentCycleForDate(liveDate)

    // Device Monitor payment progression is reconstructed by calendar-month segment.
    // Loaded Reports seed historical dates; SMS Active snapshots override those dates
    // once available and are converted from month-to-date cumulative values into
    // payment-cycle contributions. Future report dates never participate.
    val resolvedCycle = paymentCycleResolution
    val livePaymentCycleTotal = if (deviceMonitorMode || showBothSources) resolvedCycle?.activations else null
    val deviceMonitorEstimate = resolvedCycle?.estimate
    val loadedReportEstimate = companyCycleTotal?.let { PaymentRules.estimate(it, companySundayTotal) }
    val deviceMonitorAvailable = deviceMonitorEstimate != null
    val loadedReportAvailable = loadedReportEstimate != null

    val partner = row?.partnerName.orEmpty().ifBlank { "-" }
    val trade = row?.tradeCode.orEmpty().ifBlank { "-" }
    val staff = row?.staffName.orEmpty().ifBlank { "-" }
    val territory = row?.territory.orEmpty().ifBlank { "-" }
    val region = row?.region.orEmpty().ifBlank { "-" }
    val cluster = row?.cluster.orEmpty().ifBlank { "-" }
    val code = row?.deviceId ?: localRecord?.code ?: "-"

    @Composable
    fun EstimateBlock(
        title: String,
        source: String,
        estimate: IncentiveEstimate,
        showSunday: Boolean,
        monitorSource: Boolean
    ) {
        AuroraGlassCard(Modifier.fillMaxWidth(), if (monitorSource) AuroraBlue else AuroraCyan) {
            Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                Text("Evidence source: $source", style = MaterialTheme.typography.bodySmall)
                Text("Current Activation Achieved: ${estimate.activations}", fontWeight = FontWeight.Bold)
                if (!monitorSource) {
                    val liveDate = PaymentRules.currentAwareDate()
                    Text("Payment cycle: ${PaymentRules.paymentCycleLabel(liveDate)}", fontWeight = FontWeight.Bold)
                    Text("Progression as of: $liveDate (future-dated report rows are ignored)", style = MaterialTheme.typography.bodySmall)
                }
                val currentTier = when {
                    estimate.activations >= 300 -> "300+ activation tier"
                    estimate.activations >= 250 -> "250 activation tier"
                    estimate.activations >= 200 -> "200 activation tier"
                    estimate.activations >= 150 -> "150 activation tier"
                    estimate.activations >= 100 -> "100 activation tier"
                    estimate.activations >= 70 -> "70 activation tier"
                    estimate.activations >= 50 -> "50 activation tier"
                    estimate.activations >= 30 -> "30 activation tier"
                    else -> "Below 30 activation tier"
                }
                Text("Current payment category: $currentTier")
                Text("Fixed performance reward: ₦${estimate.fixedReward.formatNaira()}")
                Text("Estimated FRC component (₦250 × activations): ₦${estimate.estimatedRechargeBonus.formatNaira()}")
                if (monitorSource) {
                    val liveDate = PaymentRules.currentAwareDate()
                    Text("Device Monitor as of: $liveDate", fontWeight = FontWeight.Bold)
                    Text("Payment cycle: ${PaymentRules.paymentCycleLabel(liveDate)}", fontWeight = FontWeight.Bold)
                    Text("Current payment-cycle activations: ${livePaymentCycleTotal ?: 0}", fontWeight = FontWeight.Bold)
                    if (resolvedCycle != null) {
                        Text("Data available from: ${resolvedCycle.availableThrough ?: "not established"}", style = MaterialTheme.typography.bodySmall)
                        Text(
                            if (resolvedCycle.complete) "Cycle coverage is complete through today."
                            else resolvedCycle.warning ?: "Cycle coverage is incomplete; missing dates are not invented.",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text("Sources: ${resolvedCycle.source.ifBlank { "none" }}", style = MaterialTheme.typography.bodySmall)
                    }
                    resolvedCycle?.warning?.let { warning ->
                        Text(warning, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                    }
                }
                if (showSunday && estimate.sundayBonus > 0) {
                    Text("Sunday bonus: ₦${estimate.sundayBonus.formatNaira()} (${estimate.sundayActivations} qualifying Sunday activations)", fontWeight = FontWeight.Bold)
                } else if (showSunday) {
                    Text("Sunday bonus: ₦0 (each Sunday must reach ${PaymentRules.SUNDAY_MIN_ACTIVATIONS}+ qualifying activations)")
                }
                Text("Estimated total: ₦${estimate.estimatedSubtotal.formatNaira()}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                if (estimate.nextThreshold != null) {
                    LinearProgressIndicator(
                        progress = { (estimate.activations.toFloat() / estimate.nextThreshold!!.toFloat()).coerceIn(0f, 1f) },
                        Modifier.fillMaxWidth()
                    )
                    Text("${estimate.activationsToNext} more activation${if (estimate.activationsToNext == 1) "" else "s"} to ${estimate.nextThreshold} → ₦${estimate.nextReward?.formatNaira() ?: "-"}")
                    Text("Do more. Reach the next level. Earn better.", fontWeight = FontWeight.Bold)
                } else {
                    Text("You've reached the highest currently configured fixed-reward tier. Keep the momentum going.", fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack) { Text("‹ Back") }
            Text("Device Payment", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
        }
        HorizontalDivider()
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(start = 16.dp, top = 16.dp, end = 16.dp, bottom = 180.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                AuroraGlassCard(Modifier.fillMaxWidth(), AuroraBlue) {
                    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text("DEVICE PAYMENT CARD", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.ExtraBold)
                        Text(code, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                        Text("Payment progression and earnings estimate", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
            item {
                AuroraGlassCard(Modifier.fillMaxWidth(), AuroraCyan) {
                    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text("Device details", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("Partner: $partner")
                        Text("Partner / Trade code: $trade")
                        Text("Agent / Staff: $staff")
                        Text("Territory: $territory")
                        Text("Region: $region")
                        Text("Cluster: $cluster")
                    }
                }
            }

            if (showBothSources) {
                if (deviceMonitorAvailable) {
                    item {
                        EstimateBlock(
                            title = "DEVICE MONITOR PAYMENT ESTIMATE",
                            source = resolvedCycle?.source?.ifBlank { "Current payment-cycle sources" } ?: "Current payment-cycle sources",
                            estimate = deviceMonitorEstimate!!,
                            showSunday = false,
                            monitorSource = true
                        )
                    }
                }
                if (loadedReportAvailable) {
                    item {
                        EstimateBlock(
                            title = "LOADED REPORT PAYMENT ESTIMATE",
                            source = "Normalized Loaded Reports — current 21st–20th payment cycle",
                            estimate = loadedReportEstimate!!,
                            showSunday = true,
                            monitorSource = false
                        )
                    }
                    if (companyCycleContributions.isNotEmpty()) {
                        item {
                            AuroraGlassCard(Modifier.fillMaxWidth(), AuroraCyan) {
                                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                    Text("Loaded report contributions", fontWeight = FontWeight.Bold)
                                    companyCycleContributions.forEach { part ->
                                        val range = listOfNotNull(part.coverageStart, part.coverageEnd).joinToString(" → ")
                                        Text("${part.sourceName}${if (range.isNotBlank()) " ($range)" else ""}: ${part.activationCount} activations")
                                    }
                                }
                            }
                        }
                    }
                }
                if (!deviceMonitorAvailable && !loadedReportAvailable) {
                    item {
                        AuroraGlassCard(Modifier.fillMaxWidth(), AuroraViolet) {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("No payment result available yet", fontWeight = FontWeight.ExtraBold)
                                Text("This device has no usable Device Monitor or Loaded Reports activation evidence yet.")
                            }
                        }
                    }
                }
            } else if (deviceMonitorMode) {
                item {
                    if (deviceMonitorEstimate != null) {
                        EstimateBlock(
                            title = "DEVICE MONITOR PAYMENT ESTIMATE",
                            source = when {
                                resolvedCycle?.source?.contains("Device Monitor Active") == true -> "Device Monitor: current payment-cycle SMS"
                                else -> "Device Monitor: current payment-cycle Loaded Reports"
                            },
                            estimate = deviceMonitorEstimate,
                            showSunday = false,
                            monitorSource = true
                        )
                    } else {
                        AuroraGlassCard(Modifier.fillMaxWidth(), AuroraCyan) {
                            Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                Text("CURRENT PAYMENT PROGRESSION", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                                Text("No Device Monitor activation figure is available for this device yet.")
                                Text("Keep monitoring the device; an estimate will appear when activation evidence becomes available.")
                            }
                        }
                    }
                }
            } else {
                item {
                    if (loadedReportEstimate != null) {
                        EstimateBlock(
                            title = "LOADED REPORT PAYMENT ESTIMATE",
                            source = "HQ Activation report / normalized Loaded Reports",
                            estimate = loadedReportEstimate,
                            showSunday = true,
                            monitorSource = false
                        )
                    } else if (row != null && !reportIsActivation) {
                        AuroraGlassCard(Modifier.fillMaxWidth(), AuroraCyan) {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("CURRENT PAYMENT PROGRESSION", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                                Text("This HQ report is a SIM Reg/registration report. Registration totals are not converted into activation payout estimates.", fontWeight = FontWeight.Bold)
                                Text("Use Device Monitor or an HQ Activations report when activation evidence is available.")
                            }
                        }
                    } else {
                        AuroraGlassCard(Modifier.fillMaxWidth(), AuroraCyan) {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("CURRENT PAYMENT PROGRESSION", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                                Text("No activation figure is available for this device yet.")
                            }
                        }
                    }
                }
            }

            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("⚠ PAYMENT / INCENTIVE WARNING", fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.error)
                        Text("DevMonitor figures are for monitoring / estimation only. Company official data remains final.", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

private fun Int.formatNaira(): String = "%d".format(java.util.Locale.US, this)

@Composable
fun PaymentLandingScreen(
    report: SimRegReport?,
    localRecords: Map<String, QueryRecord>,
    agents: List<Agent>,
    companyActivations: CompanyActivationStore? = null,
    myDevicesStore: MyDevicesStore? = null,
    deviceMonitorStore: DatabaseStore? = null
) {
    val context = LocalContext.current
    var mode by remember { mutableStateOf<String?>(null) }
    var query by remember { mutableStateOf("") }
    var selectedCode by remember { mutableStateOf<String?>(null) }
    var selectedPartner by remember { mutableStateOf<String?>(null) }

    val normalizedQuery = query.trim().uppercase()
    val activationReport = report?.takeIf { it.isActivationReport }
    val hqRows = report?.rows.orEmpty()
    val localByCode = remember(localRecords) { localRecords.values.associateBy { canonicalDeviceCode(it.code) } }
    val hqByCode = remember(hqRows) { hqRows.associateBy { canonicalDeviceCode(it.deviceId) } }

    if (selectedCode != null) {
        val code = selectedCode!!
        DevicePaymentCardScreen(
            row = hqByCode[canonicalDeviceCode(code)],
            localRecord = localByCode[canonicalDeviceCode(code)],
            reportIsActivation = activationReport != null,
            reportMonth = activationReport?.coverageEnd?.let(YearMonth::from),
            reportCutoffDay = activationReport?.cutoffDay,
            companyActivations = companyActivations,
            myDevicesStore = myDevicesStore,
            deviceMonitorStore = deviceMonitorStore,
            deviceMonitorMode = false,
            showBothSources = true,
            onBack = { selectedCode = null }
        )
        return
    }

    if (selectedPartner != null) {
        val partnerKey = selectedPartner!!
        val partnerRows = hqRows.filter {
            it.partnerName.equals(partnerKey, ignoreCase = true) || it.tradeCode.equals(partnerKey, ignoreCase = true)
        }
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { selectedPartner = null }) { Text("‹ Back") }
                Text("Partner Overview", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
            }
            HorizontalDivider()
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text(partnerKey, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                            Text("${partnerRows.size} device${if (partnerRows.size == 1) "" else "s"} found")
                            Text("Tap a device to open its full payment card.")
                        }
                    }
                }
                items(partnerRows, key = { canonicalDeviceCode(it.deviceId) }) { row ->
                    val local = localByCode[canonicalDeviceCode(row.deviceId)]
                    val count = when {
                        local?.result?.active != null -> local.result.active ?: 0
                        activationReport != null -> row.mtd(activationReport.cutoffDay)
                        else -> null
                    }
                    val sundayActivations = activationReport?.coverageEnd?.let { PaymentRules.qualifyingSundayActivations(row.daily, YearMonth.from(it), activationReport.cutoffDay) } ?: 0
                    val estimate = count?.let { PaymentRules.estimate(it, sundayActivations) }
                    Card(Modifier.fillMaxWidth().clickable { selectedCode = row.deviceId }) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(row.deviceId, fontWeight = FontWeight.ExtraBold)
                            Text("Agent: ${row.staffName.ifBlank { "-" }}")
                            Text("Activations: ${count ?: "-"} • Category: ${estimate?.let { when { it.activations >= 300 -> "300+"; it.activations >= 250 -> "250"; it.activations >= 200 -> "200"; it.activations >= 150 -> "150"; it.activations >= 100 -> "100"; it.activations >= 70 -> "70"; it.activations >= 50 -> "50"; it.activations >= 30 -> "30"; else -> "<30" } } ?: "-"}")
                            if (estimate != null) Text("Estimated: ₦${estimate.estimatedSubtotal.formatNaira()}")
                            if (estimate?.nextThreshold != null) Text("${estimate.activationsToNext} more to ${estimate.nextThreshold}. Do more. Reach the next level. Earn better.", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
        return
    }

    Column(Modifier.fillMaxSize()) {
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, top = 12.dp, end = 16.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                AuroraGlassCard(Modifier.fillMaxWidth(), AuroraViolet) {
                    Text("PAYMENT INTELLIGENCE", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.secondary)
                    Spacer(Modifier.height(4.dp))
                    Text("Payment intelligence", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
                    Text("View estimated agent, device and partner payment based on the available HQ/SIMReg data.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(10.dp))
                    Text("No partner authorization is required to view payment calculations. Confidential partner incentive rates are not displayed.", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                }
            }
            item {
                AuroraGlassCard(Modifier.fillMaxWidth(), AuroraBlue) {
                    Text("PAYMENT SEARCH", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.height(6.dp))
                    Text("Search the available HQ/SIMReg and Device Monitor data.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(mode == "AGENT", onClick = { mode = "AGENT"; query = "" }, label = { Text("AGENT / DEVICE TAG") }, modifier = Modifier.weight(1f))
                        FilterChip(mode == "PARTNER", onClick = { mode = "PARTNER"; query = "" }, label = { Text("PARTNER") }, modifier = Modifier.weight(1f))
                    }
                    if (mode != null) {
                        Spacer(Modifier.height(10.dp))
                        OutlinedTextField(
                            value = query,
                            onValueChange = { query = it },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            label = { Text(if (mode == "AGENT") "Device Tag / Device ID" else "Partner name / Partner code") },
                            placeholder = { Text(if (mode == "AGENT") "e.g. GLO-GD-235N" else "e.g. partner name or code") }
                        )
                    }
                }
            }
            if (mode == "AGENT" && normalizedQuery.isNotBlank()) {
                val matches = buildList {
                    hqRows.filter { canonicalDeviceCode(it.deviceId).contains(normalizedQuery) || it.deviceId.uppercase().contains(normalizedQuery) || it.partnerName.uppercase().contains(normalizedQuery) || it.staffName.uppercase().contains(normalizedQuery) }.forEach { add(canonicalDeviceCode(it.deviceId)) }
                    localRecords.keys.filter { canonicalDeviceCode(it).contains(normalizedQuery) }.forEach { add(canonicalDeviceCode(it)) }
                }.distinct().take(100)
                if (matches.isEmpty()) item {
                    DevMonitorEmptyState(
                        title = "No matching device",
                        message = "No device was found in the available HQ Activation/SIMReg and Device Monitor data."
                    )
                }
                items(matches, key = { it }) { code ->
                    AuroraGlassCard(Modifier.fillMaxWidth().clickable { selectedCode = code }, AuroraBlue) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(code, fontWeight = FontWeight.ExtraBold)
                            val row = hqByCode[code]
                            Text("${row?.partnerName?.ifBlank { "Partner not available" } ?: "Partner not available"} • ${row?.staffName?.ifBlank { "Agent not available" } ?: "Agent not available"}")
                            Text("Tap to view payment card", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            if (mode == "PARTNER" && normalizedQuery.isNotBlank()) {
                val matches = buildList {
                    hqRows.filter { it.partnerName.uppercase().contains(normalizedQuery) || it.tradeCode.uppercase().contains(normalizedQuery) }.mapNotNull { it.partnerName.ifBlank { it.tradeCode.ifBlank { null } } }.forEach { add(it) }
                    agents.filter { it.name.uppercase().contains(normalizedQuery) }.forEach { add(it.name) }
                }.distinct().take(50)
                if (matches.isEmpty()) item {
                    DevMonitorEmptyState(
                        title = "No matching partner",
                        message = "No partner was found in the available data. Check the name or trade code and try again."
                    )
                }
                items(matches, key = { it }) { partner ->
                    AuroraGlassCard(Modifier.fillMaxWidth().clickable { selectedPartner = partner }, AuroraViolet) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(partner, fontWeight = FontWeight.ExtraBold)
                            Text("Tap to view all matching devices and payment progression.", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            item {
                AuroraGlassCard(Modifier.fillMaxWidth(), AuroraViolet) {
                    Column(Modifier.padding(0.dp)) {
                        Image(
                            painter = painterResource(com.aziitech.simregmonitor.R.drawable.payment_structure),
                            contentDescription = "Company payment structure",
                            modifier = Modifier.fillMaxWidth(),
                            contentScale = ContentScale.FillWidth
                        )
                    }
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("⚠ PAYMENT / INCENTIVE WARNING", fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.error)
                        Text("DevMonitor figures are for monitoring / estimation only. Company official data remains final.", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun PaymentTrackingDialog(store: DatabaseStore, onDismiss: () -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Payment Tracking") }, text = { Text("Payment tracking is now available from the full Payments page.") }, confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } })
}
