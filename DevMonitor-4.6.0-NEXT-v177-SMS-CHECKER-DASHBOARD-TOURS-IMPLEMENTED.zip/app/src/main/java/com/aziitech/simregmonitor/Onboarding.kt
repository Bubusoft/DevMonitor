package com.aziitech.simregmonitor

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import android.net.Uri
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalDensity

@Composable
fun WelcomeWizard(
    guided: Boolean,
    onClose: () -> Unit,
    onStartGuidedTour: () -> Unit = {},
    onBuildProfile: () -> Unit = {},
    onNavigate: (Int) -> Unit
) {
    var page by remember { mutableIntStateOf(0) }
    val pages = listOf(
        Triple("Welcome to DevMonitor", "SMS automation, monitoring and reporting — designed to turn routine queries into useful operational insight.", "Explore first whenever you like. The tour is optional."),
        Triple("1 • Run your device checks", "Load your device or partner codes, select the SIM that should send SMS, choose your destination and run the batch.", "Tip: paste one code per line, or import an Excel file."),
        Triple("2 • Watch the Flags Centre", "Company-owned devices receive priority. The app highlights persistent low sales, four consecutive zero-sales days, Conversion Lost and unusual behaviour.", "Open Flags Centre from the flag icon at the top."),
        Triple("3 • Keep your operational database", "Maintain agents and partners, multiple phone numbers, locations, linked device codes and the separate 21st–20th payment record.", "You can change the payment calendar later."),
        Triple("4 • Reports, Earning Progress & history", "Review HQ company reports, Month-on-Month performance and the 21st–20th earning cycle without mixing those data pathways.", "Heavy calculations remain user-triggered to keep the phone responsive."),
        Triple("5 • Start with your profile", "Build your My Devices scope from the Company Skeleton first. You can load company activation data later when you need performance details.", "Your profile determines the primary scope used by DevMonitor."),
    )
    val p = pages[page]

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            Modifier.fillMaxSize().padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = onClose) { Text("Explore First") }
            }
            Spacer(Modifier.height(4.dp))
            Image(
                painter = painterResource(R.drawable.busayo_photo_1),
                contentDescription = "Busayo avatar",
                modifier = Modifier.size(width = if (guided) 150.dp else 170.dp, height = if (guided) 190.dp else 215.dp).clip(RoundedCornerShape(28.dp)),
                contentScale = ContentScale.Fit
            )
            Spacer(Modifier.height(16.dp))
            Column(
                Modifier
                    .fillMaxWidth()
                    .weight(1f, fill = true)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Card(
                    Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(28.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(if (page == 0) "Hello! I'm Busayo 👋" else "Let's take a quick look", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                        Text(p.first, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text(p.second, style = MaterialTheme.typography.bodyLarge)
                        Text(p.third, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = .78f))
                    }
                }
                Spacer(Modifier.height(18.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    pages.indices.forEach { i ->
                        Box(Modifier.size(if (i == page) 24.dp else 8.dp, 8.dp).clip(RoundedCornerShape(50)).background(if (i == page) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant))
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            if (page == 0 && !guided) {
                DevMonitorButton(onClick = { page++ }, Modifier.fillMaxWidth().height(52.dp)) { Text("Next") }
                Spacer(Modifier.height(8.dp))
                DevMonitorOutlinedButton(onClick = onClose, Modifier.fillMaxWidth().height(52.dp)) { Text("Explore First") }
            } else {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (page > 0) DevMonitorOutlinedButton(onClick = { page-- }, Modifier.weight(1f)) { Text("Back") }
                    if (page < pages.lastIndex) {
                        DevMonitorButton(onClick = { page++ }, Modifier.weight(1f)) { Text("Next") }
                    } else {
                        DevMonitorButton(onClick = { onClose(); onBuildProfile() }, Modifier.weight(1f)) { Text("BUILD PROFILE") }
                    }
                }
                if (page in 1..4) {
                    Spacer(Modifier.height(8.dp))
                    val target = page - 1
                    val label = listOf("Open Device Monitor", "Open Flags Centre", "Open Agents", "Open Reports / Dashboard")[target]
                    TextButton(onClick = { onNavigate(target); onClose() }) { Text(label) }
                }
            }
        }
    }
}

@Composable
fun AboutBusayoDialog(
    adsRemoved: Boolean,
    onPremium: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("About") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Image(painterResource(R.drawable.busayo_photo_1), "Busayo avatar", Modifier.size(width = 120.dp, height = 150.dp).clip(RoundedCornerShape(22.dp)), contentScale = ContentScale.Fit)
                Text("OLUWABUSAYO ISAIAH OYEGUNWA", fontWeight = FontWeight.ExtraBold)
                Text("isaiahoyegun@gmail.com")
                Text("BUSINESS DEVELOPMENT EXECUTIVE")
                Text("08055576433, 08130445047")
                if (BuildConfig.MONETIZED_BUILD) {
                    DevMonitorButton(onClick = onPremium, Modifier.fillMaxWidth()) {
                        Text(if (adsRemoved) "Premium Active" else "⭐ Go Premium — Remove Ads")
                    }
                    Text(
                        if (adsRemoved) "Your Premium subscription is active."
                        else "Remove ads and unlock unlimited exports.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        },
        confirmButton = { DevMonitorButton(onClick = onDismiss) { Text("Close") } }
    )
}


@Composable
fun InteractiveGuidedTourOverlay(
    stage: Int,
    targets: Map<String, Rect>,
    reportOpen: Boolean,
    lastExportUri: Uri?,
    onStart: () -> Unit,
    onContinue: () -> Unit,
    onSkip: () -> Unit,
    onFinish: () -> Unit,
    onOpenExportedFile: (Uri) -> Unit
) {
    if (stage == 51 || reportOpen) return

    val targetKey = when (stage) {
        1 -> "device_monitor"
        20 -> "select_sim"
        2 -> "code_input"
        21 -> "add_list"
        3 -> "start_sms"
        4 -> "progress"
        5 -> "summary"
        6 -> "export_excel"
        8 -> "save_list"
        9 -> "saved"
        else -> null
    }
    val target = targetKey?.let { targets[it] }
    val title: String
    val body: String
    val step: String

    when (stage) {
        0 -> {
            title = "Welcome to your first operation"
            body = "I'll guide you through a real operation: open Device Monitor, enter your codes, send the SMS queries, review the report, export it to Excel, and then show you how to save the code list for reuse."
            step = "Guided tour"
        }
        1 -> {
            title = "Open Device Monitor"
            body = "This is where your device and partner codes are entered and where SMS operations are run. Tap the highlighted Open Device Monitor button."
            step = "Step 1 of 9"
        }
        20 -> {
            title = "Select the SIM for SMS"
            body = "If your phone has more than one SIM, select the default/preferred SIM that DevMonitor should use to send the SMS queries. The phone's default SMS SIM is preselected when available. Tap the highlighted Select SIM button, then choose the SIM."
            step = "Step 2 of 9"
        }
        2 -> {
            title = "Enter your codes"
            body = "Paste or type your Device/Partner codes here. One code per line is recommended, but comma-, tab-, semicolon-separated and multi-line pasted lists are also accepted. Example short code: GLO-GD-255D. DevMonitor removes duplicates and uses only the Device short code for SMS queries."
            step = "Step 3 of 9"
        }
        21 -> {
            title = "Add the code list"
            body = "Tap Add list to load the codes into this operation."
            step = "Step 4 of 9"
        }
        3 -> {
            title = "Start sending SMS"
            body = "When the SMS permission is ready, tap the highlighted Start Sending SMS button. The tour will wait for the real operation to begin."
            step = "Step 5 of 9"
        }
        4 -> {
            title = "Monitor the operation"
            body = "The batch is now running. Watch the progress, sent count and results. When the operation finishes, the report button will be highlighted."
            step = "Step 6 of 9"
        }
        5 -> {
            title = "Review the report"
            body = "Tap Summary to view the daily and monthly report, including totals, active devices, Bar 48/96 and flags."
            step = "Step 7 of 9"
        }
        6 -> {
            title = "Export to Excel"
            body = "Your report is ready. Tap Export Excel and choose where to save the workbook. The tour will continue after the file is successfully created."
            step = "Step 8 of 9"
        }
        7 -> {
            title = "First operation complete! 🎉"
            body = "You've completed the full workflow: sent the SMS queries, monitored the operation, reviewed the report and exported the results to Excel."
            step = "Step 9 of 9"
        }
        8 -> {
            title = "Save your code list"
            body = "You can save this list so you don't have to paste the same codes again. This button opens the save dialog."
            step = "Quick tip"
        }
        9 -> {
            title = "Find saved lists later"
            body = "Saved lists can be opened again from here. That's all for the guided tour."
            step = "Quick tip"
        }
        else -> return
    }

    androidx.compose.foundation.layout.BoxWithConstraints(Modifier.fillMaxSize()) {
        val highlightColor = MaterialTheme.colorScheme.primary
        val pulse = rememberInfiniteTransition(label = "tour_pulse")
            .animateFloat(
                initialValue = 0.78f,
                targetValue = 1.18f,
                animationSpec = infiniteRepeatable(
                    animation = tween(durationMillis = 750),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "tour_pulse_scale"
            ).value

        androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
            val scrim = Color.Black.copy(alpha = 0.62f)
            val holes = buildList {
                target?.let { add(it) }
                // Once the user starts typing, keep the real input field visually
                // active while the Add list button becomes the next animated target.
                if (stage == 21) {
                    targets["code_input"]?.let { inputTarget ->
                        if (target == null || inputTarget != target) add(inputTarget)
                    }
                }
            }

            if (holes.isEmpty()) {
                drawRect(scrim)
            } else {
                // Keep the active controls uncovered. Stage 21 intentionally has
                // two holes: the input remains foreground while Add list is next.
                var cursorY = 0f
                val sortedHoles = holes.sortedBy { it.top }
                sortedHoles.forEach { hole ->
                    if (hole.top > cursorY) {
                        drawRect(
                            scrim,
                            topLeft = androidx.compose.ui.geometry.Offset(0f, cursorY),
                            size = androidx.compose.ui.geometry.Size(size.width, hole.top - cursorY)
                        )
                    }
                    if (hole.left > 0f) {
                        drawRect(
                            scrim,
                            topLeft = androidx.compose.ui.geometry.Offset(0f, hole.top),
                            size = androidx.compose.ui.geometry.Size(hole.left, hole.height)
                        )
                    }
                    if (hole.right < size.width) {
                        drawRect(
                            scrim,
                            topLeft = androidx.compose.ui.geometry.Offset(hole.right, hole.top),
                            size = androidx.compose.ui.geometry.Size(size.width - hole.right, hole.height)
                        )
                    }
                    cursorY = maxOf(cursorY, hole.bottom)
                }
                if (cursorY < size.height) {
                    drawRect(
                        scrim,
                        topLeft = androidx.compose.ui.geometry.Offset(0f, cursorY),
                        size = androidx.compose.ui.geometry.Size(size.width, size.height - cursorY)
                    )
                }
            }

            // The current target gently pulses so the user can immediately see
            // what to tap next. During stage 21 this specifically animates Add list.
            target?.let { t ->
                val extra = 3f + (pulse - 0.78f) * 5f
                drawRoundRect(
                    color = highlightColor.copy(alpha = 0.72f + (pulse - 0.78f) * 0.22f),
                    topLeft = androidx.compose.ui.geometry.Offset(t.left - extra, t.top - extra),
                    size = androidx.compose.ui.geometry.Size(t.width + extra * 2f, t.height + extra * 2f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(14f, 14f),
                    style = androidx.compose.ui.graphics.drawscope.Stroke(width = 5f)
                )
            }
        }

        // Place the instruction card on the opposite side of the highlighted control.
        // This is target-aware so the explanation can never sit over the live button the
        // user is being asked to tap. If the target is in the lower half, the card goes
        // to the top; if it is in the upper half, it goes to the bottom.
        val maxHeightPx = with(LocalDensity.current) { maxHeight.toPx() }
        val placeAtTop = target == null || target.center.y > maxHeightPx / 2f
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .align(if (placeAtTop) Alignment.TopCenter else Alignment.BottomCenter),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                Text(step, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                Text(body, style = MaterialTheme.typography.bodyLarge)

                when (stage) {
                    0 -> {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            DevMonitorOutlinedButton(onClick = onSkip, Modifier.weight(1f)) { Text("Skip") }
                            DevMonitorButton(onClick = onStart, Modifier.weight(1f)) { Text("Start Tour") }
                        }
                    }
                    7 -> {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (lastExportUri != null) {
                                DevMonitorOutlinedButton(
                                    onClick = { onOpenExportedFile(lastExportUri) },
                                    Modifier.weight(1f)
                                ) { Text("Open Excel") }
                            }
                            DevMonitorButton(onClick = onContinue, Modifier.weight(1f)) { Text("Continue") }
                        }
                    }
                    8, 9 -> {
                        TextButton(onClick = onFinish, Modifier.align(Alignment.End)) { Text("Finish") }
                    }
                    else -> {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Tap the highlighted control to continue.", style = MaterialTheme.typography.bodySmall)
                            TextButton(onClick = onSkip) { Text("Skip") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BuildProfileSpotlight(
    onBuildProfile: () -> Unit,
    onSkip: () -> Unit
) {
    Surface(
        Modifier.fillMaxSize().background(Color.Black.copy(alpha = .58f)),
        color = Color.Transparent
    ) {
        Column(
            Modifier.fillMaxSize().padding(horizontal = 22.dp, vertical = 110.dp),
            verticalArrangement = Arrangement.Top
        ) {
            Card(
                Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 12.dp)
            ) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("START HERE", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                    Text("Build your profile", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
                    Text("DevMonitor can identify your devices from the built-in Company Skeleton before you load activation data. Start by building your profile.")
                    DevMonitorButton(onClick = onBuildProfile, Modifier.fillMaxWidth()) { Text("BUILD PROFILE") }
                    TextButton(onClick = onSkip, Modifier.align(Alignment.End)) { Text("Skip") }
                }
            }
        }
    }
}

@Composable
fun DashboardGuidedTourOverlay(
    stage: Int,
    targets: Map<String, Rect>,
    onAdvance: () -> Unit,
    onSkip: () -> Unit,
    onFinish: () -> Unit
) {
    val steps = listOf(
        Triple("hero", "Today's Operations", "This is your quick operational snapshot. It shows today's registrations and the number of devices currently in your monitoring scope."),
        Triple("profile", "Your Profile", "This is the identity and device scope DevMonitor uses to focus your reports, My Devices and performance information."),
        Triple("sms", "SMS CHECKER", "Use SMS CHECKER to query device or partner codes and monitor their current standing."),
        Triple("my_devices", "MY DEVICES", "This is your saved device workspace. It keeps your profile scope together so you can return to your own devices quickly."),
        Triple("load_report", "LOAD REPORT", "Use this to import and review an authoritative company report. Importing does not automatically run heavy downstream calculations."),
        Triple("earning", "EARNING PROGRESS", "This is where you track progress through the established payment cycle and earning progression."),
        Triple("payment", "PAYMENT CYCLE", "This card gives you a quick view of the current payment-cycle evidence. Refresh it when you want the latest calculation."),
    )
    if (stage !in steps.indices) return
    val (key, title, body) = steps[stage]
    val target = targets[key]
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val maxHeightPx = with(LocalDensity.current) { maxHeight.toPx() }
        val pulse = rememberInfiniteTransition(label = "dashboard_tour_pulse")
            .animateFloat(
                initialValue = 0.82f,
                targetValue = 1.12f,
                animationSpec = infiniteRepeatable(tween(800), RepeatMode.Reverse),
                label = "dashboard_tour_pulse_value"
            ).value
        Canvas(Modifier.fillMaxSize()) {
            val scrim = Color.Black.copy(alpha = 0.58f)
            if (target == null) {
                drawRect(scrim)
            } else {
                var cursorY = 0f
                if (target.top > cursorY) {
                    drawRect(scrim, topLeft = androidx.compose.ui.geometry.Offset(0f, cursorY), size = androidx.compose.ui.geometry.Size(size.width, target.top - cursorY))
                }
                if (target.left > 0f) {
                    drawRect(scrim, topLeft = androidx.compose.ui.geometry.Offset(0f, target.top), size = androidx.compose.ui.geometry.Size(target.left, target.height))
                }
                if (target.right < size.width) {
                    drawRect(scrim, topLeft = androidx.compose.ui.geometry.Offset(target.right, target.top), size = androidx.compose.ui.geometry.Size(size.width - target.right, target.height))
                }
                cursorY = target.bottom
                if (cursorY < size.height) {
                    drawRect(scrim, topLeft = androidx.compose.ui.geometry.Offset(0f, cursorY), size = androidx.compose.ui.geometry.Size(size.width, size.height - cursorY))
                }
                drawRoundRect(
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.86f),
                    topLeft = androidx.compose.ui.geometry.Offset(target.left - 4f, target.top - 4f),
                    size = androidx.compose.ui.geometry.Size(target.width + 8f, target.height + 8f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(18f, 18f),
                    style = androidx.compose.ui.graphics.drawscope.Stroke(width = 5f + (pulse - 0.82f) * 4f)
                )
            }
        }
        val placeAtTop = target == null || target.center.y > maxHeightPx / 2f
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .align(if (placeAtTop) Alignment.TopCenter else Alignment.BottomCenter),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 12.dp)
        ) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Dashboard tour • ${stage + 1} of ${steps.size}", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                Text(body, style = MaterialTheme.typography.bodyLarge)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = onSkip) { Text("Skip") }
                    Text("Advancing automatically…", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
    LaunchedEffect(stage) {
        delay(5000)
        if (stage >= steps.lastIndex) onFinish() else onAdvance()
    }
}
