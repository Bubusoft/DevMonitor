# DevMonitor 4.6.0-NEXT v205 — Online Reports GitHub Preflight

The GitHub release workflow now verifies the actual Google Drive Online Reports API access before producing a release APK.

## What this proves
- `DRIVE_REPORT_API_KEY` exists.
- The key can actually query the configured public report folder.
- The production folder ID is the expected folder.
- The generated release `BuildConfig` contains the same API key supplied by GitHub (verified by SHA-256 prefix only; the key is never printed).
- The generated release `BuildConfig` contains the expected folder ID.

If the Drive preflight fails, GitHub stops before producing an APK instead of producing an APK that cannot list/download reports.

Phone build behaviour is unchanged: the user supplies the Drive key manually in local `gradle.properties`; no prompt is added.
