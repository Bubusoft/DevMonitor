# DevMonitor 4.5.18F — Experimental GitHub Actions Build

## Purpose
4.5.18F is an **experimental cloud-build fork** of the locked DevMonitor 4.5.17 performance baseline. The immediate goal is simply to prove that the project can be compiled reliably by GitHub Actions instead of using the phone as the build machine.

## Default build
The GitHub Actions workflow builds **Debug** by default.

- Workflow: `.github/workflows/android-build.yml`
- Build task: `./gradlew assembleDebug --stacktrace --no-daemon`
- Artifact: `DevMonitor-4.5.18F-debug`
- No release signing secrets are required for this experimental build.
- No release keystore is required for this experimental build.

The workflow runs automatically when changes are pushed to `main`, and it can also be started manually with **Run workflow**.

## What we are testing
1. GitHub can check out the project.
2. Java/Gradle setup works in the cloud runner.
3. The project compiles successfully.
4. GitHub produces the Debug APK as an artifact.
5. The resulting APK can be installed and tested on the phone.

## Baseline protection
This fork does not intentionally modify the established payment cycle, four-database Month-on-Month architecture, SMS/device-monitor logic, Loaded Reports authority model, or the 4.5.17 performance baseline.

## Important distinction
This is **not a production/release-signing exercise**. Release signing can be addressed later in a separate production workflow when the experimental build has been validated.

## Version
- versionName: `4.5.18F`
- versionCode: `151`
