# v199 — Online Report Drive Listing/Access Fix

## Problem
The phone build could report `No online reports` even when the configured Drive folder visibly contained Excel reports.

## Fix
- Added `supportsAllDrives=true` and `includeItemsFromAllDrives=true` to Drive listing.
- Increased listing page size.
- Validated the configured folder before listing children, with actionable HTTP error details.
- Kept extension-based Excel detection (`.xlsx`, `.xlsm`, `.xls`, `.csv`).
- Added shared-drive support to media download.

PaymentEngine/payment-cycle logic is unchanged.
