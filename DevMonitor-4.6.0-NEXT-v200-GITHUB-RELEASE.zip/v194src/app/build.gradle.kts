plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.gms.google-services")
}

android { namespace = "com.aziitech.simregmonitor"; compileSdk = 36
    buildFeatures { buildConfig = true }

    val releaseStoreFile = project.findProperty("RELEASE_STORE_FILE")?.toString()
    val releaseStorePassword = project.findProperty("RELEASE_STORE_PASSWORD")?.toString()
    val releaseKeyAlias = project.findProperty("RELEASE_KEY_ALIAS")?.toString()
    val releaseKeyPassword = project.findProperty("RELEASE_KEY_PASSWORD")?.toString()

    signingConfigs {
        create("release") {
            if (!releaseStoreFile.isNullOrBlank() && !releaseStorePassword.isNullOrBlank() &&
                !releaseKeyAlias.isNullOrBlank() && !releaseKeyPassword.isNullOrBlank()) {
                storeFile = file(releaseStoreFile)
                storePassword = releaseStorePassword
                keyAlias = releaseKeyAlias
                this.keyPassword = releaseKeyPassword
            }
        }
    }
    defaultConfig {
        applicationId = "com.aziitech.simregmonitor"
        minSdk = 26
        targetSdk = 36
        versionCode = 200
        versionName = "4.6.0-NEXT"
        buildConfigField("String", "ADMOB_APP_ID", "\"${project.findProperty("ADMOB_APP_ID") ?: "ca-app-pub-4714577695045180~3822025586"}\"")
        buildConfigField("String", "ADMOB_BANNER_AD_UNIT_ID", "\"${project.findProperty("ADMOB_BANNER_AD_UNIT_ID") ?: "ca-app-pub-4714577695045180/2678615670"}\"")
        buildConfigField("String", "ADMOB_INTERSTITIAL_AD_UNIT_ID", "\"${project.findProperty("ADMOB_INTERSTITIAL_AD_UNIT_ID") ?: "ca-app-pub-4714577695045180/7739370665"}\"")
        buildConfigField("String", "ADMOB_REWARDED_AD_UNIT_ID", "\"${project.findProperty("ADMOB_REWARDED_AD_UNIT_ID") ?: "ca-app-pub-4714577695045180/9511512135"}\"")
        buildConfigField("Boolean", "MONETIZED_BUILD", "${project.findProperty("MONETIZED_BUILD") ?: "true"}")
        buildConfigField("String", "BILLING_MONTHLY_PRODUCT_ID", "\"${project.findProperty("BILLING_MONTHLY_PRODUCT_ID") ?: "fieldpulse_remove_ads_monthly"}\"")
        buildConfigField("String", "BILLING_YEARLY_PRODUCT_ID", "\"${project.findProperty("BILLING_YEARLY_PRODUCT_ID") ?: "fieldpulse_remove_ads_yearly"}\"")
        buildConfigField("String", "FEEDBACK_WEB_APP_URL", "\"${project.findProperty("FEEDBACK_WEB_APP_URL") ?: ""}\"")
        // Online Company Reports configuration. Prefer the explicit build property/secret,
        // then the environment-backed property used by phone builds. As a final fallback,
        // use the existing Google Services API key already bundled for this Firebase project.
        // This keeps the app functional when an APK is built directly from the project while
        // still allowing GitHub Actions to inject the dedicated Drive key without hardcoding it.
        val driveReportFolderId = project.findProperty("DRIVE_REPORT_FOLDER_ID")?.toString()?.trim()
            ?: System.getenv("DRIVE_REPORT_FOLDER_ID")?.trim()
            ?: "1d2mCmBiFgQXjIYHAvgjXAD_JgSvITbwI"
        val driveReportApiKey = project.findProperty("DRIVE_REPORT_API_KEY")?.toString()?.trim()
            ?: System.getenv("DRIVE_REPORT_API_KEY")?.trim()
            ?: run {
                val googleServices = file("google-services.json")
                if (googleServices.isFile) {
                    Regex("""["']current_key["']\s*:\s*["']([^"']+)["']""")
                        .find(googleServices.readText())?.groupValues?.getOrNull(1)?.trim().orEmpty()
                } else ""
            }
        buildConfigField("String", "DRIVE_REPORT_FOLDER_ID", "\"$driveReportFolderId\"")
        buildConfigField("String", "DRIVE_REPORT_API_KEY", "\"$driveReportApiKey\"")
        manifestPlaceholders["ADMOB_APP_ID"] = project.findProperty("ADMOB_APP_ID") ?: "ca-app-pub-4714577695045180~3822025586"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = false
        }
    }

    // Phone/Android-IDE release builds can spend an unbounded amount of time in
    // lintVitalAnalyzeRelease after compilation has already succeeded. Lint is
    // advisory here; do not let it block creation of the signed release APK.
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }

}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.9.0")
    implementation("androidx.datastore:datastore-preferences:1.1.1")
    implementation("com.google.android.gms:play-services-ads:23.6.0")
    implementation("com.google.android.gms:play-services-auth:21.3.0")
    implementation(platform("com.google.firebase:firebase-bom:33.16.0"))
    implementation("com.google.firebase:firebase-auth")
    implementation("com.google.firebase:firebase-firestore")
    implementation("io.coil-kt:coil-compose:2.7.0")
    implementation("com.xiaomi.billingclient:billing:1.1.9")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
