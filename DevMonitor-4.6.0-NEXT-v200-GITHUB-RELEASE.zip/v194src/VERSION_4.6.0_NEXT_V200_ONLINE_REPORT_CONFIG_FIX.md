# DevMonitor 4.6.0-NEXT v200 — Online Reports Build Configuration Fix

## Problem
The installed DevMonitor APK could show:

> Online reports are not configured yet. Set the Google Drive folder ID and API key in the build configuration.

This occurred when the Online Company Reports screen was built without the dedicated Drive API key reaching `BuildConfig`, especially for direct/phone builds that did not run the release helper script.

## Fix
- Online Reports now resolves configuration in this order:
  1. Explicit Gradle `DRIVE_REPORT_FOLDER_ID` / `DRIVE_REPORT_API_KEY` properties.
  2. Matching environment variables used by the phone/GitHub build paths.
  3. The existing Google Services `current_key` as a local-build fallback when no dedicated Drive key was injected.
- The production GitHub workflow still prefers the `DRIVE_REPORT_API_KEY` GitHub Secret and does not hardcode that secret into source.
- The production folder ID remains `1d2mCmBiFgQXjIYHAvgjXAD_JgSvITbwI`.
- Existing v199 Google Drive shared-drive/public-folder flags remain intact.
- PaymentEngine/payment-cycle logic is untouched.
- Loaded Report, My Devices, MOM, dashboard search, and profile behavior are untouched.

## Build verification
Version code is now **200**.
