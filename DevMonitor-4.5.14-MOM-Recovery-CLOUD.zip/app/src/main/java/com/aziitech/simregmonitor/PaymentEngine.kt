package com.aziitech.simregmonitor

import java.time.LocalDate
import java.time.YearMonth

/**
 * Unified payment-progression engine with two deliberately separate calculators.
 *
 * Loaded Report progression is calculated only from the continuous normalized
 * Loaded Reports database. Device Monitor progression is calculated from SMS
 * Active data and may consult Loaded Reports only to reconstruct the historical
 * calendar-month baseline needed to turn a cumulative Active counter into a
 * 21st-to-20th payment-cycle value.
 */
object PaymentEngine {
    data class Progression(
        val cycleStart: LocalDate,
        val cycleEnd: LocalDate,
        val asOf: LocalDate,
        val activations: Int?,
        val availableThrough: LocalDate?,
        val complete: Boolean,
        val source: String,
        val baselineDate: LocalDate? = null,
        val baselineActive: Int? = null,
        val warning: String? = null
    ) {
        val estimate: IncentiveEstimate? get() = activations?.let { PaymentRules.estimate(it, 0) }
    }

    object LoadedReports {
        fun calculate(
            deviceId: String,
            asOfRequested: LocalDate = LocalDate.now(),
            companyStore: CompanyActivationStore
        ): Progression {
            val asOf = PaymentRules.currentAwareDate(asOfRequested)
            val (cycleStart, cycleEnd) = PaymentRules.paymentCycleForDate(asOf)
            val values = companyStore.dailyCoverageForDevice(deviceId, cycleStart, asOf)
            val through = values.keys.maxOrNull()
            val total = if (values.isNotEmpty()) values.values.sumOf { it.coerceAtLeast(0) } else null
            val complete = through != null && through >= asOf
            val warning = when {
                values.isEmpty() -> "No Loaded Report data is available for this device in the current payment cycle."
                !complete -> "Loaded Report progression is available through $through; later cycle dates have not been loaded yet."
                else -> null
            }
            return Progression(
                cycleStart = cycleStart,
                cycleEnd = cycleEnd,
                asOf = asOf,
                activations = total,
                availableThrough = through,
                complete = complete,
                source = "Loaded Reports continuous database",
                warning = warning
            )
        }
    }

    object DeviceMonitor {
        fun calculate(
            deviceId: String,
            asOfRequested: LocalDate = LocalDate.now(),
            deviceStore: DatabaseStore,
            companyStore: CompanyActivationStore?
        ): Progression {
            val asOf = PaymentRules.currentAwareDate(asOfRequested)
            val (cycleStart, cycleEnd) = PaymentRules.paymentCycleForDate(asOf)
            val code = canonicalDeviceCode(deviceId)
            val currentMonth = YearMonth.from(asOf)
            val previousMonth = currentMonth.minusMonths(1)

            // The previous-calendar-month portion of a cycle is always report data:
            // e.g. Aug 21-31 when the live cycle is Aug 21-Sep 20.
            val previousPortionStart = cycleStart
            val previousPortionEnd = minOf(asOf, previousMonth.atEndOfMonth())
            val previousPortion = if (previousPortionStart <= previousPortionEnd && companyStore != null) {
                companyStore.dailyCoverageForDevice(code, previousPortionStart, previousPortionEnd)
            } else emptyMap()
            var total = previousPortion.values.sumOf { it.coerceAtLeast(0) }
            var availableThrough = previousPortion.keys.maxOrNull()
            val sources = mutableListOf<String>()
            if (previousPortion.isNotEmpty()) sources += "Loaded Reports ${previousPortionStart}..${previousPortionEnd}"

            val monthStart = currentMonth.atDay(1)
            val loadedReportImportedAt = companyStore?.latestReportImportedAt(monthStart, asOf)
            val sms = deviceStore.observationsBetween(code, monthStart, asOf)
                .filter { it.active != null }
                .filter { observation ->
                    loadedReportImportedAt == null || parseReceivedAt(observation.receivedAt)?.let { it > loadedReportImportedAt } == true
                }
                .sortedBy { it.date }
            val latestSms = sms.lastOrNull()

            if (asOf.dayOfMonth >= 21) {
                // The current payment cycle starts inside the current calendar month.
                // Active is cumulative from the 1st, so subtract the calendar-month
                // baseline at the end of the 20th. Prefer an actual SMS snapshot; when
                // that snapshot does not exist, reconstruct the baseline from Loaded
                // Report daily activations for this specific device.
                val boundary = cycleStart.minusDays(1)
                val baselineSms = deviceStore.observation(code, boundary.toString())?.active
                val baselineFromReports = if (baselineSms == null && companyStore != null) {
                    if (companyStore.hasCompleteDeviceCoverage(code, monthStart, boundary)) {
                        companyStore.dailyCoverageForDevice(code, monthStart, boundary)
                            .values.sumOf { it.coerceAtLeast(0) }
                    } else null
                } else null
                val baseline = baselineSms ?: baselineFromReports

                if (latestSms == null) {
                    // No current Active observation means there is no live Device
                    // Monitor value to subtract from the boundary. Do not silently
                    // replace it with Loaded Report progression.
                    val warning = if (baseline == null) {
                        "Insufficient historical data: Device Monitor needs a current Active value and a $boundary baseline."
                    } else {
                        "No current Device Monitor Active observation is available."
                    }
                    return Progression(
                        cycleStart, cycleEnd, asOf, null, availableThrough, false,
                        sources.joinToString(" + ").ifBlank { "Device Monitor SMS" },
                        boundary, baseline, warning
                    )
                }

                availableThrough = latestSms.date.let { LocalDate.parse(it) }
                if (baseline == null) {
                    return Progression(
                        cycleStart, cycleEnd, asOf, null, availableThrough, false,
                        "Device Monitor SMS Active",
                        boundary, null,
                        "Insufficient historical data to calculate payment progression. Load a report covering the calendar-month history through $boundary."
                    )
                }
                val currentContribution = ((latestSms.active ?: 0) - baseline).coerceAtLeast(0)
                total += currentContribution
                sources += "Device Monitor Active ${latestSms.date} − baseline $boundary"
                return Progression(
                    cycleStart, cycleEnd, asOf, total, availableThrough,
                    availableThrough >= asOf,
                    sources.distinct().joinToString(" + "),
                    boundary, baseline,
                    if (availableThrough < asOf) "Device Monitor progression is current through $availableThrough." else null
                )
            }

            // Days 1-20: the current calendar-month Active value is already the
            // cumulative contribution for the current-month part of the cycle.
            if (latestSms != null) {
                total += (latestSms.active ?: 0).coerceAtLeast(0)
                availableThrough = LocalDate.parse(latestSms.date)
                sources += "Device Monitor Active ${latestSms.date}"
                return Progression(
                    cycleStart, cycleEnd, asOf, total, availableThrough,
                    availableThrough >= asOf,
                    sources.distinct().joinToString(" + ").ifBlank { "Device Monitor Active" },
                    null, 0,
                    if (availableThrough < asOf) "Device Monitor progression is current through $availableThrough." else null
                )
            }

            // Before the 21st there is no current-month SMS evidence. Loaded Reports
            // may still provide a partial progression, but it is explicitly identified
            // as historical/report evidence rather than pretending it is SMS Active.
            if (companyStore != null) {
                val currentLoaded = companyStore.dailyCoverageForDevice(code, monthStart, asOf)
                if (currentLoaded.isNotEmpty()) {
                    total += currentLoaded.values.sumOf { it.coerceAtLeast(0) }
                    availableThrough = maxOf(availableThrough ?: currentLoaded.keys.minOrNull()!!, currentLoaded.keys.maxOrNull()!!)
                    sources += "Loaded Reports current-month fallback"
                    return Progression(
                        cycleStart, cycleEnd, asOf, total, availableThrough, false,
                        sources.distinct().joinToString(" + "),
                        null, 0,
                        "No Device Monitor Active observation is available; current-month progression is report-backed only."
                    )
                }
            }

            return Progression(
                cycleStart, cycleEnd, asOf, if (previousPortion.isNotEmpty()) total else null,
                availableThrough, false,
                sources.distinct().joinToString(" + ").ifBlank { "Device Monitor" },
                null, 0,
                "No Device Monitor Active observation is available for the current month."
            )
        }

        private fun parseReceivedAt(value: String): Long? = runCatching {
            java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US).parse(value)?.time
        }.getOrNull()
    }
}
