# DevMonitor 4.6.0-NEXT v207 — GitHub Online Reports Fix

Derived directly from the original v203 phone-build baseline.

The application OnlineReports implementation is unchanged. The GitHub cloud-build workflow was the problem: the repository workflow was building `assembleDebug` without supplying `DRIVE_REPORT_API_KEY`, while the phone release build reads the key from `gradle.properties`.

This revision changes only the cloud build boundary:
- GitHub builds the signed release variant.
- `DRIVE_REPORT_FOLDER_ID` is supplied as a Gradle project property.
- `DRIVE_REPORT_API_KEY` is supplied through `ORG_GRADLE_PROJECT_DRIVE_REPORT_API_KEY`, which Gradle exposes as the same project property consumed by `app/build.gradle.kts`.
- The phone `gradle.properties` mechanism remains unchanged; no prompt is added.
- Payment, MOM, report import and OnlineReports runtime code are unchanged.
