# DevMonitor 4.6.0-NEXT v170 — Recovery Base + Floating Loader + Same-Coverage HQ Replacement

## Purpose

v170 establishes a controlled development recovery point from v162.1.

The v162.1 application/UI base is retained. Later Loaded Report workflow
experiments from v163-v170 are not carried forward wholesale.

## Retained post-v162.1 UI improvement

The single app-wide floating waiting window is upgraded to the agreed
informative presentation:

- one floating waiting window;
- operation/category label;
- current major step;
- fixed projected overall percentage;
- one progress bar;
- concise user-facing status;
- no row counting or separate performance-monitoring calculation system.

The existing import progress stages remain represented by the existing
import workflow state.

## HQ same-coverage replacement rule

For the current and immediately previous calendar-month HQ stores:

- first valid report for a month is accepted;
- newer coverage replaces the existing complete monthly snapshot;
- older coverage is rejected;
- the same coverage/end date is accepted as a replacement, not rejected as a duplicate;
- replacement remains a complete snapshot replacement;
- current and previous calendar months remain independent.

This specifically accommodates different complete HQ exports such as
registration and activation reports that can share the same coverage end date.

## Deliberately not carried forward

The following later Loaded Report workflow changes are intentionally not
included in this recovery build:

- v163 openLoadedReportViewer workflow changes;
- v170 preferProvidedReport report-selection changes;
- v170 onReportTableReady/frame-synchronization changes;
- v170 previous-report rendering synchronization changes.

Those will be reconsidered independently after the v162.1-based recovery
point is verified.

## Protected

- PaymentEngine and payment formulas/progression rules;
- Device Monitor/SMS business logic;
- Profile Builder;
- two-month HQ architecture;
- existing v162 dashboard/settings/My Devices UI changes;
- release identity.

## Testing note

As of October 1, 2026, the valid active HQ months are October (current)
and September (previous). August is outside the two-month physical HQ
storage window and should not be used as the normal previous-month test.

Local Gradle compilation is not available in the current environment because
the required Gradle distribution is not cached and external Gradle download
is unavailable. GitHub Actions remains the compiler authority.
