# DevMonitor 4.6.0-NEXT v208 — SMS Checker Search + Zero Devices

Base: v203 phone-built source.

## Changes
- Added a fast device search field to SMS CHECKER results.
- Added ZERO DEVICES action beside Quick Check.
- Zero Devices is derived from company devices in the previous month authoritative HQ snapshot that are in the active My Devices ownership scope.
- A device leaves the Zero Devices subset when current-month sales activity is evidenced by an authoritative current-month Loaded Report or by a successful SMS observation with Today/MTD activity.
- The bundled Company Directory skeleton is never treated as sales activity.
- No new physical database was added; the queue is derived on explicit user action from existing monthly HQ data and SMS observations, avoiding another synchronized database.
- Quick Check was reduced to half-width to make room for Zero Devices.
- PaymentEngine, MOM/payment architecture, report importer, and existing SMS workflow were not changed.

## v209 build fix
- Fixed MainActivity.kt missing androidx.compose.ui.unit.sp import used by the SMS Checker search icon.
- versionCode advanced from 208 to 209.
- No feature logic changed.
