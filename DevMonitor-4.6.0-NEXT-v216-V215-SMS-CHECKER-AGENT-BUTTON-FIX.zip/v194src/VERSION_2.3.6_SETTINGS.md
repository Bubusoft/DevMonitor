# FieldPulse 2.3.6 — Comprehensive Settings

## Change
Expanded the app-level Settings screen into a broader Android-style settings area while preserving the existing Monitor Settings dialog.

## General
- Added persistent Theme preference: System default, Light, or Dark.
- Theme selection is stored locally and takes effect immediately.
- System default continues to follow the device theme automatically.

## Monitor
- Existing Monitor settings remain available as a separate section.
- SMS destinations and analytics retention remain unchanged.

## App Experience
- Guided Tour can be started again from Settings.

## Data & Storage
- Added a local-data summary showing codes, current records and history records.
- Clarified that operational data remains local unless deliberately exported or shared.

## Premium
- Existing premium/ad-removal controls remain available.

## More
- Files & Analysis, About the App, and Feedback & Suggestions remain accessible from Settings.

## Preserved
- Full left navigation drawer
- Separate first-launch introduction and guided tour
- Target-aware guided-tour spotlight positioning
- Device Monitor/SMS workflow
- Excel export and Open workflow
- Dashboard, flags, agents/partners, payments, ads and billing
