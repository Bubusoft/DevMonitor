# FieldPulse 4.3.4.17 — Aurora Complete UI Redesign

## Purpose
This build is a presentation-layer redesign of the working 4.3.4.16 baseline. The goal is to move FieldPulse from a Material-heavy interface to the intended Aurora product language shown in the FieldPulse redesign reference.

## Preserved
- Firebase/Google authentication and Firestore partner authorization.
- Existing phone-profile and billing behavior.
- Device Monitor, SMS recovery/recheck and SIMReg report workflows.
- Payment intelligence and existing business rules.
- Google Drive backup/restore.
- Existing Android phone build configuration and AAPT2 override.

## UI changes
- New Aurora surface, action, metric, hero, list-row and status primitives.
- Reduced Material elevation and removed the large grey button halos visible in 4.3.4.16.
- Consistent navy/blue/cyan/violet/green visual hierarchy.
- More deliberate dashboard information hierarchy.
- Refreshed Device Monitor, Settings and Payment/Partner screens.
- Refreshed top-bar brand treatment and account avatar placement.

## Build note
The build environment is intentionally unchanged. Build on Android Code Studio/AndroidIDE with:

```sh
sh ./gradlew :app:assembleDebug
```

or the existing helper:

```sh
sh ./build-phone.sh :app:assembleDebug
```
