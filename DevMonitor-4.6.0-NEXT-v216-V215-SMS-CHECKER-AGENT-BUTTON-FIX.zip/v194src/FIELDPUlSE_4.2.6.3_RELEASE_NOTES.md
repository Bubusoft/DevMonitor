# FieldPulse 4.2.6.3

## Changes
- Saved Company SIMReg workbooks now show a dedicated opening/loading screen while the saved `.xlsx` is read and parsed.
- User-facing wording now uses **Load SIMReg Report File** rather than Import for the SIMReg report workflow.
- Back navigation now returns from app sections to the initial dashboard; only Back from the initial dashboard exits the app.
- Existing saved workbook loading fix from 4.2.6.2 is retained.
- Ads remain enabled.
- Phone-exclusive Gradle/AAPT2 build configuration remains unchanged.

## Build
Use the phone's Android Code Studio environment and run:

`sh build-phone.sh assembleDebug --console=plain`

The project version declaration remains unchanged unless a deliberate release-version bump is requested; **4.2.6.3 is the working package/milestone name for this iteration**.
