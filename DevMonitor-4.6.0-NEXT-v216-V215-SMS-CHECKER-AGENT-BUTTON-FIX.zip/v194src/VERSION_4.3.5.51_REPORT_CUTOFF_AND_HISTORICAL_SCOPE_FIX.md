# DevMonitor 4.3.5.51 — Report Cutoff + Historical Scope Fix

## Problem found in 4.3.5.50

The Month-on-Month calculator could select a current-month report whose `coverage_end` metadata was blank even though normalized `activation_days` contained data through a later date. In that case the calculator fell back to the phone date (for example September 25), causing the previous-month side to run through the 25th instead of the latest available September report date.

The report-population scope for a staff profile also included the current `staff_name` together with territory. Historical ownership can change between reports, so that could make a valid previous report appear to contain zero devices even though the historical territory population is present in the normalized database.

## Fix

- When a report's stored `coverage_end` is missing, derive the report's effective coverage end from `MAX(activation_date)` for that report in the normalized database.
- Use that derived date for the report-aware current-month cutoff.
- For staff-level Option A comparisons, when a territory is configured, filter each report by the territory recorded in that historical report (and region when configured), rather than requiring the current staff name to match historical ownership.
- If no territory is configured, retain staff-name scoping as the fallback.
- Added report-selection logging showing selected current and previous report IDs and effective dates.
- Kept Option A report-population comparison semantics: each month uses the devices recorded in that month's report.
- Device Monitor remains eligible to override a current-month report value only when its observation is newer than the report data.
- No payment calculation/resolver/pathway changes.
