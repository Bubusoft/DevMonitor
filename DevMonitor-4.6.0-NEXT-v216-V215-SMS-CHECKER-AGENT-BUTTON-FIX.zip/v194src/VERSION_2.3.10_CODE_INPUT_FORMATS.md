# FieldPulse 2.3.10 — Flexible Device/Partner Code Input

## Code entry UX
- Updated the Device Monitor input label to clearly say users may paste or type Device/Partner codes.
- Added five illustrated accepted input formats, with the Device short code `GLO-GD-255D` shown first.
- One code per line remains the recommended format for clarity.

## Accepted formats
1. Device short code
2. Comma-separated values
3. Tab-separated values, including lists copied from Excel
4. Semicolon-separated values
5. Multiple lines

## Normalization and SMS behavior
- Existing normalization accepts line breaks, commas, tabs and semicolons.
- Duplicate values are removed automatically.
- GLO long-form device identifiers are normalized to their short device identity.
- For the 3030 SMS query destination, only the canonical Device short code is transmitted.
- Partner codes remain supported and are not incorrectly converted into GLO device codes.

## Guided tour
- The tour now explains the flexible input formats and the short-code SMS behavior.
