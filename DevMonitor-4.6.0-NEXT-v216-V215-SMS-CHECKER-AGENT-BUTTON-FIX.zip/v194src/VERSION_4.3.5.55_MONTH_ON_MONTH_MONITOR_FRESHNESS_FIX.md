# DevMonitor 4.3.5.55 — Month-on-Month Device Monitor Freshness Fix

## Problem
The Month-on-Month card could still move the comparison cutoff from a loaded report's declared coverage date (for example September 23) to a stale/restored Device Monitor observation dated later (for example September 25). This produced an August comparison through the 25th, yielding 1,155 instead of the correct August 1–23 value of 1,058 for the supplied AIYETORO test reports.

## Fix
A Device Monitor observation may extend the current report cutoff only when its `received_at` timestamp is strictly later than the selected current-month report's `imported_at` timestamp. Stale/restored observations therefore cannot override the report cutoff.

The same freshness gate is applied when choosing a Device Monitor `active` value for the current-month total.

If there is no current-month report, a live Device Monitor observation may still supply the current cutoff.

## Expected supplied-report test
- September report coverage: September 1–23
- August comparison window: August 1–23
- Current total: 1,204
- Previous total: 1,058
- Change: +146 (+13.8%)
- Card As of: 2026-09-23

## Protected
- Payment calculation/resolver/progression/pathway logic was not changed.
- Payment-cycle logic was not changed.
- Historical device ownership fork remains deferred.
