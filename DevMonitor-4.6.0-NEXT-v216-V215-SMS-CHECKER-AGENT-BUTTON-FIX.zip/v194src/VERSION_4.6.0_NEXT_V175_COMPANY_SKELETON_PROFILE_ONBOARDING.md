# DevMonitor 4.6.0-NEXT v175 — Company Skeleton & Profile-First Onboarding

## Purpose

Fresh installs must be able to establish the user's company scope before loading a full activation report.

v175 adds a lightweight **Company Skeleton** containing company identity and organisational relationships only. It deliberately contains no activation, performance, MTD, Active, Bar48/96, or payment values.

## Embedded skeleton

The embedded skeleton is generated from the supplied `DAILY SIM-REG REPORT SEPT 1-30TH.xlsx`, sheet `GLOZONE - NEW REG`.

Stored identity fields:

- SN
- Trade Code
- Channel Partner Name
- Device ID
- Cluster
- Region
- Territory
- Staff Name

The supplied workbook did not expose a `DIVISION` column on the detailed sheet, so v175 does not invent a division value. The parser now supports `DIVISION` when a future company workbook supplies that field.

## Profile-first flow

- Dashboard has a prominent **BUILD PROFILE** action.
- Fresh install receives a one-action Build Profile spotlight with **Skip**.
- The introduction now explains the major DevMonitor areas and finishes with **BUILD PROFILE**.
- Profile Builder can search the Company Skeleton by name, Trade Code, partner name, device ID, region, territory, etc.
- Selecting a skeleton record pre-fills the profile scope.
- A profile can be saved from skeleton data even when no HQ activation snapshot exists.
- Activation data remains absent until the user explicitly loads company/HQ data.

## Load Company Data

Profile Builder includes **LOAD COMPANY DATA**.

This action parses the selected company workbook and rebuilds the lightweight skeleton only. It does not import activation rows into the authoritative two-month HQ stores and does not trigger payment, Device Monitor, MOM, dashboard, or other downstream calculations.

The single existing floating waiting window is reused for the operation.

## Actual HQ report presentation

The authoritative HQ snapshot remains atomic. v175 does not partially commit an import to achieve early display.

When a validated report is displayed, its rows are presented in priority order:

1. My Devices
2. Same staff context
3. Same region
4. Same division when supplied by the report/profile
5. Wider company

The underlying snapshot remains complete and authoritative; this is presentation ordering, not a new database or calculation pathway.

## Protected areas

v175 does not change:

- payment formulas or payment progression;
- 21st–20th payment-cycle rules;
- Device Monitor SMS business rules;
- current/previous two-month HQ storage architecture;
- atomic HQ report replacement rules;
- MOM calculation rules;
- explicit-refresh performance culture.

## Source / implementation record

This implementation is based on v173 and the supplied September company workbook. The company skeleton is a separate identity/reference layer and is not a third HQ activation database.
