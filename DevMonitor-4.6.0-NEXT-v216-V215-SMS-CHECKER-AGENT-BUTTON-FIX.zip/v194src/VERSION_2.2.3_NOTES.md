# FieldPulse 2.2.3

- Moved the AdMob banner to the bottom of the app, directly above the navigation bar.
- Uses Google's anchored adaptive banner test unit during development.
- Added an AdMob interstitial test unit and preload manager.
- Interstitials are eligible after every 2nd qualifying completed query event (SUCCESS or NOT_FOUND).
- Interstitials are shown only at the natural pause after a query completes; if an ad is not ready, the app continues without blocking.
- After an interstitial is dismissed, the next interstitial is preloaded.
- Feedback & Suggestions remains included.
- Test ad units must be replaced with your own AdMob ad-unit IDs before production release.
