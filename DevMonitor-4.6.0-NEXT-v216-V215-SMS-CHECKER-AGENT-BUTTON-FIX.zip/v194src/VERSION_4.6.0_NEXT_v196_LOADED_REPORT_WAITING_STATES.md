# DevMonitor 4.6.0-NEXT v196 — Loaded Report Waiting States

## Purpose
Make every potentially delayed Loaded Report operation visibly wait rather than showing a temporarily empty table.

## Behavior
- Saved report resolution: explicit waiting state.
- My Devices working-set preparation: explicit waiting state.
- Table filtering/sorting preparation: explicit waiting state.
- Show All company-data load: explicit waiting state.
- Once My Devices are ready, they can be displayed while the complete HQ report continues resolving.

Payment logic is untouched.
