# FieldPulse 4.3.4.20 — Aurora Gradient Button Redesign

- Redesigned reusable FieldPulse primary buttons as modern pill-shaped gradient controls.
- Redesigned secondary/outlined actions as soft Aurora pill controls with colored borders.
- Added restrained elevation/glow for enabled primary actions.
- Preserved existing click behavior, guided-tour targets, business logic, Firebase/authentication, SMS, SIMReg, reporting, backup, and navigation.
- No new dependencies or build-system changes.
- Version code: 77.
