# DevMonitor 4.5.13 — Release Readiness Correction

## Release purpose

This release is the corrected continuation of 4.5.12. It fixes the physical Month-on-Month rollover and keeps Xiaomi GetApps as the sole/default in-app purchase platform for the current release store.

## Month-on-Month rollover

The four Month-on-Month stores remain physically separate SQLite databases:

- `devmonitor_mom_previous.db`
- `devmonitor_mom_previous_my_devices.db`
- `devmonitor_mom_current.db`
- `devmonitor_mom_current_my_devices.db`

At the start of a new calendar month, the completed Current Month Full and Current Month My Devices databases replace the old Previous Month databases. The old previous month is therefore discarded even if it had been locked as a historical snapshot. New Current Month databases are then physically cleared and begin accumulating the new month.

The historical lock still protects the previous-month stores from ordinary later imports/ownership refreshes; it does not block the deliberate calendar rollover.

## Billing

Xiaomi GetApps is the current and only implemented billing platform in this release. Google Play Billing is not included as a dependency or runtime implementation. Existing Xiaomi subscription product IDs remain:

- `fieldpulse_remove_ads_monthly`
- `fieldpulse_remove_ads_yearly`

## Payment/data architecture

- Device Monitor `Active` remains the calendar-month cumulative activation source.
- A newer Device Monitor observation may supersede an older Loaded Report for current-month live calculations.
- `MTD` is never substituted for `Active`.
- Month-on-Month and Payment remain separate data systems; Loaded Report import is their shared data-ingestion point.
- Existing payment-cycle/business rules are preserved.
