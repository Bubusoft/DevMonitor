# FieldPulse 4.1 — Xiaomi GetApps Premium

- Restored both Premium purchase choices: Monthly and Yearly.
- Monthly Premium target: ₦2,000/month.
- Yearly Premium target: ₦20,000/year (store price is authoritative once configured).
- Premium removes banner, interstitial and rewarded ads.
- Premium bypasses the rewarded-export restriction.
- Added Restore Premium and Manage Subscription actions.
- Replaced Google Play Billing with Xiaomi GetApps IAP SDK 1.1.9 for this GetApps-focused build.
- Uses Xiaomi GetApps subscription SKUs `fieldpulse_remove_ads_monthly` and `fieldpulse_remove_ads_yearly`.
- Uses a stable obfuscated account ID when starting a purchase, as required by Xiaomi's current IAP documentation.
- Re-checks GetApps subscriptions on startup/restore rather than permanently trusting a local flag.
- Existing AdMob, SMS, Google Cloud file sharing, reporting, and operational workflows are otherwise unchanged.

## Xiaomi setup required

Before Premium purchases can complete on GetApps, enable Xiaomi GetApps IAP, add payment/bank details, and create/configure both subscription products in the GetApps developer console. Xiaomi's current documentation also recommends server-side purchase-token verification.


## Production AdMob IDs restored
The production AdMob configuration was recovered from FieldPulse 2.3.14-OPPO APK and applied to this Xiaomi Billing 4.1 source build:
- App ID: ca-app-pub-4714577695045180~3822025586
- Banner: ca-app-pub-4714577695045180/2678615670
- Interstitial: ca-app-pub-4714577695045180/7739370665
- Rewarded: ca-app-pub-4714577695045180/9511512135

Xiaomi GetApps billing integration remains unchanged.


## Billing SDK 1.1.9 compile compatibility fix
- Removed compile-time dependencies on Xiaomi SDK symbols that are not exposed by the resolved 1.1.9 artifact in Android Code Studio.
- Uses response code 0 for OK and the SDK subscription type string `subs`.
- Purchase product IDs and acknowledgement are handled through a small runtime compatibility bridge.
