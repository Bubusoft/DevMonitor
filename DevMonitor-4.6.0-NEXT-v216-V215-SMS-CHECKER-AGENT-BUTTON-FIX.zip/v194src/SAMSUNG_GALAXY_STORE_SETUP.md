# FieldPulse 2.2.8 — Samsung Galaxy Store publishing

## What this build changes
- Version: 2.2.8 / versionCode 35
- Removes the in-app APK downloader/update mechanism.
- Removes REQUEST_INSTALL_PACKAGES.
- Removes FileProvider used only for sideload updates.
- Store updates are handled by Galaxy Store.
- Keeps AdMob integration, bottom banner and interstitial logic.
- Keeps paste-codes -> Start workflow, SMS automation, feedback page and reporting.

## Build
Open the `FieldPulse` folder in Android Studio or Android Code Studio.
Generate a signed Android App Bundle (`.aab`) using the release variant.

Recommended: use Samsung Galaxy Store Seller Portal signing if you want Samsung to manage the signing key for this app. If you use your own signing key, keep it safe and use the same key for every future update.

Before production, replace the Google AdMob test App ID/banner/interstitial IDs in `gradle.properties` or the Gradle command-line properties with your own production AdMob IDs.

Example:
ADMOB_APP_ID=ca-app-pub-XXXXXXXXXXXXXXXX~XXXXXXXXXX
ADMOB_BANNER_AD_UNIT_ID=ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX
ADMOB_INTERSTITIAL_AD_UNIT_ID=ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX

Do not publish with Google's test IDs if you are ready for production monetization.

## Samsung Seller Portal steps
1. Create/sign in to a Samsung Account.
2. Register at Samsung Galaxy Store Seller Portal.
3. Apply for Commercial Seller status. Samsung requires commercial seller status to distribute apps.
4. Add a new Android application.
5. Complete App Information: title, description, icon, screenshots, age rating, support email, privacy policy URL and other required metadata.
6. In Binary, upload the signed `.aab` and select supported Galaxy devices.
7. Select countries/regions and set the app to Free.
8. In Publication, choose a publication date or manual release.
9. In Review, explain that FieldPulse is an SMS automation/reporting utility and provide any required test information.
10. Submit for Samsung review.

## Important review notes
- Do not describe FieldPulse as a Samsung product or imply Samsung endorsement.
- Do not submit a debug build.
- Do not include the Google Drive/self-update APK installer in this Samsung build.
- Keep the privacy policy accurate about SMS data, permissions and advertising.
- Make screenshots accurately represent the app and its ads.

## AdMob monetization after publication
Samsung Galaxy Store is a supported third-party Android store for AdMob. After the app is publicly available:
1. In AdMob, open Apps.
2. Add/link FieldPulse to Samsung Galaxy Store.
3. Use the exact package name: `com.aziitech.simregmonitor`.
4. Complete the AdMob app readiness process.
5. Replace test ad IDs with your own production IDs before release.

AdMob may take 24–48 hours to expose a newly listed store app for linking, and in some cases longer.

## Versioning
Every future Galaxy Store update must use a higher `versionCode` than 35. Example:
- 2.2.9 -> versionCode 36
- 2.3.0 -> versionCode 37

Do not re-enable automatic APK installation/update inside the Galaxy Store build. Galaxy Store policy says apps must not initiate/support automatic updates and apps must not offer app downloads inside the app.
