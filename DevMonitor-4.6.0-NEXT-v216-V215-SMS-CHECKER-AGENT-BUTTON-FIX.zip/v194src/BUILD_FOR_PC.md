# DevMonitor 4.6.0-NEXT v170 — PC Build Path

## Purpose
This project has a PC-friendly Android build path in addition to the established phone/Android Code Studio path. The PC path is intended for the development branch being worked on from a desktop/laptop environment; it does **not** change the Android application architecture or create a separate desktop application.

## PC build environment
- JDK: 17
- Gradle wrapper: 8.7
- Android Gradle Plugin: 8.6.1
- Kotlin: 2.0.21
- compileSdk / targetSdk: 36
- Standard desktop Android SDK / AAPT2 toolchain
- GitHub Actions remains a valid cloud compilation path

## Standard PC build
From the project root:

### Windows PowerShell / Command Prompt
```text
gradlew.bat :app:assembleDebug --no-daemon --console=plain
```

### Linux / macOS
```sh
chmod +x ./gradlew
./gradlew :app:assembleDebug --no-daemon --console=plain
```

The debug APK is produced under:
`app/build/outputs/apk/debug/`

For a signed release build, use the established release configuration and credentials; do not commit the release keystore or passwords.

## Important distinction from the phone build
The PC build must **not** use the ARM-compatible `android.aapt2FromMavenOverride` used by `build-phone.sh`. The phone helper exists specifically for Android Code Studio/ARM64 environments. A normal desktop build should use the standard Android SDK build tools.

Do not replace the phone build path with the PC path. Both are supported development environments for the same Android project.

## v170 recovery-build scope
This v170 recovery build uses v162.1 as its code base and selectively preserves the approved post-v162.1 UI work, especially the single informative floating waiting window.

The current HQ storage rule is:
- current and immediately previous calendar month are independently stored;
- older coverage is rejected;
- newer coverage replaces the monthly snapshot;
- **same coverage date is also accepted as a complete replacement snapshot**;
- import order between the current and previous month does not matter;
- import remains storage-only until the user invokes downstream refresh/display operations.

The protected PaymentEngine/payment rules, Device Monitor/SMS logic, Profile Builder, and release identity are not rewritten by this recovery build.

## PC branch guidance
When the PC-oriented branch is advanced, keep `BUILD_FOR_PC.md`, `BUILD_CLOUD.md`, and `MASTER_WORK_SHEET.md` aligned with the source actually being built. Do not document a PC-only workaround as part of the phone build helper.
