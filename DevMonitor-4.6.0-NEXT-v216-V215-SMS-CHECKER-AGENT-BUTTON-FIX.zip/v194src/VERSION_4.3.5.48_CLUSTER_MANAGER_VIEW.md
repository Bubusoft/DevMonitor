# DevMonitor 4.3.5.48 — Cluster Manager Month-on-Month View

Forked from the verified 4.3.5.47 build.

This fork changes only the Month-on-Month hierarchy presentation:
- Regional Manager drill-down is labeled Cluster Manager instead of Staff.
- Territory is no longer exposed as a Month-on-Month drill-down view.
- The underlying database fields, including territory, remain unchanged.
- No database migration or deletion is performed.
- Cluster Manager results are still calculated on demand only when the Regional Manager invokes the button.
- 4.3.5.47 remains the fallback build.
