# FieldPulse 4.3.4.3 — Firebase Authentication Setup

This build uses Firebase Authentication as the identity/phone-verification authority.

## Firebase project

The supplied `google-services.json` identifies the Firebase project:
- project ID: `fieldpulse-b3eb3`
- Android package: `com.aziitech.simregmonitor`

The JSON belongs at:
`app/google-services.json`

Do not rename it with `(1)`, `(2)` or another suffix.

## Required Firebase console setup

Before testing real OTP:

1. Enable Google sign-in.
2. Enable Phone sign-in.
3. Set SMS region policy to Nigeria only for the intended deployment.
4. Add the SHA fingerprints for the actual debug/release signing keys.
5. Confirm the Google web OAuth client is present in the Firebase-generated configuration.
6. Enable billing/Blaze as required by Firebase Phone Authentication before requesting real verification SMS.

## Security model

FieldPulse does not expose a general-purpose "enter any phone number and send OTP" flow.

The app first requires Google/Firebase identity and then locally checks the configured staff-candidate pattern:

`0805557xxxx`

Only a matching number is allowed to reach Firebase Phone Authentication.

The pattern is an eligibility filter, not proof of employment. OTP proves possession of the phone line. A future central FieldPulse authorization service remains responsible for deciding whether the account receives protected Payment Intelligence access.

## Firebase-side protection

Firebase Authentication itself applies verification throttles and SMS limits. Keep the SMS region policy narrow and do not repeatedly retry throttled requests.

The local 10-minute resend cooldown is an additional UX/abuse-control layer; it is not a substitute for Firebase server-side limits.

## Phone test sequence

1. Sign in with Google.
2. Open Payment Intelligence.
3. Enter a non-staff-pattern number and confirm no OTP is requested.
4. Enter a `0805557xxxx` number.
5. Request OTP.
6. Enter the received code.
7. Confirm the phone is linked to the same Firebase account.
8. Confirm a successfully OTP-verified qualifying staff account can access Payment Intelligence without a second authorization step.
