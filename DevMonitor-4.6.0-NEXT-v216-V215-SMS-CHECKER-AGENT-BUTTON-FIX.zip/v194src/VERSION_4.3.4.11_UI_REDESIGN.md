# FieldPulse 4.3.4.11 — Aurora UI Redesign

## Scope
A visual redesign of the existing FieldPulse application while preserving the working 4.3.4.10 feature set.

## Design direction
- Move away from the former default green-only visual language.
- Use a deep navy/aurora foundation with electric blue, cyan and violet accents, while retaining green only as a status/success accent where useful.
- Use larger rounded surfaces, softer hierarchy and more dimensional controls.
- Give primary buttons a subtle 3D lift/shadow and pressed-state reduction.
- Keep the interface mobile-first and readable on the existing Android phone build environment.

## Motion
- Add animated page transitions when switching the main sections.
- Add animated scaling for the selected bottom-navigation icon.
- Preserve Material motion for the navigation drawer and dialogs.
- Avoid continuous heavy animations that would worsen the reported sluggishness.

## App icon
- Redesigned adaptive/legacy launcher artwork around a FieldPulse FP/signal mark.
- Dark navy base with cyan/blue/violet signal accents.

## Preservation
- Authentication/Firebase configuration unchanged.
- Shared Firestore partner authorization unchanged.
- August historical seed unchanged.
- SIMReg parsing/report storage unchanged.
- Existing SQLite database/migrations unchanged.
- No Apache POI added.
- Existing phone build toolchain unchanged.
