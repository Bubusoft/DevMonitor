# DevMonitor 4.6.0-NEXT v155 — Profile, MOM Detail & Loading UX

## Preserved
- DevMonitor 4.6.0-NEXT payment rules remain protected.
- Four physical Month-on-Month SQLite databases remain unchanged:
  - Previous Month Full
  - Previous Month My Devices
  - Current Month Full
  - Current Month My Devices
- Loaded Report and Device Monitor payment calculators remain separate.
- Profile Builder vertical scrolling remains enabled.

## Changes

### Profile management
- Added **Delete Profile** to an existing profile's Profile Builder.
- Added confirmation before deletion.
- Deletes the selected profile's profile-owned My Devices and Device Monitor database files, including SQLite WAL/SHM sidecars.
- Safely closes the active profile database before deleting it.
- If another profile exists, it becomes active.
- If no profiles remain, DevMonitor returns to the no-active-profile state.
- Shared Month-on-Month historical databases are not deleted by profile deletion.

### Month-on-Month search
- Search results are now openable cards.
- Tapping a result opens a full-detail Month-on-Month view.
- The detail view shows matched devices, current-month totals, previous-month totals, change, percentage change where available, and the comparison date.
- Detail calculations use the existing isolated MOM store through the existing CompanyActivationStore bridge; no PaymentEngine coupling was introduced.

### Floating loading experience
- Added a floating, always-visible activity pill for major loading/processing operations.
- The indicator remains visible while the page is scrolled.
- It identifies the current operation, such as report loading, MOM search, dashboard refresh, or payment progression refresh.
- Added a more polished pulsing DevMonitor activity animation instead of relying only on a page-bound progress indicator.

### Device Monitor payment regression
- Device Monitor payment evidence freshness now compares SMS Active against the newest Loaded Report that actually covers the live date.
- A historical payment-cycle report that overlaps the current calendar month but ends on the 20th can no longer suppress a newer live SMS Active value after the 20th merely because the historical file was imported later.
- Existing baseline reconstruction and 21st–20th payment-cycle rules are preserved.
- Added payment diagnostic logging for SMS/report freshness selection.

## Validation
- Kotlin structural delimiter checks passed for modified Kotlin files.
- ZIP integrity will be checked after packaging.
- Full Gradle compilation remains dependent on the available Gradle distribution/network environment.
