# Building FieldPulse on your Android phone

This project is configured for Android Code Studio / ARM64 phone builds.

## Terminal build

From the project root, run:

```sh
sh build-phone.sh bundleRelease
```

The helper searches common Android Code Studio AAPT2 locations and passes `android.aapt2FromMavenOverride` to Gradle. This avoids the x86_64 AAPT2 binary that can fail on ARM phones.

For a normal APK:

```sh
sh build-phone.sh assembleRelease
```

The AAB should appear under `app/build/outputs/bundle/release/`.

## If AAPT2 is not found

Run:

```sh
echo $HOME
echo $PREFIX
echo $ANDROID_HOME
```

and send the output.

Android Code Studio's documentation confirms that its own AAPT2 binary is ARM-compatible and that direct terminal Gradle builds need the `android.aapt2FromMavenOverride` property.

## Release signing (4.3.5.60)

The project includes `build-phone.sh` for the established phone release workflow:

```sh
sh build-phone.sh assembleRelease --console=plain
```

For a release task, the script uses the existing release keystore and alias:

- Keystore: `/storage/emulated/0/Download/1app/fieldpulse-release.jks`
- Alias: `fieldpulse-release`
- Keystore type: JKS

The keystore password and key password are requested interactively and are passed to Gradle only through temporary environment-backed project properties. They are not written to the project.

The Drive report folder ID is supplied as project configuration. The Drive API key remains local/private: set `DRIVE_REPORT_API_KEY` or `ORG_GRADLE_PROJECT_DRIVE_REPORT_API_KEY` before the build; if neither is set, the release helper prompts for it without echoing the input.
