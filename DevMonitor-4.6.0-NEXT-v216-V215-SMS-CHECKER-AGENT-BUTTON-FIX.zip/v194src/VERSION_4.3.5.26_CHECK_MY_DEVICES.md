# DevMonitor 4.3.5.26 — Check My Devices foundation

- Adds a Dashboard **Check My Devices** shortcut.
- First use verifies that at least one Loaded Company Report exists; if none exists, the existing SIMReg/Online Reports flow is opened before profile setup.
- Adds a **My Devices Profile** entry in Settings.
- Reuses the existing Google account sign-in/backup identity.
- Saves name, phone number, user type and scope.
- Supports Partner (Trade Code), Agent (Device ID), and Staff (Cluster Head / Regional Manager / Staff) scope selection.
- Builds and saves the My Devices list from the latest hierarchy metadata in the Loaded Reports database.
- The saved My Devices list can subsequently be refreshed from the profile.
- Does not alter payment calculation or Device Monitor SMS parsing logic.
