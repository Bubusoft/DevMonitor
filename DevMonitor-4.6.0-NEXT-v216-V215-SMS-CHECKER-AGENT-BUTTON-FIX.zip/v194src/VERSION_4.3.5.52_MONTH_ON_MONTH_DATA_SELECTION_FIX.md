# DevMonitor 4.3.5.52 — Month-on-Month Data Selection Fix

## Problem fixed
The Month-on-Month page could still show a phone-date cutoff such as 2026-09-25 even when the latest loaded September data ended on September 23. It could also show a previous-month total of zero because the calculation depended too heavily on report-header metadata and the previous population selection.

## Fix
- Determine the current report from normalized activation data first, using the newest actual current-month activation date.
- Use report metadata only as a fallback when normalized data does not identify the report.
- Determine the previous-month report from normalized data first as well.
- Use the actual latest current-month data date as the comparison `asOf` date, capped by today's date.
- For a normal STAFF profile, attribute devices by `staff_name` in each month's report. Territory is not used as a substitute for ownership.
- Keep current-month and previous-month populations independent.
- Preserve the existing Device Monitor source hierarchy for current-month device values.
- Keep device/hierarchy drill-down calls restricted to their requested device/group instead of accidentally expanding to the entire report population.
- Add a visible **Refresh Comparison** button directly inside the Month-on-Month performance card.

## Explicitly unchanged
- No payment calculation, resolver, progression, or payment database pathway was modified.
- Month-on-Month remains strictly month-based/report-data-based, not cycle-based.
- Historical device ownership/transfer handling remains deferred to the documented fork.
