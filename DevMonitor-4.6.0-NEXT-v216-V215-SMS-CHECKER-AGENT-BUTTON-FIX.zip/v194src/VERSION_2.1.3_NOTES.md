# FieldPulse v2.1.3

## Google Play SMS-permission readiness

This release keeps `SEND_SMS` and `RECEIVE_SMS` because SMS-based device automation is a documented Google Play exception category, subject to Play review and approval.

Changes:
- SMS permissions are requested only from a user-initiated sending/retry action.
- A clear in-app disclosure appears immediately before the Android permission prompt.
- The disclosure explains that SMS is used for the core device-automation workflow and that SMS data is not used for advertising, profiling, or marketing.
- The existing SMS-only `SmsManager` path and optional sent/delivery reporting are unchanged.
- No RCS/chat API is used.
- The project includes a Play Console declaration guide describing the intended `Device automation` use case.

Important: Google Play review is still required. This release does not guarantee approval. The publisher must submit the SMS/Call Log Permissions Declaration Form accurately and only claim functionality actually implemented in the submitted build.
