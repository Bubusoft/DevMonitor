# FieldPulse 2.3.8 — SMS Recovery + Recheck

## Purpose
Adds checkpoint + Android SMS-inbox reconciliation without locking a code after a same-day result.

## Recovery
- Reads today's Android SMS inbox only after READ_SMS permission is granted.
- Filters to the configured monitoring destination (default 3030).
- Accepts only valid SIMReg SUCCESS/NOT_FOUND responses.
- Uses an explicit code in the response when present.
- Otherwise correlates the response with FieldPulse's persisted outbound query attempts by destination and timestamp.
- Ambiguous responses are left unresolved rather than assigned to the wrong code.
- Recovered results update the current daily observation.

## Recheck
- Previously successful results remain eligible for another send.
- Added batch recheck for previously checked codes.
- Added batch continuation for unresolved codes.
- Added per-code Recheck action.
- A later same-day result replaces the current daily snapshot while history remains available.

## Database
- Database version 7.
- Added `sms_query_attempts` to persist outbound query correlation data.
- Query attempts are retained for 14 days and pruned automatically.

## Permissions
`READ_SMS` is separate from `SEND_SMS`/`RECEIVE_SMS` and is used only for recovery/reconciliation of monitoring responses already stored on the device.
