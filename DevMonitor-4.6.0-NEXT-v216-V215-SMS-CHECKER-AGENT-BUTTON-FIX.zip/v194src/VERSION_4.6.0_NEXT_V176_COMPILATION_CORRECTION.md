# DevMonitor 4.6.0-NEXT v176 — Compilation Correction

## Issue

The v176 Company Skeleton / Profile-First onboarding package failed Kotlin compilation in `CompanyActivationStore.kt`.

Compiler errors:
- line 469: `Map<LocalDate, Int>` supplied where `String` was expected.
- line 521: `Map<LocalDate, Int>` supplied where `String` was expected.

## Cause

`SimRegReportRow` defines its constructor order as:

1. `tradeCode`
2. `partnerName`
3. `deviceId`
4. `cluster`
5. `region`
6. `territory`
7. `staffName`
8. `daily`
9. `grandTotal`
10. `division`
11. `dailyByDate`

The two affected calls supplied `by` as argument 10, so Kotlin attempted to use `Map<LocalDate, Int>` as the `division: String` value.

## Correction

Both calls now explicitly supply an empty division string before the existing `dailyByDate` map.

The correction does not alter the stored activation values, report data, payment logic, Company Skeleton contents, profile hierarchy, or two-month HQ architecture.

## Verification target

The package should pass `:app:compileDebugKotlin` and proceed to the normal debug APK build.
