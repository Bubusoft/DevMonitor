# FieldPulse 4.3.4.24 — SIMReg Loading Animation Compile Correction

This build is a targeted correction to 4.3.4.23.

- Adds the missing Compose `animateFloat` extension import used by the opening-book animation.
- Captures the animation accent color outside the Canvas draw scope so no Composable call occurs inside the DrawScope.
- Preserves the SIMReg expanded-card scrolling/inset fix.
- Preserves the working Aurora touch/ripple feedback.
- Preserves authentication, parser, payment, SMS, and reporting logic.
- No new dependencies.

Version code: 81
Version name: 4.3.4.24
