# DevMonitor Fork Documentation

This document records deferred experimental forks that are deliberately kept outside the mainline release unless explicitly requested.

## Fork 001 — Historical Device Ownership for Month-to-Month Comparisons

**Status:** Planned / Deferred. Do not enable or merge unless explicitly requested.

### Problem
A device can transfer between staff during a month. For example, Staff A may own device 6533D throughout August and Staff B may receive it during September. Company reporting can attribute August activity to Staff A and September activity to Staff B. A straightforward current-owner lookup can therefore produce large month-to-month differences that do not represent a like-for-like ownership history.

### Intended experimental approach
Add a lightweight historical ownership layer alongside the existing normalized activation database, conceptually:

```text
device_ownership_history
--------------------------------
device_code
owner_id
owner_type
effective_from
effective_to
source_report_date
```

Month-to-Month would use the ownership effective during each reporting period when attributing historical activity.

### Protected existing behavior
- Do not rewrite or move normalized activation-day records because ownership changed later.
- Do not change payment calculations or payment resolvers.
- Do not replace the My Devices architecture.
- Do not require the same device population in both months.
- Do not silently change existing Month-to-Month results; compare experimental results explicitly.

### Performance / normalization questions
1. Does the additional ownership layer improve historical attribution correctness?
2. How much storage does it add?
3. Does report import become materially slower?
4. Does Month-to-Month querying become materially slower?
5. Does CPU or memory usage increase on the phone?
6. How are missing, duplicate or conflicting ownership records handled?
7. How does the design behave with large historical datasets?

### Acceptance test
For a known transfer:

```text
6533D
August owner: Staff A
September owner: Staff B
```

The experiment must attribute:

```text
August production    -> Staff A
September production -> Staff B
```

without moving August activity to Staff B merely because B is the current owner.

### Merge condition
Only consider merging after correctness and real-device performance testing demonstrate that the additional normalization/query layer provides the intended historical attribution without a material degradation in import, query, CPU, memory or storage performance.

## Fork workflow rule
Every future fork should document:
- the problem it is intended to address;
- the proposed approach;
- existing behavior that must remain protected;
- normalization/storage impact;
- CPU/memory/query/import performance questions;
- test data and acceptance criteria;
- conditions required before merging into mainline.
