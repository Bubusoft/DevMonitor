# DevMonitor 4.5.14 — Release Recovery Audit

## User recovery improvements

### Month-on-Month
- If the user opens Month-on-Month without a saved profile/device scope, the app now explains that a profile is required and offers **Open Profile**.
- If a valid profile exists but the required historical/current Loaded Report data has not yet been imported, the app explains what is missing and offers **Open Loaded Report**.
- The Loaded Report route is the intended data-import entry point; imported data is written into the four physical Month-on-Month databases at import time.

### Device Monitor payment estimate
- The historical-data warning is no longer allowed to disappear automatically after four seconds.
- The warning now explains why the estimate cannot be calculated and provides:
  - **Load Company Report** — opens Loaded Report.
  - **Recheck Device** — returns directly to the Device Monitor SMS workflow.
- This preserves the rule that Device Monitor Active is the preferred live current-month value when newer than Loaded Report, while still requiring the historical cycle baseline.

## Other audited release paths
The current source contains the established workflows for Device Monitor, SIMReg/Loaded Reports, My Devices/profiles, Payments, Month-on-Month, exports/sharing, Tasks, Notes, Device Timeline, Visual Trends, Action Center/Notifications, Files & Analysis, Online Reports, About/Feedback, Google Sign-In diagnostics, and Premium.

No payment business rules or payment-cycle rules were changed in this recovery pass.

## Build validation limitation
The local environment could not execute the Gradle build because the Gradle 8.7 distribution is not available locally and `services.gradle.org` is unreachable. Source/package validation was performed; cloud/phone build remains the authoritative APK compilation step.
