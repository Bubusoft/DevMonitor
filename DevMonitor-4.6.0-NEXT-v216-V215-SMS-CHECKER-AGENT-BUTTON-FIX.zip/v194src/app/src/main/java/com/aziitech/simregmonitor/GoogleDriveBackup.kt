package com.aziitech.simregmonitor

import android.content.Context
import com.google.android.gms.auth.GoogleAuthUtil
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Private Google Drive appData backup. The database stays local unless the user explicitly backs it up. */
object GoogleDriveBackup {
    private const val SCOPE = "oauth2:https://www.googleapis.com/auth/drive.appdata"
    private const val API = "https://www.googleapis.com/drive/v3/files"
    private const val UPLOAD = "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart"
    private const val NAME = "DevMonitorBackup.db"

    suspend fun backup(context: Context, account: GoogleSignInAccount, dbFile: File): String = withContext(Dispatchers.IO) {
        val token = GoogleAuthUtil.getToken(context, account.email ?: throw IllegalStateException("Google account email is unavailable"), SCOPE)
        val boundary = "DevMonitor-${System.currentTimeMillis()}"
        val metadata = JSONObject().put("name", NAME).put("parents", org.json.JSONArray().put("appDataFolder"))
        val body = dbFile.readBytes()
        val conn = URL(UPLOAD).openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.doOutput = true
        conn.setRequestProperty("Authorization", "Bearer $token")
        conn.setRequestProperty("Content-Type", "multipart/related; boundary=$boundary")
        conn.outputStream.use { out ->
            out.write("--$boundary\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n".toByteArray())
            out.write(metadata.toString().toByteArray())
            out.write("\r\n--$boundary\r\nContent-Type: application/octet-stream\r\n\r\n".toByteArray())
            out.write(body)
            out.write("\r\n--$boundary--\r\n".toByteArray())
        }
        if (conn.responseCode !in 200..299) throw IllegalStateException("Google Drive backup failed (${conn.responseCode})")
        conn.disconnect()
        "Backup completed to your Google Drive app data"
    }

    suspend fun restore(context: Context, account: GoogleSignInAccount, target: File): String = withContext(Dispatchers.IO) {
        val token = GoogleAuthUtil.getToken(context, account.email ?: throw IllegalStateException("Google account email is unavailable"), SCOPE)
        val query = java.net.URLEncoder.encode("name='$NAME' and 'appDataFolder' in parents and trashed=false", "UTF-8")
        val list = request("$API?q=$query&spaces=appDataFolder&fields=files(id,name,modifiedTime)&pageSize=10", token)
        val files = JSONObject(list).optJSONArray("files")
        if (files == null || files.length() == 0) throw IllegalStateException("No DevMonitor backup was found in this Google account")
        var newestId = files.getJSONObject(0).getString("id")
        var newestTime = files.getJSONObject(0).optString("modifiedTime")
        for (i in 1 until files.length()) {
            val o = files.getJSONObject(i); val t = o.optString("modifiedTime")
            if (t > newestTime) { newestTime = t; newestId = o.getString("id") }
        }
        val conn = URL("$API/$newestId?alt=media").openConnection() as HttpURLConnection
        conn.setRequestProperty("Authorization", "Bearer $token")
        if (conn.responseCode !in 200..299) throw IllegalStateException("Google Drive restore failed (${conn.responseCode})")
        val bytes = conn.inputStream.use { it.readBytes() }; conn.disconnect()
        if (bytes.size < 1000) throw IllegalStateException("The cloud backup appears invalid")
        target.outputStream().use { it.write(bytes) }
        "Restore downloaded successfully"
    }

    private fun request(url: String, token: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.setRequestProperty("Authorization", "Bearer $token")
        if (c.responseCode !in 200..299) throw IllegalStateException("Google Drive request failed (${c.responseCode})")
        return c.inputStream.bufferedReader().use { it.readText() }.also { c.disconnect() }
    }
}
