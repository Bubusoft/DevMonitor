package com.aziitech.simregmonitor

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

/**
 * User-scoped primary working database for Check My Devices.
 * The normalized company database remains the complete authoritative archive,
 * while this database is the fast everyday working set containing only the
 * user's devices and the active working-window data.
 */
class MyDevicesStore(private val context: Context, databaseName: String = DB_NAME) : SQLiteOpenHelper(context, databaseName, null, DB_VERSION) {
    companion object {
        private const val DB_NAME = "my_devices.db"
        private const val DB_VERSION = 2
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE my_devices(code TEXT PRIMARY KEY, json TEXT, updated_at INTEGER NOT NULL)")
        db.execSQL("CREATE INDEX idx_my_devices_updated ON my_devices(updated_at)")
        db.execSQL("CREATE TABLE my_devices_meta(key TEXT PRIMARY KEY, value TEXT)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("CREATE TABLE IF NOT EXISTS my_devices_meta(key TEXT PRIMARY KEY, value TEXT)")
        }
    }

    fun codes(): List<String> {
        val out = mutableListOf<String>()
        readableDatabase.rawQuery("SELECT code FROM my_devices ORDER BY rowid ASC", null).use { c ->
            while (c.moveToNext()) out.add(c.getString(0))
        }
        return out
    }

    fun replaceCodes(codes: List<String>) {
        val normalized = codes.map(::canonicalDeviceCode).filter { it.isNotBlank() }.distinct()
        val db = writableDatabase
        db.beginTransaction()
        try {
            val keep = normalized.toHashSet()
            val existing = mutableListOf<String>()
            db.rawQuery("SELECT code FROM my_devices", null).use { c -> while (c.moveToNext()) existing.add(c.getString(0)) }
            existing.filterNot { it in keep }.forEach { db.delete("my_devices", "code=?", arrayOf(it)) }
            val now = System.currentTimeMillis()
            normalized.forEach { code ->
                db.execSQL("INSERT OR IGNORE INTO my_devices(code,json,updated_at) VALUES(?,?,?)", arrayOf(code, null, now))
                db.execSQL("UPDATE my_devices SET updated_at=? WHERE code=?", arrayOf(now, code))
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    /** Replace the materialized primary working set. Only the requested date window
     * is persisted, so the My Devices table never needs to scan the company database. */
    fun replaceWorkingSet(
        rows: List<SimRegReportRow>,
        codes: List<String>,
        start: LocalDate,
        end: LocalDate
    ) {
        val normalizedCodes = codes.map(::canonicalDeviceCode).filter { it.isNotBlank() }.distinct()
        replaceCodes(normalizedCodes)
        val wanted = normalizedCodes.toHashSet()
        val db = writableDatabase
        db.beginTransaction()
        try {
            val now = System.currentTimeMillis()
            val byCode = rows.filter { canonicalDeviceCode(it.deviceId) in wanted }
                .associateBy { canonicalDeviceCode(it.deviceId) }
            normalizedCodes.forEach { code ->
                val row = byCode[code]
                if (row == null) {
                    db.execSQL("UPDATE my_devices SET json=NULL,updated_at=? WHERE code=?", arrayOf(now, code))
                } else {
                    val clipped = row.copy(
                        dailyByDate = row.dailyByDate.filterKeys { !it.isBefore(start) && !it.isAfter(end) },
                        grandTotal = row.dailyByDate.filterKeys { !it.isBefore(start) && !it.isAfter(end) }.values.sum()
                    )
                    db.execSQL("UPDATE my_devices SET json=?,updated_at=? WHERE code=?", arrayOf(rowToJson(clipped).toString(), now, code))
                }
            }
            db.execSQL("INSERT OR REPLACE INTO my_devices_meta(key,value) VALUES('window_start',?)", arrayOf(start.toString()))
            db.execSQL("INSERT OR REPLACE INTO my_devices_meta(key,value) VALUES('window_end',?)", arrayOf(end.toString()))
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun workingWindow(): Pair<LocalDate, LocalDate>? {
        val values = mutableMapOf<String, String>()
        readableDatabase.rawQuery("SELECT key,value FROM my_devices_meta WHERE key IN ('window_start','window_end')", null).use { c ->
            while (c.moveToNext()) values[c.getString(0)] = c.getString(1)
        }
        val start = values["window_start"]?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
        val end = values["window_end"]?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
        return if (start != null && end != null) start to end else null
    }

    fun hasDevice(code: String): Boolean = readableDatabase.rawQuery(
        "SELECT 1 FROM my_devices WHERE code=? LIMIT 1", arrayOf(canonicalDeviceCode(code))
    ).use { it.moveToFirst() }

    fun dailyCoverageForDevice(deviceId: String, start: LocalDate, end: LocalDate): Map<LocalDate, Int> {
        if (start.isAfter(end)) return emptyMap()
        val code = canonicalDeviceCode(deviceId)
        val row = readableDatabase.rawQuery("SELECT json FROM my_devices WHERE code=? LIMIT 1", arrayOf(code)).use { c ->
            if (c.moveToFirst() && !c.isNull(0)) runCatching { jsonToRow(JSONObject(c.getString(0))) }.getOrNull() else null
        } ?: return emptyMap()
        return row.dailyByDate.filterKeys { !it.isBefore(start) && !it.isAfter(end) }
    }

    fun cycleTotal(deviceId: String, date: LocalDate = LocalDate.now()): Int? {
        val code = canonicalDeviceCode(deviceId)
        if (!hasDevice(code)) return null
        val (start, _) = PaymentRules.paymentCycleForDate(PaymentRules.currentAwareDate(date))
        val values = dailyCoverageForDevice(code, start, PaymentRules.currentAwareDate(date))
        return values.values.sum()
    }

    fun cycleContributions(deviceId: String, date: LocalDate = LocalDate.now()): List<CompanyActivationStore.CycleContribution> {
        val code = canonicalDeviceCode(deviceId)
        if (!hasDevice(code)) return emptyList()
        val asOf = PaymentRules.currentAwareDate(date)
        val (start, end) = PaymentRules.paymentCycleForDate(asOf)
        val values = dailyCoverageForDevice(code, start, asOf)
        if (values.isEmpty()) return listOf(CompanyActivationStore.CycleContribution(-1L, "My Devices working database", start, minOf(end, asOf), 0))
        return listOf(CompanyActivationStore.CycleContribution(-1L, "My Devices working database", values.keys.minOrNull(), values.keys.maxOrNull(), values.values.sum()))
    }

    fun cycleSundayActivations(deviceId: String, date: LocalDate = LocalDate.now()): Int {
        val code = canonicalDeviceCode(deviceId)
        if (!hasDevice(code)) return 0
        val asOf = PaymentRules.currentAwareDate(date)
        val (start, _) = PaymentRules.paymentCycleForDate(asOf)
        return dailyCoverageForDevice(code, start, asOf).entries.sumOf { (d, value) ->
            if (d.dayOfWeek.value == 7 && value >= PaymentRules.SUNDAY_MIN_ACTIVATIONS) value else 0
        }
    }

    fun cachedRows(): List<SimRegReportRow> {
        val out = mutableListOf<SimRegReportRow>()
        readableDatabase.rawQuery("SELECT json FROM my_devices WHERE json IS NOT NULL ORDER BY rowid ASC", null).use { c ->
            while (c.moveToNext()) runCatching { out.add(jsonToRow(JSONObject(c.getString(0)))) }
        }
        return out
    }

    private fun rowToJson(r: SimRegReportRow): JSONObject = JSONObject().apply {
        put("tradeCode", r.tradeCode)
        put("partnerName", r.partnerName)
        put("deviceId", r.deviceId)
        put("cluster", r.cluster)
        put("region", r.region)
        put("territory", r.territory)
        put("staffName", r.staffName)
        put("grandTotal", r.grandTotal)
        put("daily", JSONArray().apply { r.daily.entries.sortedBy { it.key }.forEach { put(JSONObject().put("day", it.key).put("value", it.value)) } })
        put("dailyByDate", JSONArray().apply { r.dailyByDate.entries.sortedBy { it.key }.forEach { put(JSONObject().put("date", it.key.toString()).put("value", it.value)) } })
    }

    private fun jsonToRow(o: JSONObject): SimRegReportRow {
        val daily = linkedMapOf<Int, Int>()
        val da = o.optJSONArray("daily") ?: JSONArray()
        for (i in 0 until da.length()) {
            val x = da.optJSONObject(i) ?: continue
            daily[x.optInt("day")] = x.optInt("value")
        }
        val byDate = linkedMapOf<LocalDate, Int>()
        val dates = o.optJSONArray("dailyByDate") ?: JSONArray()
        for (i in 0 until dates.length()) {
            val x = dates.optJSONObject(i) ?: continue
            runCatching { LocalDate.parse(x.optString("date")) }.onSuccess { byDate[it] = x.optInt("value") }
        }
        return SimRegReportRow(
            tradeCode = o.optString("tradeCode"), partnerName = o.optString("partnerName"),
            deviceId = o.optString("deviceId"), cluster = o.optString("cluster"),
            region = o.optString("region"), territory = o.optString("territory"),
            staffName = o.optString("staffName"), daily = daily,
            grandTotal = o.optInt("grandTotal"), dailyByDate = byDate
        )
    }
}
