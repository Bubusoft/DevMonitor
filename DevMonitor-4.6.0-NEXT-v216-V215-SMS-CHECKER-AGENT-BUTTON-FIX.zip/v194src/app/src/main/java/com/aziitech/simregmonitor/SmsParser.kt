package com.aziitech.simregmonitor

object SmsParser {
    /** Attempts to identify a device/agent code when the carrier includes it in the response. */
    fun extractCode(raw: String): String? {
        val patterns = listOf(
            Regex("(?i)\\b(GLO-(?:GD|DD|FD)-[A-Z0-9]+)\\b"),
            Regex("(?im)^(?:agent\\s*code|code|device\\s*code)\\s*[:=-]\\s*([A-Z0-9-]+)\\s*$")
        )
        for (p in patterns) p.find(raw)?.groupValues?.getOrNull(1)?.let { return canonicalDeviceCode(it) }
        return null
    }

    fun parse(code: String, raw: String, receivedAt: String): SimRegResult {
        fun n(vararg labels: String): Int? {
            for (label in labels) {
                val match = Regex("(?im)^\\s*${Regex.escape(label)}\\s*:\\s*(\\d+)").find(raw)
                if (match != null) return match.groupValues[1].toIntOrNull()
            }
            return null
        }
        val status = when {
            raw.contains("agent code does not exist", true) -> AttemptStatus.NOT_FOUND
            raw.contains("Todays SIMReg Count", true) && raw.contains("MTD SIMReg Count", true) -> AttemptStatus.SUCCESS
            else -> AttemptStatus.UNRECOGNIZED
        }
        return SimRegResult(
            code = code,
            type = QueryType.from(code),
            receivedAt = receivedAt,
            today = n("Todays SIMReg Count"),
            mtd = n("MTD SIMReg Count"),
            active = n("Active"),
            bar48 = n("Bar 48"),
            bar96 = n("Bar 96"),
            duplicates = n("Duplicates", "Duplicate"),
            monthlyTarget = n("Monthly Target"),
            status = status,
            raw = raw
        )
    }
}
