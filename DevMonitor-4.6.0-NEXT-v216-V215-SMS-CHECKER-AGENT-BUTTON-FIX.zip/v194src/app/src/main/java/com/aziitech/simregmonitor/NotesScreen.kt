package com.aziitech.simregmonitor

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun NotesDialog(
    store: DatabaseStore,
    deviceCodes: List<String>,
    agents: List<Agent>,
    onDismiss: () -> Unit
) {
    var notes by remember { mutableStateOf(store.operationalNotes()) }
    var showEditor by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<OperationalNote?>(null) }
    var query by remember { mutableStateOf("") }

    fun refresh() { notes = store.operationalNotes() }
    val visible = remember(notes, query) {
        val q = query.trim()
        if (q.isBlank()) notes else notes.filter {
            it.title.contains(q, true) || it.body.contains(q, true) ||
                (it.linkValue?.contains(q, true) == true)
        }
    }

    if (showEditor) {
        NoteEditorDialog(
            note = editing, deviceCodes = deviceCodes, agents = agents,
            onDismiss = { showEditor = false },
            onSave = { note -> store.saveOperationalNote(note); showEditor = false; refresh() }
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Notes") },
        text = {
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = query, onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(), singleLine = true,
                    label = { Text("Search notes") }, placeholder = { Text("Title, details or linked item") }
                )
                if (visible.isEmpty()) {
                    Text(if (query.isBlank()) "No notes yet. Add an operational note and optionally link it to a device, partner or staff member." else "No notes match your search.")
                } else {
                    LazyColumn(Modifier.heightIn(max = 470.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(visible, key = { it.id }) { note ->
                            ElevatedCard(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                        Text(note.title.ifBlank { "Untitled note" }, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                        TextButton(onClick = { store.setOperationalNotePinned(note.id, !note.pinned); refresh() }) { Text(if (note.pinned) "Pinned" else "Pin") }
                                    }
                                    Text(note.body)
                                    val link = if (note.linkType != null && note.linkValue != null) "${note.linkType!!.lowercase().replaceFirstChar { it.uppercase() }}: ${note.linkValue}" else "General note"
                                    Text(link, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                        TextButton(onClick = { editing = note; showEditor = true }) { Text("Edit") }
                                        TextButton(onClick = { store.deleteOperationalNote(note.id); refresh() }) { Text("Delete") }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { DevMonitorButton(onClick = { editing = null; showEditor = true }) { Text("Add note") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

@Composable
private fun NoteEditorDialog(
    note: OperationalNote?, deviceCodes: List<String>, agents: List<Agent>,
    onDismiss: () -> Unit, onSave: (OperationalNote) -> Unit
) {
    var title by remember(note) { mutableStateOf(note?.title ?: "") }
    var body by remember(note) { mutableStateOf(note?.body ?: "") }
    var linkType by remember(note) { mutableStateOf(note?.linkType ?: "NONE") }
    var linkValue by remember(note) { mutableStateOf(note?.linkValue ?: "") }
    var pinned by remember(note) { mutableStateOf(note?.pinned ?: false) }
    var linkExpanded by remember { mutableStateOf(false) }
    var valueExpanded by remember { mutableStateOf(false) }
    val linkOptions = listOf("NONE", "DEVICE", "PARTNER", "STAFF")
    val values = when (linkType) {
        "DEVICE" -> deviceCodes.filter { it.startsWith("GLO-", true) }.distinct()
        "PARTNER" -> deviceCodes.filter { !it.startsWith("GLO-", true) }.distinct()
        "STAFF" -> agents.map { "${it.id}|${it.name}" }
        else -> emptyList()
    }
    val canSave = body.isNotBlank() && (linkType == "NONE" || linkValue.isNotBlank())
    fun displayValue(value: String): String = if (linkType == "STAFF") value.substringAfter('|', value) else value

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (note == null) "New note" else "Edit note") },
        text = {
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, Modifier.fillMaxWidth(), label = { Text("Title (optional)") }, placeholder = { Text("e.g. Agent discussion") }, singleLine = true)
                OutlinedTextField(body, { body = it }, Modifier.fillMaxWidth(), label = { Text("Note") }, placeholder = { Text("Write the operational detail here…") }, minLines = 4)
                Box {
                    OutlinedButton(onClick = { linkExpanded = true }, modifier = Modifier.fillMaxWidth()) { Text("Link: ${linkType.lowercase().replaceFirstChar { it.uppercase() }}") }
                    DropdownMenu(linkExpanded, { linkExpanded = false }) { linkOptions.forEach { type -> DropdownMenuItem(text = { Text(type.lowercase().replaceFirstChar { it.uppercase() }) }, onClick = { linkType = type; linkValue = ""; linkExpanded = false }) } }
                }
                if (linkType != "NONE") {
                    Box {
                        OutlinedButton(onClick = { valueExpanded = true }, modifier = Modifier.fillMaxWidth(), enabled = values.isNotEmpty()) { Text(if (linkValue.isBlank()) "Choose ${linkType.lowercase()}" else displayValue(linkValue)) }
                        DropdownMenu(valueExpanded, { valueExpanded = false }) { values.forEach { value -> DropdownMenuItem(text = { Text(displayValue(value)) }, onClick = { linkValue = value.substringBefore('|').ifBlank { value }; valueExpanded = false }) } }
                    }
                    if (values.isEmpty()) Text("No ${linkType.lowercase()} items are currently available in this profile.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = pinned, onCheckedChange = { pinned = it })
                    Text("Pin this note to the top")
                }
            }
        },
        confirmButton = {
            DevMonitorButton(enabled = canSave, onClick = {
                onSave(OperationalNote(note?.id ?: 0L, title.trim(), body.trim(), linkType.takeUnless { it == "NONE" }, linkValue.substringBefore('|').ifBlank { null }, pinned, note?.createdAt ?: System.currentTimeMillis(), System.currentTimeMillis()))
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
