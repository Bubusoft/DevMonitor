package com.aziitech.simregmonitor

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Lightweight, profile-scoped in-app notification store. It never performs work in the background. */
data class DevMonitorNotification(
    val id: String,
    val title: String,
    val message: String,
    val timestamp: Long,
    val kind: String,
    val read: Boolean
)

object NotificationStore {
    private const val PREFS = "devmonitor_notifications"
    private const val MAX_ITEMS = 80

    private fun key(profileId: String) = "items_${profileId.ifBlank { "default" }}"

    fun list(context: Context, profileId: String): List<DevMonitorNotification> = runCatching {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(key(profileId), "[]") ?: "[]"
        val array = JSONArray(raw)
        buildList {
            for (i in 0 until array.length()) {
                val o = array.optJSONObject(i) ?: continue
                add(
                    DevMonitorNotification(
                        id = o.optString("id"),
                        title = o.optString("title"),
                        message = o.optString("message"),
                        timestamp = o.optLong("timestamp"),
                        kind = o.optString("kind", "info"),
                        read = o.optBoolean("read", false)
                    )
                )
            }
        }.sortedByDescending { it.timestamp }
    }.getOrDefault(emptyList())

    fun add(context: Context, profileId: String, title: String, message: String, kind: String = "info") {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val current = list(context, profileId).toMutableList()
        current.add(0, DevMonitorNotification(UUID.randomUUID().toString(), title, message, System.currentTimeMillis(), kind, false))
        val array = JSONArray()
        current.take(MAX_ITEMS).forEach { n ->
            array.put(JSONObject().apply {
                put("id", n.id); put("title", n.title); put("message", n.message)
                put("timestamp", n.timestamp); put("kind", n.kind); put("read", n.read)
            })
        }
        prefs.edit().putString(key(profileId), array.toString()).apply()
    }

    fun markRead(context: Context, profileId: String, id: String) = rewrite(context, profileId) { it.map { n -> if (n.id == id) n.copy(read = true) else n } }

    fun markAllRead(context: Context, profileId: String) = rewrite(context, profileId) { it.map { n -> n.copy(read = true) } }

    fun clear(context: Context, profileId: String) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(key(profileId)).apply()

    private fun rewrite(context: Context, profileId: String, transform: (List<DevMonitorNotification>) -> List<DevMonitorNotification>) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val array = JSONArray()
        transform(list(context, profileId)).take(MAX_ITEMS).forEach { n ->
            array.put(JSONObject().apply {
                put("id", n.id); put("title", n.title); put("message", n.message)
                put("timestamp", n.timestamp); put("kind", n.kind); put("read", n.read)
            })
        }
        prefs.edit().putString(key(profileId), array.toString()).apply()
    }
}
