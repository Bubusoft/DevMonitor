package com.aziitech.simregmonitor

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Lightweight, user-triggered reporting helpers. Does not calculate or alter payment rules. */
object ReportExportPack {
    fun shareDailySnapshot(context: Context, dashboard: DashboardSummary, format: SnapshotFormat): Boolean {
        return runCatching {
            val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
            val file = when (format) {
                SnapshotFormat.IMAGE -> createImage(context, dashboard, stamp)
                SnapshotFormat.PDF -> createPdf(context, dashboard, stamp)
            }
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = if (format == SnapshotFormat.IMAGE) "image/png" else "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_TEXT, "DevMonitor Daily Snapshot — ${dashboard.date}")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Share Daily Snapshot"))
            true
        }.getOrDefault(false)
    }

    private fun createImage(context: Context, d: DashboardSummary, stamp: String): File {
        val width = 1080
        val height = 1320
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(0xFFF7FAFD.toInt())
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF12233A.toInt(); textSize = 34f; typeface = Typeface.DEFAULT }
        val bold = Paint(paint).apply { typeface = Typeface.DEFAULT_BOLD }
        canvas.drawText("DevMonitor", 64f, 82f, bold.apply { textSize = 48f; color = 0xFF00843D.toInt() })
        canvas.drawText("Daily Operational Snapshot", 64f, 130f, paint.apply { textSize = 30f; color = 0xFF40546A.toInt() })
        canvas.drawText(d.date, 64f, 178f, paint.apply { textSize = 26f })
        var y = 250f
        val metrics = listOf(
            "Devices observed" to d.deviceCount.toString(),
            "Today's SIMReg" to d.todayTotal.toString(),
            "MTD SIMReg" to d.mtdTotal.toString(),
            "Active" to d.activeTotal.toString(),
            "Bar 48" to d.bar48Total.toString(),
            "Bar 96" to d.bar96Total.toString(),
            "Company today / MTD" to "${d.companyToday} / ${d.companyMtd}",
            "Partner today / MTD" to "${d.partnerToday} / ${d.partnerMtd}",
            "Active flags" to d.flags.size.toString()
        )
        for ((label, value) in metrics) {
            canvas.drawRoundRect(54f, y - 34f, width - 54f, y + 28f, 18f, 18f, Paint(paint).apply { color = 0xFFFFFFFF.toInt() })
            canvas.drawText(label, 82f, y + 5f, paint.apply { textSize = 24f; color = 0xFF40546A.toInt() })
            canvas.drawText(value, 800f, y + 5f, bold.apply { textSize = 26f; color = 0xFF12233A.toInt() })
            y += 88f
        }
        y += 28f
        canvas.drawText("Exceptions", 64f, y, bold.apply { textSize = 30f; color = 0xFFD14B5B.toInt() })
        y += 48f
        val flags = d.flags.take(8)
        if (flags.isEmpty()) canvas.drawText("No active flags recorded.", 64f, y, paint.apply { textSize = 24f })
        else flags.forEach { flag ->
            val line = "• ${flag.code}: ${flag.reason}"
            canvas.drawText(line.take(78), 70f, y, paint.apply { textSize = 21f; color = 0xFF40546A.toInt() })
            y += 38f
        }
        val file = File(context.cacheDir, "DevMonitor_Daily_Snapshot_$stamp.png")
        FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
        bitmap.recycle()
        return file
    }

    private fun createPdf(context: Context, d: DashboardSummary, stamp: String): File {
        val doc = PdfDocument()
        val page = doc.startPage(PdfDocument.PageInfo.Builder(612, 792, 1).create())
        val canvas = page.canvas
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF12233A.toInt(); textSize = 14f }
        val bold = Paint(paint).apply { typeface = Typeface.DEFAULT_BOLD }
        canvas.drawText("DevMonitor — Daily Operational Snapshot", 36f, 48f, bold.apply { textSize = 20f; color = 0xFF00843D.toInt() })
        canvas.drawText("Date: ${d.date}", 36f, 72f, paint)
        val lines = listOf(
            "Devices observed: ${d.deviceCount}", "Today's SIMReg: ${d.todayTotal}", "MTD SIMReg: ${d.mtdTotal}",
            "Active: ${d.activeTotal}", "Bar 48: ${d.bar48Total}", "Bar 96: ${d.bar96Total}",
            "Company today / MTD: ${d.companyToday} / ${d.companyMtd}",
            "Partner today / MTD: ${d.partnerToday} / ${d.partnerMtd}", "Active flags: ${d.flags.size}"
        )
        var y = 110f
        lines.forEach { canvas.drawText(it, 42f, y, paint); y += 25f }
        y += 12f
        canvas.drawText("Exceptions", 36f, y, bold.apply { textSize = 16f; color = 0xFFD14B5B.toInt() }); y += 25f
        d.flags.take(14).forEach { flag ->
            val text = "${flag.code} — ${flag.reason}"
            canvas.drawText(text.take(92), 42f, y, paint.apply { textSize = 10f; color = 0xFF40546A.toInt() }); y += 17f
            if (y > 750f) return@forEach
        }
        doc.finishPage(page)
        val file = File(context.cacheDir, "DevMonitor_Daily_Snapshot_$stamp.pdf")
        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
        return file
    }
}

enum class SnapshotFormat { IMAGE, PDF }
