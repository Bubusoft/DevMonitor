package com.aziitech.simregmonitor

/**
 * Incremental feature boundary for the modular-architecture milestone.
 * MainActivity can continue hosting legacy flows while new feature surfaces
 * are registered here and migrated one at a time without changing behaviour.
 */
object FeatureModuleRegistry {
    data class Module(val id: String, val title: String, val refreshDriven: Boolean)
    val modules = listOf(
        Module("next_level", "Next Level Centre", true),
        Module("payments", "Payments", true),
        Module("month_on_month", "Month-on-Month", true),
        Module("device_monitor", "Device Monitor", true),
        Module("reports", "Reports", true),
        Module("settings", "Settings", false)
    )
}
