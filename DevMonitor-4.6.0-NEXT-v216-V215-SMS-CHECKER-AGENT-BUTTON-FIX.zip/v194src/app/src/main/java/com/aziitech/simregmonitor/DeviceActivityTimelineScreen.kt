package com.aziitech.simregmonitor

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private data class TimelineEvent(
    val timestamp: Long,
    val kind: String,
    val title: String,
    val detail: String,
    val accent: androidx.compose.ui.graphics.Color
)

private fun timelineDate(timestamp: Long): String =
    SimpleDateFormat("dd MMM yyyy • HH:mm", Locale.getDefault()).format(Date(timestamp))

@Composable
fun DeviceActivityTimelineDialog(
    store: DatabaseStore,
    deviceCodes: List<String>,
    onDismiss: () -> Unit
) {
    val available = remember(deviceCodes) { deviceCodes.map(::canonicalDeviceCode).filter { it.isNotBlank() }.distinct().sorted() }
    var selectedCode by remember(available) { mutableStateOf(available.firstOrNull().orEmpty()) }
    var expanded by remember { mutableStateOf(false) }
    var events by remember(selectedCode) { mutableStateOf(emptyList<TimelineEvent>()) }
    var loading by remember(selectedCode) { mutableStateOf(false) }

    fun refresh() {
        if (selectedCode.isBlank()) { events = emptyList(); return }
        loading = true
        val observations = store.observationsForCode(selectedCode, 60)
        val history = store.loadHistoryForCode(selectedCode, 120)
        val tasks = store.operationalTasks(true).filter { it.linkType == "DEVICE" && canonicalDeviceCode(it.linkValue.orEmpty()) == selectedCode }
        val notes = store.operationalNotes(false).filter { it.linkType == "DEVICE" && canonicalDeviceCode(it.linkValue.orEmpty()) == selectedCode }
        events = buildList {
            observations.forEach { o ->
                val stamp = runCatching { java.time.LocalDate.parse(o.date).atStartOfDay(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli() }.getOrDefault(System.currentTimeMillis())
                add(TimelineEvent(stamp, "OBSERVATION", "SIMReg observation", "Today ${o.today ?: "-"} • MTD ${o.mtd ?: "-"} • Active ${o.active ?: "-"} • Bar48 ${o.bar48 ?: "-"}", AuroraBlue))
            }
            history.forEach { h ->
                val r = h.record
                add(TimelineEvent(h.completedAt, "QUERY", "Device query: ${r.status}", "Attempt ${r.attempt} • responses ${r.responseCount} • Today ${r.result?.today ?: "-"} • MTD ${r.result?.mtd ?: "-"}", AuroraCyan))
            }
            tasks.forEach { t ->
                add(TimelineEvent(t.updatedAt, "TASK", if (t.completed) "Task completed" else "Task updated", "${t.title}${t.dueDate?.let { " • Due $it" } ?: ""}", AuroraGreen))
            }
            notes.forEach { n ->
                add(TimelineEvent(n.updatedAt, "NOTE", "Note updated", n.title.ifBlank { n.body.take(120) }, AuroraViolet))
            }
        }.sortedByDescending { it.timestamp }
        loading = false
    }

    LaunchedEffect(selectedCode) { refresh() }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Device Activity Timeline") },
        text = {
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (available.isEmpty()) {
                    Text("No devices are currently available for a timeline.")
                } else {
                    Box {
                        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
                            Text(selectedCode.ifBlank { "Choose device" })
                        }
                        DropdownMenu(expanded, { expanded = false }) {
                            available.forEach { code ->
                                DropdownMenuItem(text = { Text(code) }, onClick = { selectedCode = code; expanded = false })
                            }
                        }
                    }
                    if (loading) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                            Text("Loading activity…")
                        }
                    } else if (events.isEmpty()) {
                        Text("No recorded activity yet for $selectedCode.")
                    } else {
                        LazyColumn(Modifier.heightIn(max = 500.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(events) { event ->
                                ElevatedCard(Modifier.fillMaxWidth()) {
                                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.Top) {
                                        Surface(color = event.accent.copy(alpha = 0.12f), shape = MaterialTheme.shapes.small) {
                                            Text(event.kind, modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = event.accent)
                                        }
                                        Spacer(Modifier.width(9.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(event.title, fontWeight = FontWeight.Bold)
                                            Text(timelineDate(event.timestamp), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            Spacer(Modifier.height(3.dp))
                                            Text(event.detail, style = MaterialTheme.typography.bodySmall)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}
