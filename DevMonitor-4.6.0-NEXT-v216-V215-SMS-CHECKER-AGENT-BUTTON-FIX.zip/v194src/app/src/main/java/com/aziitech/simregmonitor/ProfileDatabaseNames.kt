package com.aziitech.simregmonitor

/** Stable database naming for profile-owned operational data. */
object ProfileDatabaseNames {
    const val LEGACY_DATABASE = "simreg_monitor.db"

    fun deviceMonitor(profileId: String): String {
        val safe = profileId.filter { it.isLetterOrDigit() }.take(24).ifBlank { "profile" }
        return "device_monitor_profile_$safe.db"
    }
}
