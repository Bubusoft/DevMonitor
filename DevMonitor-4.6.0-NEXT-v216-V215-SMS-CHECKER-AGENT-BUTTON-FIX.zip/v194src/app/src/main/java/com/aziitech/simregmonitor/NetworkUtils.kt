package com.aziitech.simregmonitor

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities

/** Small shared guard for user actions that require a live Internet connection. */
object NetworkUtils {
    fun hasActiveInternet(context: Context): Boolean {
        val manager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return false
        val network = manager.activeNetwork ?: return false
        val capabilities = manager.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    const val OFFLINE_MESSAGE = "Internet connection required. Please turn on Wi-Fi or mobile data and try again."
}
