package com.aziitech.simregmonitor

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.delay

/** Tracks optional carrier/SMS app sent and delivered callbacks. */
object SmsDeliveryTracker {
    data class Status(
        @Volatile var sentKnown: Boolean = false,
        @Volatile var sentOk: Boolean = false,
        @Volatile var deliveredKnown: Boolean = false,
        @Volatile var deliveredOk: Boolean = false
    )

    private val statuses = ConcurrentHashMap<String, Status>()

    fun begin(): String {
        val token = UUID.randomUUID().toString()
        statuses[token] = Status()
        return token
    }

    fun updateSent(token: String, ok: Boolean) {
        statuses[token]?.apply { sentKnown = true; sentOk = ok }
    }

    fun updateDelivered(token: String, ok: Boolean) {
        statuses[token]?.apply { deliveredKnown = true; deliveredOk = ok }
    }

    suspend fun await(token: String, timeoutMs: Long): Status {
        val start = System.currentTimeMillis()
        while (System.currentTimeMillis() - start < timeoutMs) {
            val status = statuses[token] ?: return Status()
            if ((status.sentKnown && !status.sentOk) || (status.deliveredKnown && !status.deliveredOk)) return status
            if (status.deliveredKnown && status.deliveredOk) return status
            if (status.sentKnown && status.sentOk && !status.deliveredKnown) {
                delay(250)
            } else {
                delay(200)
            }
        }
        return statuses[token] ?: Status()
    }

    fun remove(token: String) { statuses.remove(token) }
}

class SmsDeliveryReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val token = intent?.getStringExtra(EXTRA_TOKEN) ?: return
        when (intent.action) {
            ACTION_SENT -> SmsDeliveryTracker.updateSent(token, resultCode == Activity.RESULT_OK)
            ACTION_DELIVERED -> SmsDeliveryTracker.updateDelivered(token, resultCode == Activity.RESULT_OK)
        }
    }

    companion object {
        const val ACTION_SENT = "com.aziitech.simregmonitor.SMS_SENT"
        const val ACTION_DELIVERED = "com.aziitech.simregmonitor.SMS_DELIVERED"
        const val EXTRA_TOKEN = "delivery_token"
    }
}
