package com.aziitech.simregmonitor

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Telephony
import androidx.core.content.ContextCompat

object SmsInbox {
    data class ReceivedSms(val sender: String, val body: String, val receivedAt: Long, val id: Long)

    fun add(context: Context, sender: String, body: String, receivedAt: Long): ReceivedSms {
        val store = StateStore(context.applicationContext)
        val id = store.addSms(sender, body, receivedAt)
        return ReceivedSms(sender, body, receivedAt, id)
    }

    fun after(context: Context, id: Long): List<ReceivedSms> = StateStore(context.applicationContext).smsAfter(id)
    fun all(context: Context): List<ReceivedSms> = StateStore(context.applicationContext).allSms()
    fun latestId(context: Context): Long = StateStore(context.applicationContext).latestSmsId()

    /** Reads the real Android SMS inbox. This is intentionally separate from DevMonitor's
     * local capture table so recovery also works when the app was killed. */
    fun systemInbox(context: Context, since: Long = 0L): List<ReceivedSms> {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) return emptyList()
        val out = mutableListOf<ReceivedSms>()
        runCatching {
            context.contentResolver.query(
                Telephony.Sms.Inbox.CONTENT_URI,
                arrayOf(Telephony.Sms._ID, Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE),
                "${Telephony.Sms.DATE} >= ?",
                arrayOf(since.toString()),
                "${Telephony.Sms.DATE} ASC"
            )?.use { c ->
                val idCol = c.getColumnIndexOrThrow(Telephony.Sms._ID)
                val addressCol = c.getColumnIndexOrThrow(Telephony.Sms.ADDRESS)
                val bodyCol = c.getColumnIndexOrThrow(Telephony.Sms.BODY)
                val dateCol = c.getColumnIndexOrThrow(Telephony.Sms.DATE)
                while (c.moveToNext()) out.add(ReceivedSms(c.getString(addressCol) ?: "", c.getString(bodyCol) ?: "", c.getLong(dateCol), c.getLong(idCol)))
            }
        }
        return out
    }
}

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return
        val sender = messages.firstOrNull()?.displayOriginatingAddress ?: return
        val body = messages.joinToString("\n") { it.messageBody ?: "" }
        SmsInbox.add(context.applicationContext, sender, body, System.currentTimeMillis())
    }
}
