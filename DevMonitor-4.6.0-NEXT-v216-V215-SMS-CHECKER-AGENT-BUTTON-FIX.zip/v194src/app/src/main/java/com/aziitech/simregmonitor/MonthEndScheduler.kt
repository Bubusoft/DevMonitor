package com.aziitech.simregmonitor

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * DevMonitor performance policy: heavy operational work is user initiated.
 * This compatibility class deliberately does not schedule background monitoring.
 * Month-end prompting is handled in the dashboard as a lightweight, user-facing
 * reminder; this class only cancels legacy alarms left by older app versions.
 */
object MonthEndScheduler {
    private const val ACTION = "com.aziitech.simregmonitor.MONTH_END_CHECK"

    fun schedule(context: Context) = cancel(context)

    fun cancel(context: Context) {
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, MonthEndReceiver::class.java).setAction(ACTION)
        val pending = PendingIntent.getBroadcast(
            context, 7711, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarm.cancel(pending)
        pending.cancel()
    }
}

class MonthEndReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        // Intentionally inert. Legacy alarms are cancelled by DevMonitor.
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED || intent?.action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            MonthEndScheduler.cancel(context)
        }
    }
}
