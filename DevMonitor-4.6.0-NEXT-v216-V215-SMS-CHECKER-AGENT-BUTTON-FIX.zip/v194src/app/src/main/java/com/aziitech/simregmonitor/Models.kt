package com.aziitech.simregmonitor

import java.time.LocalDate

data class QueryItem(val code: String, val type: QueryType = QueryType.from(code))

/**
 * Returns the stable device identity used by DevMonitor for GLO device codes.
 * 3030 identifies a GLO device by its final device token, so long hierarchical
 * forms and their short forms must share one daily identity. Non-GLO codes are
 * intentionally left unchanged.
 */
fun canonicalDeviceCode(code: String): String {
    val clean = code.trim().uppercase(java.util.Locale.US)
    val match = Regex("^(GLO-(?:GD|DD|FD))-(?:.+)-([A-Z0-9]+)$").matchEntire(clean)
    return if (match != null) "${match.groupValues[1]}-${match.groupValues[2]}" else clean
}

enum class QueryType {
    DEVICE, PARTNER, UNKNOWN;
    companion object {
        fun from(code: String): QueryType = when {
            code.matches(Regex("GLO-(GD|DD|FD)-.*", RegexOption.IGNORE_CASE)) -> DEVICE
            code.trim().isNotEmpty() -> PARTNER
            else -> UNKNOWN
        }
    }
}

enum class Ownership { COMPANY, PARTNER, UNKNOWN;
    companion object {
        fun from(code: String): Ownership = when {
            code.matches(Regex("GLO-GD-.*", RegexOption.IGNORE_CASE)) -> COMPANY
            code.matches(Regex("GLO-(DD|FD)-.*", RegexOption.IGNORE_CASE)) -> PARTNER
            else -> if (QueryType.from(code) == QueryType.PARTNER) Ownership.PARTNER else UNKNOWN
        }
    }
}

enum class AttemptStatus { QUEUED, SENDING, WAITING, SUCCESS, NOT_FOUND, TIMEOUT, SEND_FAILED, UNRECOGNIZED }

data class SimRegResult(
    val code: String,
    val type: QueryType,
    val receivedAt: String,
    val today: Int?,
    val mtd: Int?,
    val active: Int?,
    val bar48: Int?,
    val bar96: Int?,
    val duplicates: Int?,
    val monthlyTarget: Int?,
    val status: AttemptStatus,
    val raw: String
)

data class QueryRecord(
    val code: String,
    val type: QueryType,
    val attempt: Int,
    val repetitionsSent: Int,
    val responseCount: Int = 0,
    val status: AttemptStatus,
    val result: SimRegResult? = null,
    val error: String? = null,
    val firstAttemptStatus: AttemptStatus? = null,
    val completedAt: Long = System.currentTimeMillis()
)

data class SavedQueryList(val name: String, val codes: List<String>)
data class ZeroDeviceCandidate(
    val code: String,
    val previousMonth: String,
    val currentActivity: Int,
    val source: String
)
data class DailyObservation(
    val code: String, val date: String, val ownership: Ownership,
    val today: Int?, val mtd: Int?, val active: Int?, val bar48: Int?, val bar96: Int?,
    val duplicates: Int?, val monthlyTarget: Int?, val receivedAt: String
)
data class DeviceFlag(val code: String, val ownership: Ownership, val severity: String, val reason: String, val date: String)
data class TrendPoint(
    val date: String,
    val sales: Int,
    val active: Int,
    val bar48: Int,
    val companySales: Int,
    val partnerSales: Int,
    val observedDevices: Int
)

data class DashboardSummary(
    val date: String, val month: String, val deviceCount: Int,
    val todayTotal: Int, val mtdTotal: Int, val activeTotal: Int, val bar48Total: Int, val bar96Total: Int,
    val companyToday: Int, val companyMtd: Int, val partnerToday: Int, val partnerMtd: Int,
    val flags: List<DeviceFlag>
)


data class Agent(
    val id: Long, val name: String, val address: String, val latitude: Double?, val longitude: Double?,
    val createdAt: Long, val updatedAt: Long
)
data class AgentPhone(val id: Long, val agentId: Long, val phone: String, val label: String)
data class PaymentCycle(
    val id: Long, val startDate: String, val endDate: String, val label: String, val mode: String, val closed: Boolean
)
data class PaymentRecord(
    val id: Long, val cycleId: Long, val code: String, val agentId: Long?, val ownership: Ownership,
    val mtd: Int?, val today: Int?, val active: Int?, val bar48: Int?, val bar96: Int?,
    val snapshotDate: String, val amount: Double?, val paid: Boolean, val notes: String?
)


data class OperationalTask(
    val id: Long, val title: String, val details: String, val dueDate: String?,
    val priority: String, val linkType: String?, val linkValue: String?,
    val completed: Boolean, val createdAt: Long, val updatedAt: Long
)

data class OperationalNote(
    val id: Long, val title: String, val body: String,
    val linkType: String?, val linkValue: String?, val pinned: Boolean,
    val createdAt: Long, val updatedAt: Long
)
