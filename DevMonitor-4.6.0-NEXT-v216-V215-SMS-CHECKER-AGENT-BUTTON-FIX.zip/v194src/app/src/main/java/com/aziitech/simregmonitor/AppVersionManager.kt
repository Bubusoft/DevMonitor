package com.aziitech.simregmonitor

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await
import java.util.Locale

/** Central version-awareness for feature/resource compatibility and update prompts. */
class AppVersionManager(private val context: Context) {
    data class UpdateInfo(
        val latestVersionName: String,
        val latestVersionCode: Long,
        val minimumVersionName: String,
        val minimumVersionCode: Long,
        val updateUrl: String,
        val reason: String = ""
    )

    private data class VersionNumber(val parts: List<Int>) : Comparable<VersionNumber> {
        override fun compareTo(other: VersionNumber): Int {
            val size = maxOf(parts.size, other.parts.size)
            for (i in 0 until size) {
                val a = parts.getOrElse(i) { 0 }
                val b = other.parts.getOrElse(i) { 0 }
                if (a != b) return a.compareTo(b)
            }
            return 0
        }
    }

    private fun parseVersion(value: String): VersionNumber {
        val parts = value.trim().split('.', '-', '_')
            .mapNotNull { it.toIntOrNull() }
            .ifEmpty { listOf(0) }
        return VersionNumber(parts)
    }

    private fun currentCode(): Long = BuildConfig.VERSION_CODE.toLong()
    private fun currentName(): String = BuildConfig.VERSION_NAME

    suspend fun checkFeature(featureKey: String, localRequiredVersionCode: Long = 0L): UpdateInfo? {
        val snapshot = runCatching {
            FirebaseFirestore.getInstance()
                .collection("app_config")
                .document("devmonitor_version")
                .get()
                .await()
        }.getOrNull() ?: return null

        val data = snapshot.data ?: return null
        val features = data["features"] as? Map<*, *>
        val feature = features?.get(featureKey) as? Map<*, *>
        val remoteRequiredCode = (feature?.get("minimumVersionCode") as? Number)?.toLong() ?: 0L
        val remoteRequiredName = feature?.get("minimumVersionName")?.toString().orEmpty()
        val requiredCode = maxOf(localRequiredVersionCode, remoteRequiredCode)
        val requiredName = if (remoteRequiredName.isNotBlank()) remoteRequiredName else BuildConfig.VERSION_NAME

        val needsUpdate = requiredCode > currentCode() ||
            (requiredCode == 0L && parseVersion(requiredName) > parseVersion(currentName()))
        if (!needsUpdate) return null

        val latestName = data["latestVersionName"]?.toString().orEmpty().ifBlank { requiredName }
        val latestCode = (data["latestVersionCode"] as? Number)?.toLong() ?: requiredCode
        val url = data["updateUrl"]?.toString().orEmpty()
        return UpdateInfo(latestName, latestCode, requiredName, requiredCode, url, feature?.get("reason")?.toString().orEmpty())
    }

    suspend fun checkRequiredUpdate(): UpdateInfo? {
        val snapshot = runCatching {
            FirebaseFirestore.getInstance()
                .collection("app_config")
                .document("devmonitor_version")
                .get()
                .await()
        }.getOrNull() ?: return null

        val data = snapshot.data ?: return null
        val minimumCode = (data["minimumVersionCode"] as? Number)?.toLong() ?: 0L
        val minimumName = data["minimumVersionName"]?.toString().orEmpty()
        val needsUpdate = minimumCode > currentCode() ||
            (minimumCode == 0L && minimumName.isNotBlank() && parseVersion(minimumName) > parseVersion(currentName()))
        if (!needsUpdate) return null

        val latestName = data["latestVersionName"]?.toString().orEmpty().ifBlank { minimumName }
        val latestCode = (data["latestVersionCode"] as? Number)?.toLong() ?: minimumCode
        return UpdateInfo(
            latestVersionName = latestName,
            latestVersionCode = latestCode,
            minimumVersionName = minimumName.ifBlank { latestName },
            minimumVersionCode = minimumCode,
            updateUrl = data["updateUrl"]?.toString().orEmpty(),
            reason = data["reason"]?.toString().orEmpty()
        )
    }

    fun openUpdate(context: Context, updateUrl: String) {
        val fallback = "https://play.google.com/store/apps/details?id=${context.packageName}"
        val uri = updateUrl.trim().ifBlank { fallback }
        runCatching {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(uri)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }.onFailure {
            if (uri != fallback) {
                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(fallback)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
    }
}
