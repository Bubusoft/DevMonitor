package com.aziitech.simregmonitor

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStream
import java.util.Locale

/**
 * Lightweight company identity map used before an activation report is loaded.
 * It contains identifiers and organisational relationships only — never daily
 * activations, MTD, Active, Bar48/96 or payment values.
 */
data class CompanySkeletonRecord(
    val sn: String,
    val tradeCode: String,
    val partnerName: String,
    val deviceId: String,
    val cluster: String,
    val division: String,
    val region: String,
    val territory: String,
    val staffName: String
)

class CompanySkeletonStore(private val context: Context) {
    companion object { private const val PREFS = "devmonitor_company_skeleton"; private const val KEY = "records_v1" }
    private val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    @Volatile private var cached: List<CompanySkeletonRecord>? = null

    fun hasData(): Boolean = cached != null || !prefs.getString(KEY, null).isNullOrBlank() || runCatching { context.assets.list("")?.contains("company_skeleton.json") == true }.getOrDefault(false)

    fun records(): List<CompanySkeletonRecord> {
        cached?.let { return it }
        val stored = prefs.getString(KEY, null)
        val value = if (!stored.isNullOrBlank()) decode(JSONArray(stored)) else loadEmbedded()
        cached = value
        return value
    }

    fun replaceFromReport(report: SimRegReport): Int {
        val seen = LinkedHashSet<String>()
        val rows = report.rows.mapNotNull { row ->
            val id = row.deviceId.trim()
            if (id.isBlank() || !seen.add(id.uppercase(Locale.US))) null else CompanySkeletonRecord(
                sn = "", tradeCode = row.tradeCode.trim(), partnerName = row.partnerName.trim(),
                deviceId = id, cluster = row.cluster.trim(), division = row.division.trim(),
                region = row.region.trim(), territory = row.territory.trim(), staffName = row.staffName.trim()
            )
        }
        prefs.edit().putString(KEY, encode(rows)).apply()
        cached = rows
        return rows.size
    }

    fun search(query: String, limit: Int = 40): List<CompanySkeletonRecord> {
        val q = query.trim().uppercase(Locale.US)
        if (q.isBlank()) return emptyList()
        return records().asSequence().filter {
            listOf(it.tradeCode, it.partnerName, it.deviceId, it.cluster, it.division, it.region, it.territory, it.staffName)
                .any { value -> value.uppercase(Locale.US).contains(q) }
        }.take(limit).toList()
    }

    /** Source-data option normalisation is display-only: the original workbook values are retained in records.
     * Case/typographic variants such as AFIKPO/Afikpo or JAMA'A/JAMA’A therefore appear once in selectors
     * while searches and stored records continue to use the source values.
     */
    private fun optionKey(value: String): String = value.trim()
        .replace('’', '\'')
        .replace('‘', '\'')
        .uppercase(Locale.US)

    private fun distinctOptions(values: Sequence<String>): List<String> = values
        .map { it.trim() }
        .filter { it.isNotBlank() }
        .groupBy { optionKey(it) }
        .values
        .map { group -> group.minWithOrNull(compareBy<String>({ it.uppercase(Locale.US) }, { it })) ?: group.first() }
        .sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it })

    fun divisions(): List<String> = distinctOptions(records().asSequence().map { it.division })
    fun regions(division: String = ""): List<String> = distinctOptions(records().asSequence()
        .filter { division.isBlank() || it.division.equals(division, true) }
        .map { it.region })
    fun territories(division: String = "", region: String = ""): List<String> = distinctOptions(records().asSequence()
        .filter { division.isBlank() || it.division.equals(division, true) }
        .filter { region.isBlank() || it.region.equals(region, true) }
        .map { it.territory })
    fun staff(division: String = "", region: String = "", territory: String = ""): List<String> = distinctOptions(records().asSequence()
        .filter { division.isBlank() || it.division.equals(division, true) }
        .filter { region.isBlank() || it.region.equals(region, true) }
        .filter { territory.isBlank() || it.territory.equals(territory, true) }
        .map { it.staffName })

    private fun loadEmbedded(): List<CompanySkeletonRecord> = runCatching {
        context.assets.open("company_skeleton.json").use { decode(JSONObject(String(it.readBytes(), Charsets.UTF_8)).getJSONArray("records")) }
    }.getOrDefault(emptyList())

    private fun encode(rows: List<CompanySkeletonRecord>) = JSONArray().apply { rows.forEach { put(JSONObject().apply {
        put("sn", it.sn); put("trade_code", it.tradeCode); put("partner_name", it.partnerName); put("device_id", it.deviceId)
        put("cluster", it.cluster); put("division", it.division); put("region", it.region); put("territory", it.territory); put("staff_name", it.staffName)
    }) } }.toString()

    private fun decode(a: JSONArray): List<CompanySkeletonRecord> = buildList {
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            add(CompanySkeletonRecord(
                o.optString("sn"), o.optString("trade_code"), o.optString("partner_name"), o.optString("device_id"),
                o.optString("cluster"), o.optString("division"), o.optString("region"), o.optString("territory"), o.optString("staff_name")
            ))
        }
    }
}
