package com.aziitech.simregmonitor
import android.content.Context
import android.net.Uri
import android.util.Xml
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import org.xmlpull.v1.XmlPullParser

enum class ReportExportMode { QUICK, DETAILED, PAYMENT, EXCEPTIONS, HQ, FULL }

object XlsxUtil {
    private val headerValues = setOf("CODE", "PARTNER CODE", "DEVICE CODE", "DEVICE / PARTNER CODE")
    fun readCodes(context: Context, uri: Uri): List<String> {
        return runCatching {
            context.contentResolver.openInputStream(uri)?.use { readCodes(it) } ?: emptyList()
        }.getOrDefault(emptyList())
    }
    fun readCodes(input:InputStream):List<String>{val e=linkedMapOf<String,ByteArray>();ZipInputStream(input.buffered()).use{z->while(true){val x=z.nextEntry?:break;if(!x.isDirectory)e[x.name]=z.readBytes()}};val shared=e["xl/sharedStrings.xml"]?.let(::readSharedStrings)?:emptyList();val sheet=e.keys.firstOrNull{it.startsWith("xl/worksheets/")&&it.endsWith(".xml")}?:return emptyList();return parseSheet(e[sheet]?:return emptyList(),shared).map{it.trim().uppercase()}.filter{it.isNotBlank()}.filterNot{headerValues.contains(it)}.map(::canonicalDeviceCode).distinct()}
    private fun readSharedStrings(bytes:ByteArray):List<String>{val out=mutableListOf<String>();val p=Xml.newPullParser();p.setInput(bytes.inputStream(),"UTF-8");var b=StringBuilder();var t=false;while(p.next()!=XmlPullParser.END_DOCUMENT){when(p.eventType){XmlPullParser.START_TAG->if(p.name=="t"){b=StringBuilder();t=true};XmlPullParser.TEXT->if(t)b.append(p.text);XmlPullParser.END_TAG->if(p.name=="t"&&t){out.add(b.toString());t=false}}};return out}
    private fun parseSheet(bytes:ByteArray,shared:List<String>):List<String>{val out=mutableListOf<String>();val p=Xml.newPullParser();p.setInput(bytes.inputStream(),"UTF-8");var ct="";var inv=false;var int=false;var b=StringBuilder();while(p.next()!=XmlPullParser.END_DOCUMENT){when(p.eventType){XmlPullParser.START_TAG->when(p.name){"c"->ct=p.getAttributeValue(null,"t")?:"";"v"->{b=StringBuilder();inv=true};"t"->if(ct=="inlineStr"){b=StringBuilder();int=true}};XmlPullParser.TEXT->if(inv||int)b.append(p.text);XmlPullParser.END_TAG->when(p.name){"v"->if(inv){val raw=b.toString();out.add(if(ct=="s")shared.getOrNull(raw.toIntOrNull()?:-1).orEmpty() else raw);inv=false};"t"->if(int){out.add(b.toString());int=false};"c"->ct=""}}};return out}
    fun writeReport(
        context: Context,
        uri: Uri,
        codes: List<String>,
        records: Map<String, QueryRecord>,
        dashboard: DashboardSummary,
        deviceMonitorStore: DatabaseStore? = null,
        companyStore: CompanyActivationStore? = null,
        mode: ReportExportMode = ReportExportMode.DETAILED
    ): Boolean {
        return runCatching {
            val output = context.contentResolver.openOutputStream(uri) ?: return false
            output.use { writeReport(it, codes, records, dashboard, deviceMonitorStore, companyStore, mode) }
            true
        }.getOrDefault(false)
    }
    fun writeReport(out:OutputStream,codes:List<String>,records:Map<String,QueryRecord>,dashboard:DashboardSummary,deviceMonitorStore:DatabaseStore? = null,companyStore:CompanyActivationStore? = null,mode:ReportExportMode = ReportExportMode.DETAILED){
        val canonicalRecords = records.entries
            .map { canonicalDeviceCode(it.key) to it.value }
            .groupBy { it.first }
            .mapValues { (_, entries) -> entries.maxByOrNull { it.second.completedAt }?.second }
        val reportCodes = codes.map(::canonicalDeviceCode).distinct()
        val allRows=reportCodes.map{code->
            val r=canonicalRecords[code]
            val x=r?.result
            val current = x?.active
            val progression = if (deviceMonitorStore != null && companyStore != null) {
                PaymentEngine.DeviceMonitor.calculate(code, PaymentRules.currentAwareDate(), deviceMonitorStore, companyStore)
            } else null
            val historical = progression?.baselineActive
            val combined = progression?.activations
            val estimate = progression?.estimate
            code to listOf(code,x?.today?.toString().orEmpty(),x?.mtd?.toString().orEmpty(),current?.toString().orEmpty(),historical?.toString().orEmpty(),combined?.toString().orEmpty(),estimate?.estimatedSubtotal?.toString().orEmpty(),x?.bar48?.toString().orEmpty(),x?.bar96?.toString().orEmpty())
        }
        val flaggedCodes = dashboard.flags.map { canonicalDeviceCode(it.code) }.toSet()
        val rows = when(mode) {
            ReportExportMode.QUICK -> allRows.take(20)
            ReportExportMode.PAYMENT -> allRows.filter { it.second.getOrNull(6)?.isNotBlank() == true }
            ReportExportMode.EXCEPTIONS -> allRows.filter { flaggedCodes.contains(it.first) }
            ReportExportMode.HQ -> allRows.filter { it.first.startsWith("GLO-GD-", true) || it.first.startsWith("GLO-DD-", true) || it.first.startsWith("GLO-FD-", true) }
            else -> allRows
        }.map { it.second }
        ZipOutputStream(out.buffered()).use{z->add(z,"[Content_Types].xml",types());add(z,"_rels/.rels",rootRels());add(z,"xl/workbook.xml",workbook());add(z,"xl/_rels/workbook.xml.rels",rels());add(z,"xl/styles.xml",styles());add(z,"xl/worksheets/sheet1.xml",salesSheet(rows));add(z,"xl/worksheets/sheet2.xml",flagsSheet(dashboard));add(z,"xl/worksheets/sheet3.xml",summarySheet(dashboard))}
    }
    private fun add(z:ZipOutputStream,n:String,s:String){z.putNextEntry(ZipEntry(n));z.write(s.toByteArray(Charsets.UTF_8));z.closeEntry()}
    private fun esc(s:String)=s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&apos;")
    private fun cell(s:String,style:Int=0)=if(s.toIntOrNull()!=null)"<c s=\"$style\"><v>$s</v></c>" else "<c s=\"$style\" t=\"inlineStr\"><is><t>${esc(s)}</t></is></c>"
    private fun formulaCell(f:String,style:Int=0)="<c s=\"$style\"><f>${esc(f)}</f></c>"
    private fun salesSheet(rows:List<List<String>>):String{
        val b=StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>")
        fun row(n:Int,v:List<String>,style:Int=0){b.append("<row r=\"$n\">");v.forEach{b.append(cell(it,style))};b.append("</row>")}
        row(1,listOf("Device / Partner Code","Today","MTD","Active (SMS)","Historical 21st–Month-End","Device Monitor Total","Estimated Earnings","Bar 48","Bar 96"),1)
        rows.forEachIndexed{i,r->row(i+2,r)}
        val n=rows.size+2
        b.append("<row r=\"$n\">")
        b.append(cell("TOTAL",2))
        b.append(formulaCell("SUM(B2:B${n-1})",2));b.append(formulaCell("SUM(C2:C${n-1})",2));b.append(formulaCell("SUM(D2:D${n-1})",2));b.append(formulaCell("SUM(E2:E${n-1})",2));b.append(formulaCell("SUM(F2:F${n-1})",2));b.append("</row>")
        return b.append("</sheetData></worksheet>").toString()
    }
    private fun flagsSheet(d:DashboardSummary):String{
        val b=StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>")
        fun r(n:Int,v:List<String>,style:Int=0){b.append("<row r=\"$n\">");v.forEach{b.append(cell(it,style))};b.append("</row>")}
        r(1,listOf("Code","Ownership","Severity","Reason","Date"),1)
        d.flags.forEachIndexed{i,f->r(i+2,listOf(f.code,f.ownership.name,f.severity,f.reason,f.date))}
        return b.append("</sheetData></worksheet>").toString()
    }
    private fun summarySheet(d:DashboardSummary)=sheetStyled(listOf(listOf("Date","Month","Devices","Today Total","MTD Total","Active Total","Bar48 Total","Bar96 Total","Company Today","Company MTD","Partner Today","Partner MTD"),listOf(d.date,d.month,d.deviceCount.toString(),d.todayTotal.toString(),d.mtdTotal.toString(),d.activeTotal.toString(),d.bar48Total.toString(),d.bar96Total.toString(),d.companyToday.toString(),d.companyMtd.toString(),d.partnerToday.toString(),d.partnerMtd.toString())))
    private fun sheetStyled(rows:List<List<String>>):String{val b=StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>");rows.forEachIndexed { i,v -> b.append("<row r=\"${i+1}\">");v.forEach{b.append(cell(it,if(i==0)1 else 0))};b.append("</row>")};return b.append("</sheetData></worksheet>").toString()}
    private fun types()="""<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet3.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>"""
    private fun rootRels()="""<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>"""
    private fun workbook()="""<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Sales Report" sheetId="1" r:id="rId1"/><sheet name="Flags" sheetId="2" r:id="rId2"/><sheet name="Summary" sheetId="3" r:id="rId3"/></sheets></workbook>"""
    private fun rels()="""<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet3.xml"/><Relationship Id="rId4" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>"""
    private fun styles()="""<?xml version="1.0" encoding="UTF-8"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><color rgb="FFFFFFFF"/><sz val="11"/><name val="Calibri"/></font></fonts><fills count="4"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF00843D"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFB7F2CB"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="1"><border/></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="3"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" applyFont="1" applyFill="1"/><xf numFmtId="0" fontId="0" fillId="3" borderId="0" applyFill="1"/></cellXfs></styleSheet>"""
}
