package com.aziitech.simregmonitor

import android.util.Log
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList

/** Lightweight diagnostics for Android Logcat and the in-app Log viewer. */
object DevMonitorLogger {
    private const val PREFIX = "DevMonitor"
    private const val MAX_ENTRIES = 400
    private val entries = CopyOnWriteArrayList<String>()
    private val timeFormat = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    private fun add(level: String, tag: String, message: String) {
        val line = "${timeFormat.format(Date())}  $level  [$PREFIX-$tag]  $message"
        entries.add(line)
        while (entries.size > MAX_ENTRIES) entries.removeAt(0)
    }

    fun import(message: String) {
        add("D", "IMPORT", message)
        Log.d("$PREFIX-IMPORT", message)
    }

    fun db(message: String) {
        add("D", "DB", message)
        Log.d("$PREFIX-DB", message)
    }

    fun screen(message: String) {
        add("D", "SCREEN", message)
        Log.d("$PREFIX-SCREEN", message)
    }

    fun payment(message: String) {
        add("D", "PAYMENT", message)
        Log.d("$PREFIX-PAYMENT", message)
    }

    fun error(tag: String, message: String, throwable: Throwable? = null) {
        add("E", tag, if (throwable == null) message else "$message | ${throwable::class.simpleName}: ${throwable.message}")
        if (throwable == null) Log.e("$PREFIX-$tag", message)
        else Log.e("$PREFIX-$tag", message, throwable)
    }

    fun snapshot(): List<String> = entries.toList()

    fun clear() {
        entries.clear()
    }
}
