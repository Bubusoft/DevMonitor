# SIMReg Monitor intentionally keeps release shrinking disabled for predictable mobile builds.
