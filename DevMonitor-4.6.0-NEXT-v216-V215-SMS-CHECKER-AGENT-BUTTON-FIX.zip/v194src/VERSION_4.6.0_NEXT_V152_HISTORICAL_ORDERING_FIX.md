# DevMonitor 4.6.0-NEXT v152 — Historical Report Ordering & Viewer Fallback

## Fixes

- A valid previous-month report can now be accepted after a current-month report without the current month blocking the historical import.
- Late previous-month imports refresh the physical Previous Month My Devices snapshot from the corresponding Previous Month Full store.
- The four Month-on-Month databases remain physically separate: Previous Full, Previous My Devices, Current Full, Current My Devices.
- A locked full-month previous snapshot remains authoritative; later partial reports cannot roll it backwards.
- The rolling report table now prefers the current month when current-month normalized data exists.
- If current-month data does not exist, the table displays the newest month actually present in normalized activation data.
- When current-month data later arrives, the viewer automatically returns to the current month.
- Viewer fallback is display-only and does not copy historical data into the current database.

## Signing / release configuration

The existing release configuration is preserved for later release builds, but this version remains a debug-development build. No release signing key is included in the ZIP.

- Package: `com.aziitech.simregmonitor`
- Release keystore file name: `fieldpulse-release.jks`
- Release alias: `fieldpulse-release`
- Release SHA-1: `8A:C3:1B:96:52:7D:F8:96:83:D5:84:A6:D5:99:10:0D:88:5D:F5:36`
- Firebase project: `fieldpulse-b3eb3`

Secrets/passwords are not stored in the project ZIP.
