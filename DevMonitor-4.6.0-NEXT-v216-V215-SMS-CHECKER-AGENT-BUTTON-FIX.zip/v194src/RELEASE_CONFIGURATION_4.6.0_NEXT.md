# DevMonitor / FieldPulse 4.6.0-NEXT Release Configuration

## Fixed release identity

- Application ID: `com.aziitech.simregmonitor`
- Release keystore filename: `fieldpulse-release.jks`
- Release alias: `fieldpulse-release`
- Release SHA-1: `8A:C3:1B:96:52:7D:F8:96:83:D5:84:A6:D5:99:10:0D:88:5D:F5:36`
- Firebase project: `fieldpulse-b3eb3`
- Google Drive report folder: `1d2mCmBiFgQXjIYHAvgjXAD_JgSvITbwI`

The keystore, passwords, and Drive API key are never stored in this ZIP. They must be injected by the cloud build as GitHub Actions secrets.

## GitHub Actions secrets expected

- `FIELD_PULSE_RELEASE_KEYSTORE_BASE64` — base64 contents of `fieldpulse-release.jks`
- `RELEASE_STORE_PASSWORD`
- `RELEASE_KEY_PASSWORD`
- `RELEASE_KEY_ALIAS` (may be set to `fieldpulse-release`)
- `DRIVE_REPORT_API_KEY`

## Firebase note

The checked-in `app/google-services.json` identifies the correct Firebase project and Android package. Its currently embedded Android OAuth certificate hash is the older debug certificate. The Firebase console must also register the release SHA-1 above for `com.aziitech.simregmonitor`, after which Firebase should generate a refreshed `google-services.json`.

Do not manually invent an OAuth certificate entry in `google-services.json`; use the Firebase-generated file.

## Build artifact

This release train uses version name `4.6.0-NEXT` and development version code `161`. The cloud workflow produces:

`DevMonitor-4.6.0-NEXT-v161-release.apk`

The workflow also verifies the APK's actual signing SHA-1 against the fixed release certificate.
