# DevMonitor 4.4.4 — Multi-Profile Workspaces

## Purpose
Users can maintain more than one named **Check My Devices** profile when they genuinely operate multiple accounts, regions/divisions, partner accounts, or both staff and partner scopes.

## Behavior
- The first existing My Devices setup is automatically migrated into the first/default profile.
- A compact row of named profile cards appears below the app header.
- Tapping a profile card switches the active Check My Devices workspace.
- The `+` card creates another named profile.
- A new profile is configured through the existing My Devices profile form.
- Each profile stores its own name, phone, user type, staff level, partner code/device ID, division, region, staff name, territory, and device list.
- Each profile has its own My Devices SQLite working database, preventing one profile's working data from leaking into another profile.
- Global Device Monitor observations/history remain shared; profile switching changes the active user/device scope rather than deleting global monitoring history.
- The existing first-time `Check My Devices` journey still opens profile setup when no profile exists.
- Editing the active profile updates that profile only.
- Switching profiles clears stale Month-on-Month/payment-card presentation state so the newly selected profile does not inherit the previous profile's displayed result.

## Protected behavior
- SMS sending and SIM selection are unchanged.
- Device Monitor global observation/history remains unchanged.
- Payment calculation/resolver/rules are unchanged.
- Month-on-Month isolated data architecture remains unchanged; profile-scoped current device lists continue to feed the existing My Devices projection.
- Existing users are not required to recreate their profile.


## 4.4.4 Profile-scoped Device Monitor architecture correction

- The Device Monitor operational database is now created per named profile.
- The previous shared `simreg_monitor.db` is retained only as a one-time migration source.
- On first migration, the legacy database is copied into `device_monitor_profile_default.db` so existing history is preserved.
- The global profile registry contains only profile metadata and the active profile ID.
- SMS/query state, Device Monitor observations, histories, saved lists, and related operational state follow the active profile.
- Month-to-Month live Device Monitor reads are explicitly bound to the active profile database.
- Month-end payment snapshots are captured independently for every profile.
- Cutoff/payment-cycle calculations therefore cannot mix observations from different profiles.
