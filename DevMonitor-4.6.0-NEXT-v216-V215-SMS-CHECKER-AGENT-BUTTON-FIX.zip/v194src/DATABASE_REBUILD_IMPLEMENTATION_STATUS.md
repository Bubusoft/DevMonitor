# Database Rebuild Implementation Status

This package is the Aurora 4.3.4.28 baseline prepared for the database rebuild.

Implemented in this package:
- Added `DatabaseRebuildContract.kt` containing the non-negotiable data-source rules.
- Added the Device Monitor Active-vs-MTD rule to the Master Work Sheet.
- Preserved the original Aurora application source and build environment unchanged otherwise.

The full persistence rewrite (separate Device Monitor DB, continuous normalized company-report DB, report metadata store, three-month pruning, import-to-Device-Monitor 21–30 snapshot bridge, and async DB ownership) still requires source-level integration and device/build verification.

This status is intentionally explicit: the package must not be represented as a completed database rewrite until those integrations compile and are tested.
