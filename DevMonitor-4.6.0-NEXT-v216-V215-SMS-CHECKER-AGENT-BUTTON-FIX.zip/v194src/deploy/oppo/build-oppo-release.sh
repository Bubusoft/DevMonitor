#!/bin/sh
set -eu

ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)"
CONFIG="$ROOT/deploy/oppo/oppo-release.properties"

if [ ! -f "$CONFIG" ]; then
  echo "Missing $CONFIG"
  echo "Copy deploy/oppo/oppo-release.properties.template to deploy/oppo/oppo-release.properties and fill it in."
  exit 1
fi

set -a
. "$CONFIG"
set +a

# Passwords are intentionally NOT read from the properties file.
# Prompt for them interactively so they are not stored on disk.
unset RELEASE_STORE_PASSWORD RELEASE_KEY_PASSWORD

case "${ADMOB_APP_ID:-}" in
  ca-app-pub-3940256099942544~*)
    echo "ERROR: Google test AdMob App ID detected. Replace it with the production ID."
    exit 1
    ;;
esac

case "${ADMOB_BANNER_AD_UNIT_ID:-}" in
  ca-app-pub-3940256099942544/*)
    echo "ERROR: Google test banner AdMob ID detected. Replace it with the production ID."
    exit 1
    ;;
esac

case "${ADMOB_INTERSTITIAL_AD_UNIT_ID:-}" in
  ca-app-pub-3940256099942544/*)
    echo "ERROR: Google test interstitial AdMob ID detected. Replace it with the production ID."
    exit 1
    ;;
esac

case "${ADMOB_REWARDED_AD_UNIT_ID:-}" in
  ca-app-pub-3940256099942544/*)
    echo "ERROR: Google test rewarded AdMob ID detected. Replace it with the production ID."
    exit 1
    ;;
esac

for REQUIRED in RELEASE_STORE_FILE RELEASE_KEY_ALIAS; do
  eval VALUE="\${$REQUIRED:-}"
  if [ -z "$VALUE" ]; then
    echo "ERROR: $REQUIRED is missing from $CONFIG"
    exit 1
  fi
done

if [ ! -f "$RELEASE_STORE_FILE" ]; then
  echo "ERROR: RELEASE_STORE_FILE does not point to an existing keystore:"
  echo "       $RELEASE_STORE_FILE"
  exit 1
fi

echo "======================================"
echo " FieldPulse 2.3.14 OPPO Production"
echo "======================================"
echo "Keystore: $RELEASE_STORE_FILE"
echo "Alias: $RELEASE_KEY_ALIAS"
echo "AdMob: Production IDs detected"
echo ""

printf '%s' "Enter keystore password: "
TTY_STATE=""
if TTY_STATE=$(stty -g 2>/dev/null); then
  stty -echo
fi
IFS= read -r RELEASE_STORE_PASSWORD
if [ -n "$TTY_STATE" ]; then
  stty "$TTY_STATE"
fi
printf '\n'

printf '%s' "Enter key password for $RELEASE_KEY_ALIAS: "
TTY_STATE=""
if TTY_STATE=$(stty -g 2>/dev/null); then
  stty -echo
fi
IFS= read -r RELEASE_KEY_PASSWORD
if [ -n "$TTY_STATE" ]; then
  stty "$TTY_STATE"
fi
printf '\n'

if [ -z "$RELEASE_STORE_PASSWORD" ] || [ -z "$RELEASE_KEY_PASSWORD" ]; then
  echo "ERROR: Passwords cannot be empty."
  exit 1
fi

cd "$ROOT"

sh "$ROOT/build-phone.sh" :app:assembleRelease \
  -PADMOB_APP_ID="$ADMOB_APP_ID" \
  -PADMOB_BANNER_AD_UNIT_ID="$ADMOB_BANNER_AD_UNIT_ID" \
  -PADMOB_INTERSTITIAL_AD_UNIT_ID="$ADMOB_INTERSTITIAL_AD_UNIT_ID" \
  -PADMOB_REWARDED_AD_UNIT_ID="$ADMOB_REWARDED_AD_UNIT_ID" \
  -PMONETIZED_BUILD="${MONETIZED_BUILD:-true}" \
  -PFEEDBACK_WEB_APP_URL="${FEEDBACK_WEB_APP_URL:-}" \
  -PRELEASE_STORE_FILE="$RELEASE_STORE_FILE" \
  -PRELEASE_STORE_PASSWORD="$RELEASE_STORE_PASSWORD" \
  -PRELEASE_KEY_ALIAS="$RELEASE_KEY_ALIAS" \
  -PRELEASE_KEY_PASSWORD="$RELEASE_KEY_PASSWORD"

APK="$ROOT/app/build/outputs/apk/release/app-release.apk"
OUT="$ROOT/app/build/outputs/apk/release/FieldPulse-2.3.14-OPPO.apk"

if [ ! -f "$APK" ]; then
  echo "ERROR: Release APK was not produced: $APK"
  exit 1
fi

cp "$APK" "$OUT"
echo ""
echo "======================================"
echo " BUILD SUCCESSFUL"
echo "======================================"
echo "OPPO APK:"
echo "$OUT"
