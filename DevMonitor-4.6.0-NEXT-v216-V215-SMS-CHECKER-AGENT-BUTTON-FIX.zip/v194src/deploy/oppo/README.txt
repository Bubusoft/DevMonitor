FieldPulse 2.3.7 — OPPO App Market deployment preparation

Start with OPPO_STORE_DEPLOYMENT.md.
Copy oppo-release.properties.template to oppo-release.properties, fill in production values, then run build-oppo-release.sh from the project root.

Do not place a keystore or completed secrets file inside the ZIP you share.
