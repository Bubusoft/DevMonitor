# FieldPulse 2.3.14 — Phone-Friendly Production Setup

You should not need to edit `app/build.gradle.kts`.

## 1. Keep your keystore safe

Use your generated `fieldpulse-release.jks`. Do not put it into the public source ZIP.

## 2. Create the local OPPO release properties

Copy `deploy/oppo/oppo-release.properties.template` to `deploy/oppo/oppo-release.properties`.

The local file is ignored by Git. Fill in:

- `RELEASE_STORE_FILE` = full path to `fieldpulse-release.jks`
- `RELEASE_STORE_PASSWORD` = your private password
- `RELEASE_KEY_ALIAS` = `fieldpulse-release`
- `RELEASE_KEY_PASSWORD` = your private key password

We will add the real AdMob production IDs to this local file in the next step.

## 3. Build

Run the existing OPPO release script:

`sh deploy/oppo/build-oppo-release.sh`

The script checks the signing values and keystore, refuses Google's test AdMob IDs, builds the release APK, and names the OPPO copy `FieldPulse-2.3.14-OPPO.apk`.

## Security

Never send the password in chat. Never commit `oppo-release.properties`. Never upload the `.jks` to a public repository.
