# FieldPulse 2.3.5 — Full Left App Menu

## Change
Replaced the top-right three-dot dropdown app menu with a full left-side Material 3 navigation drawer.

## Menu entries
- Guided Tour
- About the App
- Feedback & Suggestions
- Files & Analysis
- Settings

## Quick access
- Open Device Monitor

## Preserved
- 2.3.5 7-Day Save/Help behavior
- Initial introduction shown independently from the optional guided tour
- Guided tour and target highlighting
- Excel export and Open workflow
- Existing dashboard, flags, bottom navigation, SMS/device workflows, ads and billing behavior

## UX intent
The drawer is opened from a standard hamburger control in the top app bar. It provides a larger, easier-to-read surface for app-level actions and avoids the cramped three-dot dropdown.
