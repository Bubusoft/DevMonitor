# DevMonitor 4.3.5.57 — Isolated Month-to-Month Databases

## Purpose
Month-to-Month Comparison is being isolated from the existing Loaded Reports/normalized activation database so report replacement, monthly freezing, and current-vs-previous selection cannot be distorted by unrelated historical data.

## Four dedicated databases
1. `devmonitor_mom_previous.db` — previous month snapshot. Partial reports can replace it until a full-month Activation report is supplied.
2. `devmonitor_mom_previous_my_devices.db` — My Devices projection of #1.
3. `devmonitor_mom_current.db` — current month incremental snapshot.
4. `devmonitor_mom_current_my_devices.db` — My Devices projection of #3.

## Fifth source
At calculation time the feature peeks at the existing Device Monitor database. It does not copy or mutate that database.

## Previous-month locking
A previous-month report is locked only when all of these are true:
- its filename identifies the previous month;
- the filename contains `activation`;
- coverage is the complete first through last day of that month.

A registration report, even if it covers the whole month, cannot lock the previous-month snapshot. Once locked, later reports for that month are ignored by this feature.

## Filename routing
The filename month controls which Month-to-Month month can be updated. A report for another month cannot update the current or previous snapshot. The global `HumanDateParser` is used to interpret the filename.

## Calculation
- Start with saved My Devices.
- Read current-month data from the isolated current My Devices database.
- Read previous-month data from the isolated previous My Devices database.
- Peek at Device Monitor for those devices.
- If a Device Monitor MTD observation was received after the current loaded-report snapshot, it can supersede that device's loaded-report current value.
- The newest current-month covered date becomes the cutoff.
- Previous month is evaluated from day 1 through the same day-of-month, capped by the previous month's length and by whatever data the previous snapshot actually contains.
- Return current total, previous total, absolute change and percentage change.

## Protected areas
No payment calculator, PaymentCycleResolver, payment-cycle database, or payment progression pathway is changed by this feature.
