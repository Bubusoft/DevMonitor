# FieldPulse 4.3.4.28 Aurora — Continuous Database Rebuild

Implemented on the Aurora 4.3.4.28 baseline.

- Device Monitor operational data remains in `DatabaseStore`.
- Company/HQ activation history is stored in a separate `fieldpulse_company_activations.db`.
- SIMReg/Activations imports are normalized to `device_id + activation_date`.
- A newly imported report is authoritative for the same device/date, including when its value is lower.
- Missing daily cells remain unknown instead of being converted to zero in the normalized database.
- Approximately three months of rolling company activation history is retained.
- Only a lightweight 21st–30th historical company snapshot is bridged into Device Monitor storage.
- Payment progression uses company `Active` activation history first; Device Monitor fallback uses `Active`, never MTD.
- The original XLSX is no longer persisted by the report library. Parsed report snapshots are stored for reopening the report UI.
- Firebase, Google Sign-In, Drive backup, billing, ads, agents, location, SMS and Device Monitor code paths are retained.

Build verification is still required on the user's Android Code Studio environment because this environment cannot obtain the Gradle 8.7 distribution or ARM-compatible AAPT2.
