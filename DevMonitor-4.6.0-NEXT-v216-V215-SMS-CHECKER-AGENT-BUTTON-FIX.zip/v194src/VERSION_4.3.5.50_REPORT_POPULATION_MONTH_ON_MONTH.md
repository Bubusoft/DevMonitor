# DevMonitor 4.3.5.50 — Report-Population Month-on-Month

- Month-on-Month now compares the device population recorded in each month's report (Option A).
- The current comparison uses the latest available current-month report coverage date as the effective as-of date.
- The previous-month side uses the same elapsed calendar period, but its device population comes from the previous month's report.
- Devices added or removed between monthly reports remain included on the side/report where they appear.
- Device Monitor data remains part of the current-month source hierarchy when a newer observation exists for a device represented in the current report population.
- The Month-on-Month UI wording now explicitly labels current MTD and same-period-last-month values.
- The ownership wording was removed because it described the previous common-device interpretation rather than the selected report-population model.
- Payment calculation/resolver/pathway code was not changed.
