# DevMonitor 4.3.5.9 — Device Monitor Payment-Cycle Reset

## Fix

Device Monitor payment progression now treats the 21st as a hard payment-cycle boundary. The current card never carries activations from the previous payment cycle into the new one.

For example:

- On September 21, the active cycle is September 21 → October 20.
- September 1–20 and all August data are historical and cannot contribute to the current Device Monitor card.
- A September 21 activation is the first eligible current-cycle activation.
- When October begins, September 21–30 remains part of the active October cycle (September 21 → October 20).
- When October 21 arrives, the cycle rolls to October 21 → November 20, and September data is no longer eligible.

## Implementation

- Removed the previous-month historical bridge from the Device Monitor payment-card refresh path.
- Successful SMS checks no longer refresh a previous-month bridge for use by the payment card.
- Device Monitor source labels now explicitly identify current-cycle Loaded Reports or current-cycle SMS.
- `PaymentCycleResolver` documents and logs the hard current-cycle boundary.
- Normalized activation data is retained historically; only the payment calculation is restricted to the active 21st→20th window.
- Future-dated report rows remain excluded by the existing live-date clamp.

## Expected test case: device ending 655D

On September 21:

- No September 21 record: Device Monitor = 0.
- September 21 test value = 14: Device Monitor = 14.
- September 1–20 values: ignored for the current card.
- August values: ignored for the current card.

On October 1, September 21–30 values are still included because they belong to the September 21 → October 20 payment cycle.
