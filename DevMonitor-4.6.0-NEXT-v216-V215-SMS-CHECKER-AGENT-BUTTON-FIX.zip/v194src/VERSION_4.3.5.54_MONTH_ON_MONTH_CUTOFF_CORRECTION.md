# DevMonitor 4.3.5.54 — Month-on-Month Cutoff Correction

## Confirmed problem
The supplied AIYETORO reports produce:
- September 1–23: 1,204
- August 1–23: 1,058

The app card was showing 1,204 versus 1,155. Independent calculation of the supplied August workbook shows that **1,155 is exactly August 1–25**, proving that the previous side was being calculated through August 25 even though the latest September report ends on September 23.

## Correction
The current-month report used for Month-on-Month now comes from the newest imported current-month report whose declared coverage is available by the requested as-of date. This report anchors the current cutoff before normalized-data fallback is considered.

This specifically prevents stale/restored normalized rows from an older report from selecting an obsolete later cutoff. Normalized daily values remain the source for the actual totals.

## Expected test result
For the supplied AIYETORO August and September reports:
- As of: 2026-09-23
- This month to date: 1,204
- Same period last month: 1,058
- Change: +146 (+13.8%)

## Protected
- Payment calculation/resolver/progression/pathway logic was not changed.
- Month-on-Month remains strictly month-based, not payment-cycle based.
