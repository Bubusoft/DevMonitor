# FieldPulse 2.3.2 follow-up — Input normalization

1. Device and partner codes may be entered in any case.
2. Before SMS transmission, the complete code is uppercased.
3. GLO 3030 short-form conversion remains unchanged and the final SMS is uppercase.
4. Partner codes have no hard-coded length/regex format. Any non-blank partner code is accepted; the remote service decides validity.
5. Excel import accepts open partner-code formats and ignores only common header labels.
