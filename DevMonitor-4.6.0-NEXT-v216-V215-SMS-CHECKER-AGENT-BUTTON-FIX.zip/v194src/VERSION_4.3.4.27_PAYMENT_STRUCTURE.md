# FieldPulse 4.3.4.27 — Current Agent Incentive Structure

Baseline: 4.3.4.26.

Changes:
- Replaced the in-app payment/incentive flyer with the enhanced current company flyer.
- Updated monthly activation tiers: 30/50/70/100/150/200/250/300+ with ₦9,000/₦22,500/₦35,000/₦65,000/₦90,000/₦110,000/₦135,000/₦150,000.
- FRC is estimated at ₦250 per qualifying activation using the assumed minimum ₦200 recharge.
- FDS and app-download incentives are not estimated because FieldPulse cannot establish them from the available report data.
- Recharge values above ₦200 are not estimated.
- Sunday activations remain included once in the normal monthly activation total.
- Sunday qualification is evaluated independently for each calendar Sunday in the report month/year. A Sunday with at least 5 qualifying activations earns an additional ₦200 per activation on that Sunday. A Sunday below 5 earns no Sunday extra.
- Sunday extra is therefore ₦200 per qualifying activation, in addition to the ₦250 FRC incentive; those components total ₦450 for a qualifying Sunday activation.
- Company data remains the final payment authority.
