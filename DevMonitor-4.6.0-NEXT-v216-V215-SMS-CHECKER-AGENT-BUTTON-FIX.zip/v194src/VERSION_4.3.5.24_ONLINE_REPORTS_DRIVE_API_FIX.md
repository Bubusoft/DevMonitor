# FieldPulse 4.3.5.24 — Online Reports Drive API Fix

- Configured the FieldPulse Reports public Drive folder ID.
- Corrected public-folder Drive API listing to use the documented `q` parent-folder filter without `corpora=user`.
- Kept the API key out of source control; add `DRIVE_REPORT_API_KEY` only to the local Gradle properties used for the release build.
- Version code: 109.
- Version name: 4.3.5.24.

Google documents API-key authentication for listing files in a publicly shared folder.
