# DevMonitor 4.3.5.43 — Internet Action Guards

- Added one shared active-Internet detector using Android ConnectivityManager/validated network capability.
- Added immediate offline warnings before Google Sign-In, online company reports, Google Drive backup/restore, premium purchase/restore/subscription management, Google Maps, feedback submission, and Firebase phone OTP actions.
- Online report refresh/download paths also re-check connectivity so the warning remains correct if the connection disappears after opening the dialog.
- Partner authorization Firestore operations are guarded at the data layer as well.
- Core offline/local features such as Device Monitor SMS querying, local report import, normalized database work, My Devices, payment calculations, and Month-to-Month Comparison were not changed.
- Payment calculation/resolver pathways were not changed.
