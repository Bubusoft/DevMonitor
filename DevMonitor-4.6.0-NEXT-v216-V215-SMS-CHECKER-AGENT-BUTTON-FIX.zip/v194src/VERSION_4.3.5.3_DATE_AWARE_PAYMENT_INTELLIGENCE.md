# DevMonitor 4.3.5.3 — Date-aware payment intelligence

- Payment progression is bounded by the real current device date.
- Future-dated imported activation rows never advance payment progression.
- At the start of a new cycle (21st), the current cycle starts at the 21st and shows zero when the device has no sales yet.
- Previous cycle is no longer the default loaded-report progression.
- Loaded-report cycle range is displayed explicitly.
- Added DevMonitor-PAYMENT logging for cycle calculations.
- Device Monitor historical bridge remains independent and continues to use the previous calendar month 21st→month-end rule.
