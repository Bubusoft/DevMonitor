# FieldPulse 4.3.4.9 — Shared Partner Authorization

## Purpose
Build the Partner Login → Staff Approval → Partner Unlock workflow on a shared backend suitable for Android, PC and web clients.

## Authorization identity
Approval belongs to the authenticated Firebase partner account UID + Trade Code. It does not belong to one physical phone.

## Lifecycle
- PENDING
- APPROVED
- REJECTED
- REVOKED

## Security boundary
- Partner creates only its own request.
- Partner can read its own request.
- Verified staff-line accounts can review/update requests.
- Trade Code alone is never sufficient for payment access.
- Approved partner access is restricted to the approved Trade Code.
- Staff access remains governed by the existing verified staff authentication rule.

## Cross-platform behavior
A partner who changes Android phones, moves to PC, or uses the future web client does not need a new staff approval merely because the device changed, provided the same Firebase partner account is authenticated and the Trade Code remains approved.

## Firebase setup
1. Open the existing `fieldpulse-b3eb3` Firebase project.
2. Enable Cloud Firestore.
3. Publish `firestore.rules`.
4. Keep the rules restrictive; do not switch to open/test rules for deployment.

## Android build
Use the established phone build environment:

`sh build-phone.sh assembleDebug --console=plain`

4.3.4.9 uses versionCode 67 and versionName 4.3.4.9.
