# DevMonitor 4.6.0-NEXT v158 — Targeted Payment/Search Fix

## Scope
- Device Monitor payment-card gate now checks the selected device's actual historical baseline through the 20th of the current calendar month.
- A previous-month report imported later cannot masquerade as the current month's baseline merely because it was the most recently imported report.
- Device Monitor history gating now checks calendar-month dates 1–20 for the selected device.
- Dashboard Search → Open now switches to the Device Monitor tab before opening the selected device payment card.
- Device Monitor payment cards now show an explicit historical-data warning when no payment estimate can be established, instead of silently showing no card.

## Protected
- PaymentEngine rules/calculators were not modified.
- Four physical Month-on-Month databases remain unchanged.
- Release configuration remains preserved; this is a debug build version increment only.
