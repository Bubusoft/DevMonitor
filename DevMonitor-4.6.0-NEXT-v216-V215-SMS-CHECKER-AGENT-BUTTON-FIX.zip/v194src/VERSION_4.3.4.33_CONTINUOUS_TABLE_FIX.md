# DevMonitor 4.3.4.33 — Continuous Loaded Reports Table Fix

- Loaded Reports screen always displays the continuous normalized dataset.
- Opening an individual inventory record no longer replaces the table with that report.
- Inventory records remain metadata/history for deletion and troubleshooting.
- Continuous table refreshes after inventory metadata deletion.
- Database materialization remains on Dispatchers.IO.
- This prepares the later change where Dashboard -> Load File opens the continuous table directly.
