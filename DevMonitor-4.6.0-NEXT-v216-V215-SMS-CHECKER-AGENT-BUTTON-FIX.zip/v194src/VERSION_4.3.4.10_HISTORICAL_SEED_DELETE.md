# FieldPulse 4.3.4.10 — August Historical Seed + Saved Report Delete

## Scope
- Built from the confirmed 4.3.4.9 partner-authorization baseline.
- Preloads the supplied August 2026 full-month SIMReg workbook once on first app start.
- Preserves the supplied workbook bytes unchanged.
- Stores explicit August 1-31, 2026 full-month metadata so historical comparison logic uses the intended month even though the workbook heading contains an inconsistent date range.
- Keeps the seed inside the existing completed-full-month three-report retention policy.
- Adds a Delete button beside Open for saved SIMReg reports.
- Delete requires confirmation and removes only the saved workbook and metadata entry; Device Monitor/SMS data are untouched.
- No authentication, Firebase, partner authorization, parser, or payment-access rules were changed.
