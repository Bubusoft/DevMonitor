# DevMonitor 4.5.12 — Physical Month-on-Month Stores + Live Device Monitor Active

## Build
- versionName: `4.5.12`
- versionCode: `146`

## Month-on-Month architecture correction
The Month-on-Month feature now treats its four SQLite databases as four real,
independent physical databases:

- `devmonitor_mom_previous.db` — Previous Month Full
- `devmonitor_mom_previous_my_devices.db` — Previous Month My Devices
- `devmonitor_mom_current.db` — Current Month Full (the month remains ongoing)
- `devmonitor_mom_current_my_devices.db` — Current Month My Devices

There is no continuing database relationship between Month-on-Month and the
payment section. Loaded Report import is the integration point.

### Historical ownership protection
- Current Month My Devices follows the current saved ownership list.
- Previous Month My Devices is a historical snapshot and is never rebuilt from
  the current month's ownership list.
- At month rollover, Current Month Full becomes Previous Month Full and Current
  Month My Devices becomes Previous Month My Devices.
- The old Current pair is then physically cleared so the new Current Month pair
  starts empty and grows only from the new month's imports/ownership.
- A locked full previous-month database is never overwritten at rollover.

## Device Monitor Active source rule
For current-month payment progression, Device Monitor `Active` is the live
calendar-month cumulative value. When its observation was received after the
relevant Loaded Report import, it is preferred over the report value. If the
Loaded Report is newer, the report remains authoritative. `MTD` is never used
as a substitute for `Active`.

For a cycle that begins on the 21st, the current calendar-month Active value is
combined with the appropriate 20th baseline. A historical baseline may come from
Loaded Reports when a 20th Device Monitor observation is unavailable.

## Build variants
Two distribution ZIPs are supplied:

- **CLOUD** — standard Gradle/cloud build using `./gradlew`.
- **PHONE** — retains the Android Code Studio/ARM-safe `build-phone.sh` path and
  the established single-worker build settings.

No payment tier/business-rule values were changed by this milestone.
