# DevMonitor 4.6.0-NEXT v197 — Settings Profile Boundary + Online Reports Fix

- Manage My Profile is now reachable from Settings only; the Check My Devices action menu no longer opens the profile editor.
- Corrected the Google Drive report folder ID so GitHub release builds and phone builds use the same configured folder.
- Online report discovery accepts supported Excel/CSV workbook variants while excluding folders and unrelated files.
- Existing Loaded Report waiting states, My Devices-first presentation, Show more behavior, targeted search, MOM and protected payment logic are unchanged.
