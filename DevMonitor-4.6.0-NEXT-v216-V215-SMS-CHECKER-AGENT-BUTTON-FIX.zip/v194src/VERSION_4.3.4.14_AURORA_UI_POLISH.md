# FieldPulse 4.3.4.14 — Aurora UI Polish

Correction build from 4.3.4.13 based on device screenshots.

- Preserve all authentication, Firebase, Firestore, database, SIMReg and payment logic.
- Corrected disabled custom-button shadows so disabled controls no longer appear as blurred grey blocks.
- Refined Aurora light/dark surface-container colors to remove the unintended lavender Material 3 appearance.
- Increased visual depth of the light Aurora background.
- Corrected Payment Intelligence page inset handling so its content no longer draws underneath the top app bar.
- Added a small top breathing space to the Payment Intelligence list.
- No destructive database migration.
