# DevMonitor 4.6.0-NEXT v162 — Dashboard clarity / role-aware UX

## Changes
- Renamed Dashboard shortcut cards to SMS CHECKER, MY DEVICES, LOAD REPORT and EARNING PROGRESS.
- Renamed the bottom navigation payment destination to Earning Progress for consistent user-facing terminology.
- Made the Dashboard Action Centre visible only for AGENT and PARTNER profiles; STAFF profiles do not receive that card.
- Removed the obsolete Manage authentication & authorization Settings button.
- Removed developer-facing SHA-1/OAuth troubleshooting text from normal Settings UI.
- Simplified the Google backup explanation to a concise user-facing message.

## Protected
- Google sign-in implementation.
- Google Drive backup/restore implementation.
- PaymentEngine and payment formulas.
- Two-month HQ architecture and report import rules.
- Existing Device Monitor, Loaded Report and MOM calculations.

- Added individual saved-device removal from the My Devices profile editor with confirmation; removal affects only the profile working set.
