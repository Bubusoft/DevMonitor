# DevMonitor 4.6.0-NEXT v202 — Online Report Download Reliability Fix

## Scope

Fixes downloading the ordinary Excel/CSV report files already listed from the configured Google Drive folder.

## Changes

- Drive API media download remains the primary path.
- Transient HTTP 429/5xx responses receive one retry.
- If the API media request cannot deliver the selected file, the app retries the same file through Drive's public download endpoint.
- Downloaded content is validated as CSV, XLS, XLSX, or XLSM before import. HTML/JSON error responses are rejected instead of being passed to the importer.
- Drive error messages are surfaced with the HTTP status where available.
- Native Google Sheets export is deliberately not included.

Payment and report calculation logic are unchanged.
