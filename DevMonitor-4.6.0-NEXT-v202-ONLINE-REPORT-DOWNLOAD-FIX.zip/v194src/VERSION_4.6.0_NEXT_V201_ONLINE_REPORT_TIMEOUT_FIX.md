# DevMonitor 4.6.0-NEXT v201 — Online Reports Loading Timeout Fix

- Removed the extra Drive folder metadata validation request.
- Directly lists files with the Google Drive `files.list` API.
- Retains shared-drive support flags.
- Adds connection/read timeouts and a 20-second overall listing timeout.
- Adds pagination and duplicate protection.
- No payment, Loaded Report, MOM, or dashboard behavior changes.
