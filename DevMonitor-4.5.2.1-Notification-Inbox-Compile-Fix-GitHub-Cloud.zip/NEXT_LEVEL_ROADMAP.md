
## Appearance / Theme Evolution — 4.5.1

The visual phase may evolve the overall DevMonitor theme while preserving the Aurora foundation. Green is an additional visual family, not a requirement to replace the existing palette. Planned/implemented variations include emerald, mint and deep green in selected surfaces, cards, metrics, actions and payment progression.
# DevMonitor — NEXT LEVEL PRODUCT ROADMAP

**Roadmap name:** NEXT LEVEL
**Baseline:** 4.4.4 Multi-Profile / Profile-Scoped Device Monitor
**Purpose:** Evolve DevMonitor from a monitoring/reporting utility into a modern field productivity suite while preserving proven SMS, SIMReg, payment-cycle and profile-isolation logic.

## Product direction

DevMonitor should answer four questions immediately:
1. How am I doing?
2. What needs my attention?
3. What changed?
4. What should I do next?

## Phase 1 — Experience transformation

- [x] Modern command-centre dashboard foundation
- [x] Dashboard global device/alert search
- [x] Quick actions: Monitor, My Devices, Reports, Payments
- [x] Live payment-cycle progression card using existing payment rules
- [x] Action Centre with prioritized alerts and drill-down
- [x] Clearer dashboard hierarchy and information density
- [x] Reuse Aurora design system rather than adding a competing UI framework
- [x] Dedicated in-app notification/inbox surface — 4.5.2
- [ ] Rich 7-day/30-day visual trends — next planned item
- [ ] Device-card visual redesign
- [ ] Consistent loading/skeleton states across major screens
- [ ] Refined empty/error/offline states
- [ ] Motion polish and accessibility pass

## Phase 2 — Productivity layer

- [ ] Tasks and follow-ups
- [ ] Device/partner/staff notes
- [ ] Device activity timeline
- [ ] Reminders
- [ ] Exception-driven task suggestions
- [ ] Shareable daily performance snapshot
- [ ] Smarter export choices: Quick, Detailed, Payment, Exception, HQ Comparison, Full

## Phase 3 — Intelligence layer

- [ ] 7-day and 30-day trends
- [ ] Anomaly detection
- [ ] Local vs HQ reconciliation
- [ ] Performance and payment-cycle insights
- [ ] Explain-this calculation panels
- [ ] Advanced management dashboards
- [ ] Natural-language operational search/assistant after deterministic intelligence is stable

## Phase 4 — Platform maturity

- [ ] Offline-first status model
- [ ] Sync Centre
- [ ] Background sync/backup reliability
- [ ] Database indexes and query profiling
- [ ] Dashboard snapshot/cache layer
- [ ] Diagnostics Centre
- [ ] Audit trail
- [ ] Modularize MainActivity into feature areas
- [ ] Release/update and migration hardening

## Design system targets

- Material 3 foundation with DevMonitor Aurora visual language
- Consistent 4/8/12/16/24/32dp spacing scale
- Consistent 8/12/16/24dp corner families
- Strong typography hierarchy
- Compact information cards instead of excessive large cards
- Accessible contrast and touch targets
- Motion used for feedback, not decoration

## Non-negotiable architectural rules

- Payment cycle remains **21st of previous month through 20th current month**.
- Payment progression has one calculation pathway; UI must not create duplicate payment logic.
- Operational databases remain profile-scoped.
- Month-to-Month search remains isolated to its dedicated databases.
- Device Monitor may enrich other views only through explicitly permitted read-only pathways.
- SMS remains the operational transport for 3030 queries.
- Existing historical data must survive migrations.
- Performance work must not weaken data correctness.
