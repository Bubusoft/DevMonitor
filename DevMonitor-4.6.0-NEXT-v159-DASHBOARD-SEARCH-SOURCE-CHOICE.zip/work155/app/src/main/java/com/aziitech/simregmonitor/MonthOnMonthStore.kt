package com.aziitech.simregmonitor

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.text.DateFormatSymbols
import java.time.LocalDate
import java.time.YearMonth
import java.util.Locale

/**
 * Isolated data layer for Month-to-Month Comparison.
 *
 * This feature owns four physically separate SQLite databases:
 * Previous Month Full, Previous Month My Devices, Current Month Full, and
 * Current Month My Devices. Loaded Reports are copied into these stores at import
 * time. There is no ongoing database relationship with the Payment section.
 * Month-to-Month may read the live Device Monitor database as its established
 * current-month enrichment source; that does not merge or project databases.
 */
class MonthOnMonthStore(private val context: Context) {
    private var deviceMonitorStore: DatabaseStore? = null

    fun setDeviceMonitorStore(store: DatabaseStore) {
        deviceMonitorStore = store
    }
    data class Comparison(
        val asOf: LocalDate,
        val currentTotal: Int,
        val previousTotal: Int,
        val delta: Int,
        val percentChange: Double?
    )

    data class SearchHit(
        val type: String,
        val label: String,
        val detail: String,
        val deviceIds: List<String> = emptyList(),
        val sources: List<String> = emptyList(),
        val monitorLatestDate: LocalDate? = null,
        val monitorActive: Int? = null,
        val monitorIsNewer: Boolean = false
    )

    private data class SnapshotRow(
        val deviceId: String,
        val date: LocalDate,
        val count: Int
    )

    private class SnapshotDb(context: Context, name: String) :
        SQLiteOpenHelper(context, name, null, 1) {
        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL("CREATE TABLE meta(month_key TEXT PRIMARY KEY, coverage_start TEXT, coverage_end TEXT, source_name TEXT, imported_at INTEGER NOT NULL, locked INTEGER NOT NULL DEFAULT 0)")
            db.execSQL("CREATE TABLE devices(device_id TEXT PRIMARY KEY, trade_code TEXT, partner_name TEXT, cluster TEXT, region TEXT, territory TEXT, staff_name TEXT, imported_at INTEGER NOT NULL)")
            db.execSQL("CREATE TABLE daily(device_id TEXT NOT NULL, obs_date TEXT NOT NULL, value INTEGER NOT NULL, imported_at INTEGER NOT NULL, PRIMARY KEY(device_id,obs_date))")
            db.execSQL("CREATE INDEX idx_mom_daily_date ON daily(obs_date)")
            db.execSQL("CREATE INDEX idx_mom_daily_device_date ON daily(device_id,obs_date)")
        }
        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit
    }

    private val previousDb = SnapshotDb(context, "devmonitor_mom_previous.db")
    private val previousMyDevicesDb = SnapshotDb(context, "devmonitor_mom_previous_my_devices.db")
    private val currentDb = SnapshotDb(context, "devmonitor_mom_current.db")
    private val currentMyDevicesDb = SnapshotDb(context, "devmonitor_mom_current_my_devices.db")

    private val monthDbNames = listOf(
        "previous" to "devmonitor_mom_previous.db",
        "previous_my_devices" to "devmonitor_mom_previous_my_devices.db",
        "current" to "devmonitor_mom_current.db",
        "current_my_devices" to "devmonitor_mom_current_my_devices.db"
    )

    /** Import one report into the isolated Month-to-Month stores. */
    @Synchronized
    fun acceptLoadedReport(report: SimRegReport, myDeviceCodes: List<String>, now: LocalDate = LocalDate.now()): String {
        rolloverIfNeeded(now)
        val month = monthFromFilename(report.sourceName, report.coverageStart?.year ?: now.year)
            ?: return "ignored: filename has no recognizable month"
        val currentMonth = YearMonth.from(now)
        val previousMonth = currentMonth.minusMonths(1)
        if (month != currentMonth && month != previousMonth) {
            return "ignored: filename month=$month is outside current/previous comparison months"
        }

        val fullActivation = month == previousMonth &&
            report.sourceName.contains("activation", ignoreCase = true) &&
            report.coverageStart == month.atDay(1) &&
            report.coverageEnd == month.atEndOfMonth()

        val target = if (month == previousMonth) previousDb else currentDb

        // A locked historical full-month snapshot is authoritative. It is safe to
        // ignore later partial reports for that same month, but the existence of
        // a newer CURRENT-MONTH report must never prevent a valid historical report
        // from being imported when the previous-month database is still empty.
        if (month == previousMonth && isLocked(previousDb)) {
            return "ignored: previous month $month is already locked by a full activation report"
        }

        writeReport(target, report, month, fullActivation)

        when (month) {
            currentMonth -> {
                // Current Month My Devices follows the currently saved ownership list.
                refreshMyDevicesSnapshot(myDeviceCodes, currentDb, currentMyDevicesDb)
            }
            previousMonth -> {
                // IMPORTANT: a historical report can arrive after the current month
                // has already been imported (for example August arriving in September).
                // Previous Month Full and Previous Month My Devices must be populated
                // from that historical import in the same operation. This is not a
                // rollover and must not depend on Current Month being present first.
                //
                // If the historical My Devices snapshot already exists, refresh it
                // from the updated Previous Month Full store so late historical data
                // becomes visible there too. The four databases remain physically
                // separate; this is an explicit copy of the historical snapshot.
                refreshMyDevicesSnapshot(myDeviceCodes, previousDb, previousMyDevicesDb)
            }
        }

        val result = buildString {
            append(if (month == previousMonth) "previous" else "current")
            append(" month=$month stored")
            if (fullActivation) append(" and locked")
        }
        DevMonitorLogger.db("Month-on-Month isolated import: $result source=\"${report.sourceName}\"")
        return result
    }

    /**
     * Refresh the physical Current Month My Devices database from the user's
     * currently saved My Devices set. The Previous Month My Devices database is
     * historical and is deliberately never rebuilt from the current list.
     */
    @Synchronized
    fun refreshMyDevices(codes: List<String>) {
        val normalized = codes.map(::canonicalDeviceCode).filter { it.isNotBlank() }.distinct()

        // Current Month My Devices always follows the active profile.
        refreshMyDevicesSnapshot(normalized, currentDb, currentMyDevicesDb)

        // A fresh install can load the previous-month report before a profile is
        // created. In that sequence the historical Full database is populated, but
        // Previous Month My Devices receives no scope because the code list was empty
        // at import time. When the user subsequently saves/updates the profile, make
        // one explicit, user-initiated rebuild from the already imported historical
        // snapshot so MOM can see the user's previous-month data. Once populated,
        // later report imports still use the historical import path and do not copy
        // current-month data into the previous-month Full database.
        if (normalized.isNotEmpty() && hasMonthData(previousDb)) {
            refreshMyDevicesSnapshot(normalized, previousDb, previousMyDevicesDb)
        }
    }

    private fun hasMonthData(dbHelper: SnapshotDb): Boolean =
        dbHelper.readableDatabase.rawQuery(
            "SELECT 1 FROM daily LIMIT 1",
            null
        ).use { it.moveToFirst() }

    /**
     * Calculates strictly from the isolated stores and the live Device Monitor DB.
     * No CompanyActivationStore/activation_days data is queried here.
     */
    fun compare(codes: List<String>, asOf: LocalDate = LocalDate.now()): Comparison? {
        val myCodes = codes.map(::canonicalDeviceCode).filter { it.isNotBlank() }.distinct()
        if (myCodes.isEmpty()) return null

        rolloverIfNeeded(asOf)

        val currentMonth = YearMonth.from(asOf)
        val previousMonth = currentMonth.minusMonths(1)
        val currentRows = readRows(currentMyDevicesDb, currentMonth)
        val previousRows = readRows(previousMyDevicesDb, previousMonth)
        val ownedMonitor = deviceMonitorStore == null
        val monitor = deviceMonitorStore ?: DatabaseStore(context)

        try {
            val currentReportEnd = readCoverageEnd(currentMyDevicesDb, currentMonth)
            var effectiveAsOf = currentReportEnd

            // Device Monitor is a fifth, read-only source for this calculator. For each
            // saved device, a live observation is newer than a loaded report only when
            // its received timestamp is newer than the report import timestamp.
            val reportImportedAt = readImportedAt(currentMyDevicesDb, currentMonth)
            val freshMonitorRows = mutableMapOf<String, Pair<LocalDate, Int>>()
            for (code in myCodes) {
                val newest = monitor.observationsForCode(code, 90).mapNotNull { obs ->
                    val date = runCatching { LocalDate.parse(obs.date) }.getOrNull() ?: return@mapNotNull null
                    if (YearMonth.from(date) != currentMonth || date.isAfter(asOf)) return@mapNotNull null
                    val received = parseReceivedAt(obs.receivedAt) ?: return@mapNotNull null
                    if (reportImportedAt != null && received <= reportImportedAt) return@mapNotNull null
                    // Month-to-Month uses Device Monitor's current Active value when
                    // the live observation is newer than the loaded report. Never use
                    // the MTD field here.
                    val value = obs.active ?: return@mapNotNull null
                    date to value
                }.maxByOrNull { it.first }
                if (newest != null) {
                    freshMonitorRows[code] = newest
                    if (effectiveAsOf == null || newest.first.isAfter(effectiveAsOf)) effectiveAsOf = newest.first
                }
            }

            if (effectiveAsOf == null) return null
            effectiveAsOf = effectiveAsOf.coerceAtMost(asOf)

            val currentStart = currentMonth.atDay(1)
            val previousEnd = previousMonth.atDay(minOf(effectiveAsOf.dayOfMonth, previousMonth.lengthOfMonth()))
            val currentTotal = myCodes.sumOf { code ->
                val monitorValue = freshMonitorRows[code]
                val reportValue = currentRows.filter { it.deviceId == code && !it.date.isAfter(effectiveAsOf) && !it.date.isBefore(currentStart) }.sumOf { it.count }
                val reportLatestDate = currentRows.filter { it.deviceId == code && !it.date.isAfter(effectiveAsOf) && !it.date.isBefore(currentStart) }.maxOfOrNull { it.date }
                when {
                    monitorValue != null && (reportLatestDate == null || !monitorValue.first.isBefore(reportLatestDate)) -> monitorValue.second
                    else -> reportValue
                }
            }
            val previousTotal = myCodes.sumOf { code ->
                previousRows.filter { it.deviceId == code && !it.date.isAfter(previousEnd) }.sumOf { it.count }
            }

            val delta = currentTotal - previousTotal
            val percent = if (previousTotal == 0) null else delta.toDouble() * 100.0 / previousTotal.toDouble()
            DevMonitorLogger.db(
                "isolated month-on-month currentMonth=$currentMonth previousMonth=$previousMonth " +
                    "asOf=$effectiveAsOf current=${myCodes.size}devices/$currentTotal previous=$previousTotal " +
                    "monitorFresh=${freshMonitorRows.size} currentReportEnd=$currentReportEnd"
            )
            return Comparison(effectiveAsOf, currentTotal, previousTotal, delta, percent)
        } finally {
            if (ownedMonitor) monitor.close()
        }
    }

    /**
     * Staff-only read-only search over the four dedicated Month-to-Month databases.
     * The live Device Monitor database is only peeked at to enrich matching device
     * results with the newest observation; it is never used to expand the search
     * population beyond the four Month-to-Month stores.
     */
    fun search(query: String, asOf: LocalDate = LocalDate.now(), limit: Int = 100): List<SearchHit> {
        val normalized = query.trim()
        if (normalized.length < 2) return emptyList()
        val upper = normalized.uppercase(Locale.US)
        data class RawHit(
            val type: String,
            val label: String,
            val detail: String,
            val deviceIds: List<String>,
            val source: String
        )
        val databases = listOf(
            "PREVIOUS MONTH" to previousDb,
            "PREVIOUS MONTH MY DEVICES" to previousMyDevicesDb,
            "THIS MONTH" to currentDb,
            "THIS MONTH MY DEVICES" to currentMyDevicesDb
        )
        val raw = mutableListOf<RawHit>()
        databases.forEach { (source, helper) ->
            helper.readableDatabase.rawQuery(
                "SELECT device_id,trade_code,partner_name,cluster,region,territory,staff_name FROM devices",
                null
            ).use { c ->
                while (c.moveToNext()) {
                    val device = c.getString(0).orEmpty()
                    val trade = c.getString(1).orEmpty()
                    val partner = c.getString(2).orEmpty()
                    val cluster = c.getString(3).orEmpty()
                    val region = c.getString(4).orEmpty()
                    val territory = c.getString(5).orEmpty()
                    val staff = c.getString(6).orEmpty()
                    val canonical = canonicalDeviceCode(device).uppercase(Locale.US)
                    if (canonical.contains(upper) || device.uppercase(Locale.US).contains(upper)) {
                        raw += RawHit("DEVICE", canonicalDeviceCode(device), listOf(partner, staff).filter { it.isNotBlank() }.joinToString(" • "), listOf(canonicalDeviceCode(device)), source)
                    }
                    if (partner.contains(normalized, true) || trade.contains(normalized, true)) {
                        val label = partner.ifBlank { trade }.trim()
                        if (label.isNotBlank()) raw += RawHit("PARTNER", label, listOf(trade, region, territory).filter { it.isNotBlank() }.joinToString(" • "), listOf(canonicalDeviceCode(device)), source)
                    }
                    if (staff.contains(normalized, true)) {
                        val label = staff.trim()
                        if (label.isNotBlank()) raw += RawHit("STAFF", label, listOf(region, territory).filter { it.isNotBlank() }.joinToString(" • "), listOf(canonicalDeviceCode(device)), source)
                    }
                }
            }
        }

        val grouped = raw.groupBy { "${it.type}|${it.label.uppercase(Locale.US)}" }
        val ownedMonitor = deviceMonitorStore == null
        val monitor = deviceMonitorStore ?: DatabaseStore(context)
        return try {
            grouped.values.map { group ->
                val first = group.first()
                val deviceIds = group.flatMap { it.deviceIds }.filter { it.isNotBlank() }.distinct().take(50)
                val sources = group.map { it.source }.distinct()
                val monitorCandidates = deviceIds.flatMap { code ->
                    monitor.observationsForCode(code, 90).mapNotNull { obs ->
                        val date = runCatching { LocalDate.parse(obs.date) }.getOrNull() ?: return@mapNotNull null
                        if (date.isAfter(asOf) || YearMonth.from(date) != YearMonth.from(asOf)) return@mapNotNull null
                        val active = obs.active ?: return@mapNotNull null
                        val received = parseReceivedAt(obs.receivedAt) ?: return@mapNotNull null
                        Triple(date, active, received)
                    }
                }.maxByOrNull { it.third }
                val currentImportedAt = readImportedAt(currentDb, YearMonth.from(asOf))
                val monitorDate = monitorCandidates?.first
                val monitorActive = monitorCandidates?.second
                val monitorNewer = monitorCandidates != null &&
                    (currentImportedAt == null || monitorCandidates.third > currentImportedAt)
                val detailParts = listOf(first.detail).filter { it.isNotBlank() }.toMutableList()
                if (sources.isNotEmpty()) detailParts += "Month-to-Month: ${sources.joinToString(", " )}"
                if (monitorDate != null && monitorActive != null) {
                    detailParts += "Device Monitor: ${monitorDate} Active ${monitorActive}${if (monitorNewer) " (newer)" else ""}"
                }
                SearchHit(first.type, first.label, detailParts.joinToString(" • "), deviceIds, sources, monitorDate, monitorActive, monitorNewer)
            }.sortedWith(compareBy<SearchHit> { it.type }.thenBy { it.label.uppercase(Locale.US) }).take(limit)
        } finally {
            if (ownedMonitor) monitor.close()
        }
    }

    fun close() {
        previousDb.close()
        previousMyDevicesDb.close()
        currentDb.close()
        currentMyDevicesDb.close()
    }

    private fun writeReport(dbHelper: SnapshotDb, report: SimRegReport, month: YearMonth, lock: Boolean) {
        val db = dbHelper.writableDatabase
        val now = System.currentTimeMillis()
        val rows = report.rows.flatMap { row ->
            val daily = if (row.dailyByDate.isNotEmpty()) row.dailyByDate else row.daily.mapNotNull { (day, value) ->
                runCatching { LocalDate.of(month.year, month.monthValue, day) }.getOrNull()?.let { it to value }
            }.toMap()
            daily.filter { (date, _) ->
                YearMonth.from(date) == month &&
                    (report.coverageStart == null || !date.isBefore(report.coverageStart)) &&
                    (report.coverageEnd == null || !date.isAfter(report.coverageEnd))
            }.map { SnapshotRow(canonicalDeviceCode(row.deviceId), it.key, it.value) }
        }
        db.beginTransaction()
        try {
            // Incremental month store: incoming same-month data is an update to this
            // isolated snapshot, not a destructive replacement. Existing dates remain
            // unless the newer report supplies a replacement value for that date.
            val existingMeta = db.rawQuery("SELECT month_key,coverage_end,locked FROM meta LIMIT 1", null).use { c ->
                if (c.moveToFirst()) {
                    Triple(
                        c.getString(0),
                        c.getString(1)?.let { runCatching { LocalDate.parse(it) }.getOrNull() },
                        c.getInt(2) != 0
                    )
                } else null
            }
            if (existingMeta?.third == true) {
                db.setTransactionSuccessful()
                return
            }
            val incomingEnd = report.coverageEnd ?: rows.maxOfOrNull { it.date }
            if (existingMeta != null && existingMeta.first == month.toString() &&
                existingMeta.second != null && incomingEnd != null && incomingEnd.isBefore(existingMeta.second)) {
                // An older/shorter report must never move the isolated month
                // backwards or overwrite values already supplied by a newer report.
                db.setTransactionSuccessful()
                DevMonitorLogger.db("Month-on-Month ignored older report month=$month incomingEnd=$incomingEnd existingEnd=${existingMeta.second}")
                return
            }
            if (existingMeta == null || existingMeta.first != month.toString()) {
                db.delete("daily", null, null)
                db.delete("devices", null, null)
                db.delete("meta", null, null)
            }
            db.execSQL(
                "INSERT OR REPLACE INTO meta(month_key,coverage_start,coverage_end,source_name,imported_at,locked) VALUES(?,?,?,?,?,?)",
                arrayOf(month.toString(), report.coverageStart?.toString(), report.coverageEnd?.toString(), report.sourceName, now, if (lock) 1 else 0)
            )
            report.rows.forEach { row ->
                val code = canonicalDeviceCode(row.deviceId)
                if (code.isBlank()) return@forEach
                db.execSQL(
                    "INSERT OR REPLACE INTO devices(device_id,trade_code,partner_name,cluster,region,territory,staff_name,imported_at) VALUES(?,?,?,?,?,?,?,?)",
                    arrayOf(code, row.tradeCode, row.partnerName, row.cluster, row.region, row.territory, row.staffName, now)
                )
            }
            rows.forEach { row ->
                if (row.deviceId.isBlank()) return@forEach
                db.execSQL(
                    "INSERT OR REPLACE INTO daily(device_id,obs_date,value,imported_at) VALUES(?,?,?,?)",
                    arrayOf(row.deviceId, row.date.toString(), row.count, now)
                )
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    private fun refreshMyDevicesSnapshot(codes: List<String>, parent: SnapshotDb, child: SnapshotDb) {
        val normalized = codes.toSet()
        val p = parent.readableDatabase
        val c = child.writableDatabase
        c.beginTransaction()
        try {
            c.delete("daily", null, null)
            c.delete("devices", null, null)
            c.delete("meta", null, null)
            p.rawQuery("SELECT month_key,coverage_start,coverage_end,source_name,imported_at,locked FROM meta LIMIT 1", null).use { meta ->
                if (meta.moveToFirst()) {
                    c.execSQL(
                        "INSERT INTO meta(month_key,coverage_start,coverage_end,source_name,imported_at,locked) VALUES(?,?,?,?,?,?)",
                        arrayOf(meta.getString(0), meta.getString(1), meta.getString(2), meta.getString(3), meta.getLong(4), meta.getInt(5))
                    )
                }
            }
            if (normalized.isNotEmpty()) {
                // SQLite has a finite bound-parameter limit (commonly 999 on
                // Android). Staff/cluster scopes can legitimately contain more
                // devices than that, so never construct one giant IN (...) list.
                // Chunking also keeps the profile-save/import path predictable on
                // lower-memory phones.
                normalized.chunked(500).forEach { batch ->
                    val placeholders = batch.joinToString(",") { "?" }
                    p.rawQuery(
                        "SELECT device_id,trade_code,partner_name,cluster,region,territory,staff_name,imported_at FROM devices WHERE device_id IN ($placeholders)",
                        batch.toTypedArray()
                    ).use { cur ->
                        while (cur.moveToNext()) {
                            c.execSQL(
                                "INSERT INTO devices(device_id,trade_code,partner_name,cluster,region,territory,staff_name,imported_at) VALUES(?,?,?,?,?,?,?,?)",
                                arrayOf(cur.getString(0),cur.getString(1),cur.getString(2),cur.getString(3),cur.getString(4),cur.getString(5),cur.getString(6),cur.getLong(7))
                            )
                        }
                    }
                    p.rawQuery(
                        "SELECT device_id,obs_date,value,imported_at FROM daily WHERE device_id IN ($placeholders)",
                        batch.toTypedArray()
                    ).use { cur ->
                        while (cur.moveToNext()) {
                            c.execSQL("INSERT INTO daily(device_id,obs_date,value,imported_at) VALUES(?,?,?,?)", arrayOf(cur.getString(0),cur.getString(1),cur.getInt(2),cur.getLong(3)))
                        }
                    }
                }
            }
            c.setTransactionSuccessful()
        } finally {
            c.endTransaction()
        }
    }

    private fun readRows(dbHelper: SnapshotDb, month: YearMonth): List<SnapshotRow> {
        val out = mutableListOf<SnapshotRow>()
        dbHelper.readableDatabase.rawQuery("SELECT device_id,obs_date,value FROM daily WHERE substr(obs_date,1,7)=? ORDER BY obs_date,device_id", arrayOf(month.toString())).use { c ->
            while (c.moveToNext()) {
                val date = runCatching { LocalDate.parse(c.getString(1)) }.getOrNull() ?: continue
                out += SnapshotRow(c.getString(0), date, c.getInt(2))
            }
        }
        return out
    }

    private fun readCoverageEnd(dbHelper: SnapshotDb, month: YearMonth): LocalDate? =
        dbHelper.readableDatabase.rawQuery("SELECT coverage_end FROM meta WHERE month_key=? LIMIT 1", arrayOf(month.toString())).use { c ->
            if (c.moveToFirst()) c.getString(0)?.let { runCatching { LocalDate.parse(it) }.getOrNull() } else null
        }

    private fun readImportedAt(dbHelper: SnapshotDb, month: YearMonth): Long? =
        dbHelper.readableDatabase.rawQuery("SELECT imported_at FROM meta WHERE month_key=? LIMIT 1", arrayOf(month.toString())).use { c ->
            if (c.moveToFirst()) c.getLong(0) else null
        }

    private fun isLocked(dbHelper: SnapshotDb): Boolean =
        dbHelper.readableDatabase.rawQuery("SELECT locked FROM meta LIMIT 1", null).use { c -> c.moveToFirst() && c.getInt(0) != 0 }

    private fun rolloverIfNeeded(asOf: LocalDate) {
        val current = YearMonth.from(asOf)
        val previous = current.minusMonths(1)
        val storedCurrent = currentDb.readableDatabase.rawQuery("SELECT month_key FROM meta LIMIT 1", null).use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
        if (storedCurrent == current.toString()) return

        // Physical four-database rollover:
        //   September Current Full       -> October Previous Full
        //   September Current My Devices -> October Previous My Devices
        // and then create a genuinely new, empty October Current pair.
        // The historical pair is never reconstructed from October ownership.
        val oldMonth = storedCurrent?.let { runCatching { YearMonth.parse(it) }.getOrNull() }
        if (oldMonth != null && oldMonth == previous) {
            // Rollover is the one deliberate exception to the historical lock:
            // the locked database belongs to the MONTH THAT IS BEING DISCARDED.
            // The completed current month must become the new previous month,
            // including its physical My Devices snapshot. copyDatabase() replaces
            // the old August contents with September contents atomically per store.
            copyDatabase(currentDb, previousDb)
            copyDatabase(currentMyDevicesDb, previousMyDevicesDb)
        }

        // Start the new Current Month Full and Current Month My Devices databases
        // physically empty. They will grow only from October imports/ownership.
        clearDatabase(currentDb)
        clearDatabase(currentMyDevicesDb)
    }

    private fun clearDatabase(dbHelper: SnapshotDb) {
        val db = dbHelper.writableDatabase
        db.beginTransaction()
        try {
            db.delete("daily", null, null)
            db.delete("devices", null, null)
            db.delete("meta", null, null)
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    private fun copyDatabase(from: SnapshotDb, to: SnapshotDb) {
        val src = from.readableDatabase
        val dst = to.writableDatabase
        dst.beginTransaction()
        try {
            dst.delete("daily", null, null)
            dst.delete("devices", null, null)
            dst.delete("meta", null, null)
            src.rawQuery("SELECT month_key,coverage_start,coverage_end,source_name,imported_at,locked FROM meta LIMIT 1", null).use { c ->
                if (c.moveToFirst()) dst.execSQL("INSERT INTO meta(month_key,coverage_start,coverage_end,source_name,imported_at,locked) VALUES(?,?,?,?,?,?)", arrayOf(c.getString(0),c.getString(1),c.getString(2),c.getString(3),c.getLong(4),c.getInt(5)))
            }
            src.rawQuery("SELECT device_id,trade_code,partner_name,cluster,region,territory,staff_name,imported_at FROM devices", null).use { c ->
                while (c.moveToNext()) dst.execSQL("INSERT INTO devices(device_id,trade_code,partner_name,cluster,region,territory,staff_name,imported_at) VALUES(?,?,?,?,?,?,?,?)", arrayOf(c.getString(0),c.getString(1),c.getString(2),c.getString(3),c.getString(4),c.getString(5),c.getString(6),c.getLong(7)))
            }
            src.rawQuery("SELECT device_id,obs_date,value,imported_at FROM daily", null).use { c ->
                while (c.moveToNext()) dst.execSQL("INSERT INTO daily(device_id,obs_date,value,imported_at) VALUES(?,?,?,?)", arrayOf(c.getString(0),c.getString(1),c.getInt(2),c.getLong(3)))
            }
            dst.setTransactionSuccessful()
        } finally {
            dst.endTransaction()
        }
    }

    private fun monthFromFilename(name: String, defaultYear: Int): YearMonth? {
        val dates = HumanDateParser.extractDates(name, defaultYear).sorted()
        if (dates.isNotEmpty()) return YearMonth.from(dates.first())
        val lower = name.lowercase(Locale.US)
        val symbols = DateFormatSymbols(Locale.US).months
        symbols.forEachIndexed { index, monthName ->
            if (monthName.isNotBlank() && lower.contains(monthName.lowercase(Locale.US))) return YearMonth.of(defaultYear, index + 1)
        }
        DateFormatSymbols(Locale.US).shortMonths.forEachIndexed { index, monthName ->
            if (monthName.isNotBlank() && lower.contains(monthName.lowercase(Locale.US))) return YearMonth.of(defaultYear, index + 1)
        }
        return null
    }

    private fun parseReceivedAt(value: String): Long? = runCatching {
        java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).parse(value)?.time
    }.getOrNull()
}
