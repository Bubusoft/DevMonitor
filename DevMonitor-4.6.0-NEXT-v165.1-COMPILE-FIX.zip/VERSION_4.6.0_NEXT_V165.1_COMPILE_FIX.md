# DevMonitor 4.6.0-NEXT v165.1 — Compile Fix

## Purpose

This is a targeted compile correction for v165.

GitHub Actions reported three errors in `SimRegReport.kt` because `withFrameNanos` was referenced as `kotlinx.coroutines.withFrameNanos`, but the frame-clock API belongs to Jetpack Compose Runtime.

## Correction

- Added the Compose Runtime `withFrameNanos` import.
- Replaced the incorrect `kotlinx.coroutines.withFrameNanos { }` references with `withFrameNanos { }`.
- No report-storage, previous-month, import-order, same-coverage replacement, rendering-flow, payment, Device Monitor, Profile Builder, or business-logic changes were made.

## Protected behavior

The v165 rendering-stage behavior remains unchanged:

- one floating waiting window;
- progress can remain at 100% while the imported table is rendered;
- the existing automatic report-table advance is preserved;
- the waiting window closes only after the report-table-ready callback.

## Verification

The supplied GitHub Actions failure was isolated to these three unresolved references. The source correction removes those unresolved references. Local Gradle compilation is not available in this environment because the required Gradle distribution is not cached and external Gradle download is unavailable.
