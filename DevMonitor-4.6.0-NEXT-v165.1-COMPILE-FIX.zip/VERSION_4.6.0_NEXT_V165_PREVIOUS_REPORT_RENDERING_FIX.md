# DevMonitor 4.6.0-NEXT v165 — Previous Report Display + Import Rendering Completion

## Purpose

Correct the remaining Loaded Report behavior observed after v164.1.

## Changes

### 1. Previous-month report remains the selected report after import

When an imported report belongs to the immediately previous calendar month, the report screen now prefers the report supplied by the import instead of immediately replacing it with the My Devices working-set table.

The imported report's month/coverage is therefore what is displayed after import. The existing current-month behavior remains available when the report viewer is opened normally.

The existing current report is no longer cleared merely because a new report import starts. The current table can remain mounted behind the single floating loader until the newly imported report is ready.

### 2. Show All / My Devices behavior remains user-controlled

The explicit `Show All` action still controls the full two-month company view. The change only ensures that a newly imported report is visible first so an imported previous-month report is not hidden behind the working-set/continuous view.

### 3. Floating waiting window now covers rendering

Import progress reaches 100% with the message **Rendering the imported table…** and remains visible while the report screen lays out the table and performs the established automatic advance to the table area.

The loader is dismissed only after the report screen confirms that the table has been laid out and the automatic advance has completed.

This removes the observed gap between 100% import completion and visible table rendering.

No new row-counting or performance-monitoring calculation was introduced. The final rendering stage is only a UI representation of the existing workflow.

## Protected

- PaymentEngine and payment formulas
- Payment-cycle/progression rules
- Device Monitor/SMS business logic
- HQ two-month storage architecture
- Same-coverage replacement rule
- Profile Builder
- Existing automatic report-table scroll behavior
- Import-only downstream separation
